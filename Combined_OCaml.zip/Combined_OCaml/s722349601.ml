let (n, m) = Scanf.sscanf (read_line ()) "%d %d" @@ fun n m -> (n, m)
let ab = Array.init m @@ fun _ -> Scanf.sscanf (read_line ()) "%d %d" @@ fun a b -> (a, b)

let cnt = Array.make 10_001 0

let () =
  Array.iter (fun (a, b) ->
    cnt.(a) <- cnt.(a) + 1;
    cnt.(b) <- cnt.(b) + 1
  ) ab;
  print_endline @@ if cnt 
    |> Array.map (fun cnt -> cnt mod 2 = 0)
    |> Array.fold_left (&&) true 
    then "YES" else "NO"
open Printf
open Scanf

let solve s1 s2 =
  if s1.[0] = s2.[2] && s1.[1] = s2.[1] && s1.[2] = s2.[0] then "YES" else "NO"

let () =
  scanf "%s %s " solve |> printf "%s\n"

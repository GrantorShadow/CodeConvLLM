let s = read_line ()
let t = read_line ()
let _ = print_endline @@ if s.[0] = t.[2] && s.[1] = t.[1] && s.[2] = t.[0] then "YES" else "NO"
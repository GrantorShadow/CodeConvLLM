Scanf.scanf "%d %d" (fun a b ->
    print_endline @@ if (a * b) mod 2 = 1 then "Yes" else "No"
)
open Scanf
open Printf

let () = scanf "%d %d %d" (fun a b h -> (a + b) * h / 2
  ) |> printf "%d\n"
let get_line () =
    read_line ()
    |> Str.split (Str.regexp " ")

let rec dp lst k s =
    match lst with
    | [] when k = 0 && s = 0 -> 1
    | x :: xs -> dp xs k s + dp xs (k - 1) (s - x)
    | _ -> 0

let rec solve a n cards =
    if n = 0 then 0
    else dp cards n (n * a) + solve a (n - 1) cards

let () =
    let [n; a] =
        get_line ()
        |> List.map int_of_string
    in
    let cards =
        get_line ()
        |> List.map int_of_string
    in
    solve a n cards
    |> print_int
    |> print_newline

let () = Scanf.scanf "%d"
           (fun n ->
             let rec minus2ary_from_10ary quotient ans =
               match quotient with
               | 0 -> ans
               | n when n > 0 -> minus2ary_from_10ary (n / -2) (ans * 10 + n mod -2)
               | n when n mod -2 == 0 -> minus2ary_from_10ary (n / -2) (ans * 10)
               | n ->  minus2ary_from_10ary (n / -2 + 1) (ans * 10 + 1)  (* 結果の調整 *)
             in
             Printf.printf "%d"  (minus2ary_from_10ary (n) 0))   
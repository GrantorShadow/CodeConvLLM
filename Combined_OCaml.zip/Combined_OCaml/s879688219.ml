let count_intersection s t =
    List.length (List.filter (fun a -> List.mem a t) s)

let solve s t : unit =
    let (s, t) = (List.sort_uniq compare s, List.sort_uniq compare t) in
    Printf.printf "%d\n" (count_intersection s t)

let () =
    let n = Scanf.scanf " %d " (fun n -> n) in
    let s = Array.make n 0 in
    for i = 1 to n do
        Scanf.scanf " %d " (Array.set s (i-1))
    done ;

    let q = Scanf.scanf " %d " (fun n -> n) in
    let t = Array.make q 0 in
    for i = 1 to q do
        Scanf.scanf " %d " (Array.set t (i-1))
    done ;

    solve (Array.to_list s) (Array.to_list t)
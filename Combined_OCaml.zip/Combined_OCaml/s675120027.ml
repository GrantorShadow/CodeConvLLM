let () =
  let i = read_line () in
  let a,b = Scanf.sscanf i "%d %d" (fun a b ->  a,b) in
  print_endline
    (Printf.sprintf "%d %d %f" (a/b) (a mod b) (float a /. float b) )
let () =
  Scanf.scanf "%d %d" (fun a b -> if a <= 8 && b <= 8 then "Yay!" else ":(")
  |> print_endline
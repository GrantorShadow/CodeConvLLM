let () = Scanf.scanf "%d %d %d\n" @@ fun r c k ->
  let vss = Array.make_matrix (r + 1) (c + 1) 0 in
  for i = 0 to k - 1 do
    Scanf.scanf "%d %d %d\n" @@ fun r c v ->
      vss.(r).(c) <- v
  done;
  let dp =
    Array.init (r + 1) @@ fun _ ->
      Array.init (c + 1) @@ fun _ ->
        Array.init 4 @@ fun _ -> min_int in
  dp.(1).(1).(0) <- 0;
  for i = 1 to r do
    for j = 1 to c do
      for k = 0 to 3 do
        dp.(i).(j).(0) <- max dp.(i).(j).(0) dp.(i - 1).(j).(k);
        dp.(i).(j).(k) <- max dp.(i).(j).(k) dp.(i).(j - 1).(k)
      done;
      for k = 3 downto 1 do
        dp.(i).(j).(k) <- max dp.(i).(j).(k) (dp.(i).(j).(k - 1) + vss.(i).(j))
      done;
    done
  done;
  Printf.printf "%d\n" @@ Array.fold_left max min_int dp.(r).(c)

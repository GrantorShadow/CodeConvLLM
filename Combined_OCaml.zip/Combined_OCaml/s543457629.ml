let split_string ?(pattern="") = Str.split @@ Str.regexp pattern
let n = Scanf.sscanf (read_line ()) "%d" @@ fun n -> n
let a = read_line () |> split_string ~pattern:" " |> List.map int_of_string
let b = read_line () |> split_string ~pattern:" " |> List.map int_of_string

let c = List.map2 (fun a b -> b - a) a b
let (px, mx) = List.fold_left (fun (sp, sm) c -> if c > 0 then (c :: sp, sm) else (sp, c :: sm)) ([], []) c
let sp = List.fold_left (+) 0 px
let sm = List.fold_left (+) 0 mx

let f () = 
  let rec loop i = function
    | (rest, _) when rest <= 0 -> i
    | (_, []) -> failwith ""
    | (rest, x :: xs) -> loop (i + 1) (rest + x, xs)
  in
  let mx = List.sort compare mx in
  List.length px + loop 0 (sp, mx)

let () = 
  if sp + sm > 0 then print_endline "-1"
  else if sp = 0 then print_endline "0" 
  else Printf.printf "%d\n" @@ f ()
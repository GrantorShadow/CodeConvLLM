let n, b = read_int (), ref true
let cs = Array.make n 0
let rec f n a = if n <= 0 then a else f (n - 1) (2 * a mod 1000000007)
let _ = for i = 1 to n do Scanf.scanf " %d" @@ fun a -> if a mod 2 = n mod 2 then b := false; cs.(a / 2) <- cs.(a / 2) + 1 done; for i = 0 to n / 2 + n mod 2 - 1 do if not !b || i = 0 && cs.(i) <> 2 - n mod 2 || i > 0 && cs.(i) <> 2 then (print_endline "0"; exit 0) done; Printf.printf "%d\n" @@ f (n / 2) 1
Scanf.scanf "%d %d %d %s" (fun n a b s ->
    let rec loop i pass passb =
        if i = n then () else
        if pass < a + b && s.[i] <> 'c' then (
            if s.[i] = 'a' then (print_endline "Yes"; loop (i + 1) (pass + 1) passb) else
                if passb < b then (print_endline "Yes"; loop (i + 1) (pass + 1) (passb + 1))
                else (print_endline "No"; loop (i + 1) pass passb)
        ) else (print_endline "No"; loop (i + 1) pass passb)
    in
    loop 0 0 0
)
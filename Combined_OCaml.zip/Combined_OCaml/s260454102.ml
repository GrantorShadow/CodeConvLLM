open Batteries
open Printf
let () =
  let n = Scanf.scanf "%d " (fun a -> a) in
  let l = Scanf.scanf "%d " (fun a -> a) in
  let s_l = Array.to_list @@ Array.init n (fun _ -> Scanf.scanf "%s " (fun a -> a)) in

  let s_ls = List.sort compare s_l in

  Printf.printf "%s\n" @@
  List.fold_left (^) "" s_ls

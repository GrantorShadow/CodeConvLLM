open Batteries
module EnumL = Enum.Labels
open Tuple

let dbg x = Printf.eprintf "[debug]%s\n" @@ dump x; x

let scan fmt f =
  Scanf.sscanf (read_line ()) fmt f

let scan_lines n fmt f =
  List.Labels.map
    (List.range 1 `To n)
    ~f:(fun _ -> scan fmt f)
  |> List.enum

let scan_list cnv =
  let l = read_line ()
          |> String.split_on_char ' '
          |> List.map cnv in
  List.enum l

let scan_lists n cnv =
  let ll = List.Labels.map (List.range 1 `To n)
      ~f:(fun _ -> scan_list cnv) in
  List.enum ll

let scan_array n m e conv =
  let arr = Array.make_matrix n m e in
  EnumL.iter (0 --^ n)
    ~f:(fun i -> arr.(i) <- Array.of_enum @@ scan_list conv);
  arr

let (n, m) = scan "%d %d" Tuple2.make
let lights = scan_lists m Int.of_string
let onoff = scan_list Int.of_string

let rec superset = function
  | [] -> [[]]
  | x :: xs ->
    let ps = superset xs in
    ps @ List.map (fun ss -> x :: ss) ps

let rec intersection l = function
  | [] -> []
  | h::t ->
    if List.exists ((=) h) l then
      h::intersection l t
    else intersection l t

let () =
  let sets = List.enum @@ superset (List.range 1 `To n) in
  EnumL.map sets ~f:(fun set ->
      EnumL.map (Enum.combine (Enum.clone onoff) (Enum.clone lights))
        ~f:(fun (b, l) ->
            let n = List.length @@
              intersection set @@ List.of_enum @@ Enum.skip 1 @@ Enum.clone l
            in n mod 2 = b)
      |> EnumL.for_all ~f:((=) true))
  |> EnumL.filter ~f:((=) true)
  |> Enum.count
  |> Printf.printf "%d\n"

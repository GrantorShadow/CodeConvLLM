let modulo = 1000000007
let (+@) a b = (a + b) mod modulo
let ( *@) a b = (a * b) mod modulo
let rec mod_pow a n =
  if n = 0 then 1
  else if n mod 2 = 1 then a *@ mod_pow a (n-1)
  else let h = mod_pow a (n/2) in h *@ h
let () =
  Scanf.scanf "%d %d %d" @@ fun h w k ->
  let dp = Array.init (h+1) (fun _ -> Array.make w 0) in
  dp.(0).(0) <- 1;
  for i = 1 to h do
    for b = 1 to mod_pow 2 (w-1) do
      let exc = Array.init (w-1) (fun j -> b land (1 lsl j) > 0) in
      let valid = fst @@
        Array.fold_left (fun (a,p) b ->
          a && (not (p && b)), b) (true, false) exc
      in
      if valid then begin
        for j = 0 to w-1 do
          if (j = 0 || not exc.(j-1)) && (j = w-1 || not exc.(j)) then
            dp.(i).(j) <- dp.(i).(j) +@ dp.(i-1).(j);
        done;
        Array.iteri (fun j b ->
          if b then begin
            dp.(i).(j)   <- dp.(i).(j) +@ dp.(i-1).(j+1);
            dp.(i).(j+1) <- dp.(i).(j+1) +@ dp.(i-1).(j);
          end) exc
      end
    done;
  done;
  Printf.printf "%d\n" dp.(h).(k-1)

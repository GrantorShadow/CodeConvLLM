Scanf.scanf "%d %d" (fun n m ->
    let s = Array.make 210000 0 in
    for i = 1 to m do
        Scanf.scanf " %d %d" (fun a b ->
            if a = 1 then s.(b) <- s.(b) lor 1;
            if b = 1 then s.(a) <- s.(a) lor 1;
            if a = n then s.(b) <- s.(b) lor 2;
            if b = n then s.(a) <- s.(a) lor 2;
        )
    done;
    let a = Array.fold_left (fun acc v -> if v = 3 then true else acc) false s in
    print_endline @@ if a then "POSSIBLE" else "IMPOSSIBLE"
)
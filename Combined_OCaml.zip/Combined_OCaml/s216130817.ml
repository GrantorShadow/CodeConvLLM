open Printf
let () =
 let n = Scanf.scanf "%d\n" (fun x -> x) in
 let a_ = Array.init n (fun _ -> Scanf.scanf "%d " (fun a -> a)) in
 let rec print_array a i =
  match i with
  i when i = n -> printf "\n"
 |i' -> printf "%d " a.(i'); print_array a (i'+1) in
 let rec b_sort flag a j cnt =
  match flag with
   0 when j = 0 -> a, cnt
  |fl -> if a.(j) < a.(j-1) then
          let aj = a.(j) and aj1 = a.(j-1) in
          a.(j) <- aj1; a.(j-1) <- aj; b_sort 1 a n (cnt+1)
         else
          b_sort 0 a (j-1) cnt
 in 
 let a, c = b_sort 1 a_ (n-1) 0 in
print_array a 0; printf "%d\n" c
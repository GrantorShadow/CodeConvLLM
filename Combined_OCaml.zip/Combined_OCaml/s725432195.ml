let () = Scanf.scanf "%d %d %d" @@ fun n a b ->
  if a * b < n || n < a + b - 1 then print_endline "-1"
  else if b = 1 then begin
    for i = 1 to n do
      Printf.printf "%d " i
    done;
    print_newline ()
  end else begin
    for i = 1 to (n - a) / (b - 1) do
      for j = b * i downto b * (i - 1) + 1 do
        Printf.printf "%d " j
      done
    done;
    for i = min n (n + 1 - a + (n - a) / (b - 1)) downto (n - a) / (b - 1) * b + 1 do
      Printf.printf "%d " i
    done;
    for i = n + 2 - a + (n - a) / (b - 1) to n do
      Printf.printf "\n%d " i
    done;
    print_newline ()
  end

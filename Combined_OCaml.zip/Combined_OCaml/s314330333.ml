let () =
  let s1, s2 = Scanf.scanf "%s %s " (fun a b -> a, b) in
  Printf.printf "%s\n" (if s1 = s2 then "H" else "D")
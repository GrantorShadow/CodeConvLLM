let () = Scanf.scanf "%d %d %d %d" (fun x1 y1 x2 y2 ->
      let (x3, y3, x4, y4) = 
      match (x1, y1, x2, y2) with
      | (x1, y1, x2, y2) when (x1 <= x2 && y2 >= y1) ->
       (x2 - (y2 - y1), y2 + (x2 - x1), x1 - (y2 - y1), y1 + (x2 - x1))
      | (x1, y1, x2, y2) when (x1 <= x2)-> 
      (x2 + (y1 - y2), y2 + (x2 - x1), x1 + (y1 - y2), y1 + (x2 - x1))
      | (x1, y1, x2, y2) when (y2 >= y1)->  
      (x2 - (y2 - y1),y2 - (x1 - x2), x1 - (y2 - y1) ,y1 - (x1 - x2))
      | _ -> 
      (x2 + (y1 - y2), y2 - (x1 - x2), x1 + (y1 - y2), y1  - (x1 - x2))
      in
      Printf.printf "%d %d %d %d" x3 y3 x4 y4)
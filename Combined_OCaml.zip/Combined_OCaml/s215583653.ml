let cnt = ref 0

let insertion_sort (n:int) ?(gap=1) (a:int array) =
  for i=gap to n-1 do
    let v = a.(i) in
    let j = ref (i - gap) in
    while !j >= 0 && a.(!j) > v do
      a.(!j+gap) <- a.(!j);
      j := !j - gap;
      incr cnt;
    done;
    a.(!j+gap) <- v
  done

let gen_gaps n =
  let rec aux = function
      [] -> aux [1]
    | h::t when h > n -> t
    | h::_ as l -> aux ((float_of_int h |> ( *. ) 2.25 |> int_of_float) ::l) in
  (if n > 701 then aux [701;301;132;57;23;10;4;1]
   else List.filter ((>=) n) [701;301;132;57;23;10;4;1])
  |> Array.of_list

let shell_sort (array:int array) (n: int) =
  let g = gen_gaps n in
  let m = Array.length g in
  for i=0 to m-1 do
    insertion_sort n ~gap:g.(i) array;
  done;
  Printf.printf "%d\n" m;
  Array.iteri
    (fun i x -> Printf.printf (if i=m-1 then "%d\n" else "%d ") x)
    g;
  Printf.printf "%d\n" !cnt;
  array

let () =
  let n = read_int () in
  let rec read a = function
      i when i = n -> a
    | i -> a.(i) <- (read_int ());
      read a (i+1) in
  let a = read (Array.make n 0) 0 in
  Array.iter (Printf.printf "%d\n") (shell_sort a n)
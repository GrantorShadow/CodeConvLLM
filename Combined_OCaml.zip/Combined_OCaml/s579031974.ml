let f a b = if a+b > 9 then "error" else string_of_int (a+b);;
Scanf.scanf "%d %d" f
|> Printf.printf "%s\n"
let rec seq a b = if a > b then [] else a :: seq (a+1) b
let (>>=) x f = List.map f x |> List.concat
let () =
  Scanf.scanf "%d" @@ fun n ->
  let a = Array.init n (fun _ -> Scanf.scanf " %s" (fun s -> s)) in
  let stat =
    ['M'; 'A'; 'R'; 'C'; 'H'] |> List.map (fun ch ->
      Array.fold_left (fun x s -> if s.[0] = ch then x+1 else x) 0 a)
    |> Array.of_list
  in
  (seq 0 4 >>= fun i ->
   seq (i+1) 4 >>= fun j ->
   seq (j+1) 4 >>= fun k -> [stat.(i) * stat.(j) * stat.(k)])
  |> List.fold_left (+) 0
  |> Printf.printf "%d\n"
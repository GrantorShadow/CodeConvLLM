let () = Scanf.scanf "%d %d\n" @@ fun n k ->
  let array = Array.init n @@ fun _ -> Scanf.scanf " %d" Fun.id in
  Array.sort compare array;
  let k_array = Array.sub array 0 k in
  Printf.printf "%d\n" @@ Array.fold_left ( + ) 0 k_array 
    
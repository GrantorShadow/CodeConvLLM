let () = Scanf.scanf "%d %d %d %d %d %d" @@ fun n a b c d e ->
  let m = List.fold_left min max_int [ a; b; c; d; e ] in
  Printf.printf "%d\n" @@ (n + m - 1) / m + 4

let (n, p) = Scanf.scanf "%d %d\n" @@ fun n p -> (n, p)

let prime_fact n =
  let rec f arr i n =
    if n <= 1 then arr
    else if n < i * i then n :: arr
    else if n mod i = 0 then f (i :: arr) i (n / i)
    else f arr (i + 1) n
  in
  match f [] 2 n with
    | [] -> []
    | p :: ps ->
        let (acc, p, n) = List.fold_left (fun (acc, p, n) q ->
          if p = q
          then (acc, p, n + 1)
          else ((p, n) :: acc, q, 1)) ([], p, 1) ps in
        (p, n) :: acc

let rec pow n = function
  | 0 -> 1
  | i -> n * pow n (i - 1)

let () = 
  prime_fact p
    |> List.map (fun (i, j) -> pow i (j / n))
    |> List.fold_left ( * ) 1
    |> print_int
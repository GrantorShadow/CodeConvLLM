open Printf
open Scanf

let id x = x
let pair x y = x, y

let n = scanf "%d" id
let vs = Array.init n (fun _ -> scanf " %d" id)

let () = Array.sort (fun x y -> x - y) vs

let odd1 vs =
  let mid = n / 2 in
  let up = ref (n - 1) in
  let lo = ref 0 in
  let r1 = ref 0 in
  let p = ref vs.(mid) in
  for i = 0 to n / 2 - 1 do
    r1 := !r1 + abs (!p - vs.(!up));
    p := vs.(!up);
    decr up;
    r1 := !r1 + abs (!p - vs.(!lo));
    p := vs.(!lo);
    incr lo
  done;
  !r1
  
let odd2 vs =
  let mid = n / 2 in
  let up = ref (n - 1) in
  let lo = ref 0 in
  let r1 = ref 0 in
  let p = ref vs.(mid) in
  for i = 0 to n / 2 - 1 do
    r1 := !r1 + abs (!p - vs.(!lo));
    p := vs.(!lo);
    incr lo;
    r1 := !r1 + abs (!p - vs.(!up));
    p := vs.(!up);
    decr up
  done;
  !r1

let even1 vs =
  let mid = n / 2 in
  let up = ref (n - 1) in
  let lo = ref 0 in
  let r1 = ref 0 in
  let p = ref vs.(mid) in
  for i = 0 to n / 2 - 2 do
    r1 := !r1 + abs (!p - vs.(!lo));
    p := vs.(!lo);
    incr lo;
    r1 := !r1 + abs (!p - vs.(!up));
    p := vs.(!up);
    decr up
  done;
  r1 := !r1 + abs (!p - vs.(mid - 1));
  !r1

let even2 vs =
  let mid = n / 2 - 1 in
  let up = ref (n - 1) in
  let lo = ref 0 in
  let r1 = ref 0 in
  let p = ref vs.(mid) in
  for i = 0 to n / 2 - 2 do
    r1 := !r1 + abs (!p - vs.(!up));
    p := vs.(!up);
    decr up;
    r1 := !r1 + abs (!p - vs.(!lo));
    p := vs.(!lo);
    incr lo;
  done;
  r1 := !r1 + abs (!p - vs.(mid + 1));
  !r1

let () =
  if n mod 2 = 0 then begin
    let e1 = even1 vs in
    let e2 = even2 vs in
    printf "%d\n" (max e1 e2)
  end else begin
    let o1 = odd1 vs in
    let o2 = odd2 vs in
    printf "%d\n" (max o1 o2)
  end

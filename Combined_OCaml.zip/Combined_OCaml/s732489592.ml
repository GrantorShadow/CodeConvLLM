let split_string ?(pattern="") = Str.split @@ Str.regexp pattern
let s = read_line () |> split_string |> Array.of_list
let k = Scanf.sscanf (read_line ()) "%d" @@ fun k -> k

let s_len = Array.length s

let f = 
  let cnt = Array.of_list @@ fst @@ Array.fold_left (fun (acc, before) ch ->
    match acc with
      | [] -> ([1], ch)
      | x :: xs -> ((if before = ch then ((x + 1) :: xs) else 1 :: acc), ch)
  ) ([], "") s in
  (cnt |> Array.map (fun i -> i / 2) |> Array.fold_left (+) 0) * k -
    if s.(0) = s.(s_len - 1) then let a, b = cnt.(0), cnt.(Array.length cnt - 1) in a / 2 + b / 2 - (a + b) / 2
    else 0

let () =
  Printf.printf "%d\n" @@ match s_len with
    | 1 -> k / 2
    | 2 -> if s.(0) = s.(1) then k else 0
    | _ -> f
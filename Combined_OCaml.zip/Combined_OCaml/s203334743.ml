let n, k = Scanf.scanf " %d %d" @@ fun a b -> a, b
let rec f n = if n < k then 1 else 1 + f (n / k)
let _ = Printf.printf "%d\n" @@ f n
let () = Scanf.scanf "%d\n%s\n%s\n" @@ fun n s t ->
  Array.init (n + 1) (fun i -> i)
  |> Array.to_list
  |> List.rev
  |> List.find (fun i ->
      String.sub s (n - i) i = String.sub t 0 i)
  |> ( - ) (2 * n)
  |> Printf.printf "%d\n"
let a, b, c, k = Scanf.scanf " %d %d %d %d" @@ fun a b c d -> a, b, c, d
let _ = Printf.printf "%d\n" @@ [|a - b; b - a|].(k mod 2)
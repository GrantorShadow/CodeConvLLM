let dfs t n k =
  let p = Array.make n false in
  let d = Array.make n (-1) in
  let rec doit x z =
    if p.(x) then ()
    else begin
      p.(x) <- true;
      d.(x) <- z;
      List.iter (fun (y, c) -> doit y (z + c)) t.(x);
    end in
  doit k 0;
  d

let () =
  let n = Scanf.scanf "%d " (fun i -> i) in
  let t = Array.make n [] in
  for _ = 1 to n - 1 do
    let a, b, c = Scanf.scanf "%d %d %d " (fun a b c -> a, b, c) in
    let a, b = a - 1, b - 1 in
    t.(a) <- (b, c) :: t.(a);
    t.(b) <- (a, c) :: t.(b);
  done;
  let q, k = Scanf.scanf "%d %d " (fun q k -> q, k) in
  let k = k - 1 in
  let d = dfs t n k in
  for _ = 0 to q - 1 do
    let x, y = Scanf.scanf "%d %d " (fun x y -> x, y) in
    let x, y = x - 1, y - 1 in
    Printf.printf "%d\n" (d.(x) + d.(y))
  done
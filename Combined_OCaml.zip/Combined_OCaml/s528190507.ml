let rewrite s =
  let s_as_bytes = Bytes.of_string s in
  let _ = Bytes.set s_as_bytes 3 '8' in
  Bytes.to_string s_as_bytes
  

let () =
  let s = Scanf.scanf "%s" (fun x -> x) in
  let ans = rewrite s in
  Printf.printf "%s\n" ans


let cnt = ref 0
let g = ref []

let print_list l =
  List.iteri (fun i n -> Printf.printf (if i = 0 then "%d" else " %d") n) l;
  print_newline ()

let print_array = Array.iter (fun n -> Printf.printf "%d\n" n)

let insertion_sort a n g =
  let rec insert j v =
    if j < 0 || a.(j) <= v then a.(j + g) <- v
    else (a.(j + g) <- a.(j); incr cnt; insert (j - g) v)
  in
  let rec doit i =
    if i >= n then ()
    else (insert (i - g) a.(i); doit (i + 1))
  in
  doit g

let generate_g n =
  let rec doit i lst =
    if i > n then lst
    else doit (3*i + 1) (i :: lst)
  in
  doit 1 []

let shell_sort a n =
  cnt := 0;
  g := generate_g n;
  let rec doit = function
    | [] -> ()
    | hd :: tl -> (insertion_sort a n hd; doit tl)
  in
  doit !g

let () =
  let n = read_int () in
  let a = Array.make n 0 in
  let rec doit i =
    if i >= n then ()
    else (a.(i) <- read_int (); doit (i + 1))
  in
  doit 0;
  shell_sort a n;
  Printf.printf "%d\n" (List.length !g);
  print_list !g;
  Printf.printf "%d\n" !cnt;
  print_array a
let (n, k) = Scanf.scanf "%d %d\n" (fun n k -> (n, k))

let repeat f =
  let rec loop acc = function
    | 0 -> List.rev acc
    | n -> loop (f () :: acc) (n - 1) in
  loop []

let edges = repeat (fun () -> Scanf.scanf "%d %d\n" (fun a b -> (a-1, b-1))) (n-1)

let al = Array.make n []

let maxarea r =
  let rec area i j = function
    | 0 -> 1
    | r -> List.fold_left (fun a k -> a + (if k = i then 0 else area j k (r-1))) 1 al.(j) in
  let rec aux accu = function
    | 0 -> accu
    | k -> aux (max (area (k-1) (k-1) (r/2)) accu) (k-1) in
  if r mod 2 = 0 then aux 0 n
  else List.fold_left (fun a (i,j) -> max a ((area i j (r/2)) + (area j i (r/2)))) 0 edges

let () =
  List.iter (fun (a,b) -> al.(a) <- b :: al.(a); al.(b) <- a :: al.(b)) edges;
  print_int (n-(maxarea k))
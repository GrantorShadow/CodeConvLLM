let hand a =
    let (i,j,k,l,m) = (a.(0),a.(1),a.(2),a.(3),a.(4)) in
    if (j,k,l) = (i,i,i) || (k,l,m) = (j,j,j) then "four card"
    else if (j,l,m) = (i,k,k) || (j,k,m) = (i,i,l) then "full house"
    else if (j,k) = (i,i) || (k,l) = (j,j) || (l,m) = (k,k) then "three card"
    else if (j,l) = (i,k) || (j,m) = (i,l) || (k,m) = (j,l) then "two pair"
    else if j = i || k = j || l = k || m = l then "one pair"
    else if (i,j,k,l,m) = (i,(i+1),(i+2),(i+3),(i+4)) || (i,j,k,l,m) = (1,10,11,12,13) then "straight"
    else "null"
;;

let () =
    let rec read () =
        try let line = Scanf.scanf " %d,%d,%d,%d,%d\n" (fun v w x y z -> [|v;w;x;y;z|]) in
        Array.sort compare line;
        hand line |> print_endline;
        read ()
        with End_of_file -> ()
    in read ()
;;
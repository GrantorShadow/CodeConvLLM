open Printf
open Scanf

let id x = x

let n = scanf "%d" id

let () =
    let r = ref 0 in
    let s = string_of_int n in
    String.iter (fun c -> r := !r + (int_of_char c - int_of_char '0')) s;
    if n mod !r = 0 then
        print_endline "Yes"
    else
        print_endline "No"

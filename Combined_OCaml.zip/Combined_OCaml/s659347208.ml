let () =
  let line = read_line () in
  let a :: b :: _ = line |> String.split_on_char ' '
                    |> List.map int_of_string in
  Printf.printf "%d %d\n" (a * b) (2 * (a + b))
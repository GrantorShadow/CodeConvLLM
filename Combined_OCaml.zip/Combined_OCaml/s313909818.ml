let () = Scanf.scanf "%s %s" @@ fun a b ->
  print_endline @@
  if a = b then "H" else "D"

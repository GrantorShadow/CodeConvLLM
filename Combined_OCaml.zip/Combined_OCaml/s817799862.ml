let m = 1000000007
let ( +^ ) x y = (x + y) mod m

module IntMap = Map.Make (struct
  type t = int
  let compare = compare
end)

let () = Scanf.scanf "%d\n" @@ fun n ->
  let cs = Array.make (n + 2) 0 in
  for i = 1 to n do
    Scanf.scanf "%d\n" @@ Array.set cs i
  done;
  let dp = Array.make (n + 2) 1 in
  let acc = Array.make (n + 2) IntMap.empty in
  for i = 1 to n do
    dp.(i) <- dp.(i - 1) +^
      if cs.(i) = cs.(i - 1)
      then 0
      else (try IntMap.find cs.(i) acc.(i - 1) with Not_found -> 0);
    acc.(i) <-
      if cs.(i) = cs.(i + 1)
      then acc.(i)
      else IntMap.add cs.(i) (dp.(i - 1) +^ try IntMap.find cs.(i) acc.(i - 1) with Not_found -> 0) acc.(i - 1)
  done;
  Printf.printf "%d\n" dp.(n)

let () =
  let line = read_line () in
  let rec loop tbl = function
    | -1 -> tbl
    | i ->  match line.[i] with
      | 'a'..'z' | 'A'..'Z' as c ->
        let lc = Char.lowercase c in
        Hashtbl.replace tbl lc
          (if Hashtbl.mem tbl lc then Hashtbl.find tbl lc |> (+) 1 else 1);
        loop tbl (i-1)
      | _ -> loop tbl (i-1)
  in
  let rec print_tbl tbl = function
    | 'a'..'z' as c ->
      Printf.printf "%c : %d\n"
        c (if Hashtbl.mem tbl c then Hashtbl.find tbl c else 0);
      print_tbl tbl (Char.code c |> (+) 1 |> Char.chr)
    | _ -> ()
  in
  let tbl = loop (Hashtbl.create 32) ((String.length line) - 1) in
  print_tbl tbl 'a'
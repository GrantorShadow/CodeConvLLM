let () =
  let n = Scanf.scanf "%d\n" (fun n -> n) in
  let abs = Array.init n (fun _ -> Scanf.scanf "%d %d\n" (fun a b -> a, b)) in
  Printf.printf "%d\n" @@
  Array.fold_left (fun acc (a, b) ->
    if b <= a then acc + a - b
    else acc + a) 0 abs
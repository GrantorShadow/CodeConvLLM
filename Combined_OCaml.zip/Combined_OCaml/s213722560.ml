let read_int_list () =
	read_line ()
	|> Str.split (Str.regexp " ")
	|> List.map int_of_string

let is_const_list l =
	match l with
		| [] -> false
		| e :: es -> List.for_all ((=) e) es

let diff l1 l2 = List.map2 (-) l1 l2

let () =
	let row1 = read_int_list () in
	let row2 = read_int_list () in
	let row3 = read_int_list () in
	if is_const_list (diff row1 row2) && is_const_list (diff row2 row3) then
		print_endline "Yes"
	else
		print_endline "No"

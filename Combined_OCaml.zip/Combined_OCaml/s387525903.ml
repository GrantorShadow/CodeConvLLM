Scanf.sscanf (read_line ()) "%d %d %d" (fun h w k ->
    let s = Array.init h (fun _ -> read_line ()) in
    let sm = Array.init w (fun i ->
        let rec loop j acc =
            if j = h then acc else loop (j + 1) (acc * 2 + if s.(j).[i] = '1' then 1 else 0)
        in
        loop 0 0
    )
    in
    let bits = Array.init 1024 (fun i ->
        let rec loop k acc =
            if k = 0 then acc else loop (k lsr 1) (acc + (k land 1))
        in
        loop i 0
    )
    in
    let calc b div =
        let curline = Array.make h 0 in
        let rec loop b_ div_ sum x i =
            if i = h then (curline.(x) <- sum; curline) else
                let sum = sum + (b_ land 1) in
                if div_ land 1 = 1 then (
                    curline.(x) <- sum;
                    loop (b_ lsr 1) (div_ lsr 1) 0 (x + 1) (i + 1)
                ) else (
                    loop (b_ lsr 1) (div_ lsr 1) sum x (i + 1)
                )
        in
        loop b div 0 0 0
    in
    let exists a =
        let rec loop i =
            if i = h then false else if a.(i) > k then true else loop (i + 1)
        in
        loop 0
    in
    let calc i =
        let rec loop y sum count =
            if y = w then count else
                let curline = calc sm.(y) i in
                if exists curline then max_int else
                    let rec loop2 x flag =
                        if x = h then flag else
                            let () = sum.(x) <- sum.(x) + curline.(x) in
                            let flag = flag || sum.(x) > k in
                            loop2 (x + 1) flag
                    in
                    if loop2 0 false then loop (y + 1) curline (count + 1)
                                     else loop (y + 1) sum count
        in
        loop 0 (Array.make h 0) (bits.(i))
    in
    let rec loop i mi =
        if i < 0 then mi else
            loop (i - 1) (min mi (calc i))
    in
    loop ((1 lsl (h - 1)) - 1) max_int |> Printf.printf "%d\n"
)
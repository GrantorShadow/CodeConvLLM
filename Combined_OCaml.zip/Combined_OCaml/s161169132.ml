let id x = x
let x = Scanf.scanf "%d" id

let rec func x i cnt =
  if x <= (i + cnt) then cnt else func x (i + cnt) (cnt + 1)
    
let ans = func x 0 1

let () = Printf.printf "%d\n" ans
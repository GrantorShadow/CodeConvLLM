let rec solve ss is p =
  if String.length ss.(p) <= is.(p) then p
  else begin
    let p' = Char.code ss.(p).[is.(p)] - Char.code 'a' in
    is.(p) <- 1 + is.(p);
    solve ss is p'
  end

let () =
  Printf.printf "%c\n" @@ Char.chr @@ ( + ) (Char.code 'A') @@
    solve (Array.init 3 @@ fun _ -> read_line ()) [| 0; 0; 0 |] 0

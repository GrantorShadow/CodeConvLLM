let _ =
  let a, b, t = Scanf.scanf "%f %d %f\n" (fun a b t -> a, b, t) in
  ((t +. 0.5) /. a)
  |> int_of_float
  |> ( * ) b
  |> print_int

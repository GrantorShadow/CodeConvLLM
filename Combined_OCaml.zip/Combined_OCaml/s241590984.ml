let () =
  Scanf.scanf "%d\n" @@ fun n ->
  let prr = Array.init n @@ fun _ -> Scanf.scanf "%d " @@ fun d -> d in
  let p = Array.fold_left (fun (minN, ans) x -> if minN >= x then (x, ans+1) else (minN, ans)) (prr.(0), 0) prr in
  Printf.printf "%d\n" (snd p)
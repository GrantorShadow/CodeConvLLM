let () = Scanf.scanf "%2d%2d" @@ fun up low ->
  let yymm = 1 <= low && low <= 12 in
  let mmyy = 1 <= up && up <= 12 in
  print_endline @@
  match yymm, mmyy with
  | true, true -> "AMBIGUOUS"
  | false, false -> "NA"
  | true, false -> "YYMM"
  | false, true -> "MMYY"
let rt a b = (a + b) mod 24
  
let _ =
  Printf.printf "%d\n" @@ Scanf.scanf "%d %d\n" rt

let () = Scanf.scanf "%d\n" (fun n ->
  Array.init n (fun _ -> Scanf.scanf "%c " (fun c -> c))
  |> Array.to_list
  |> List.exists (( = ) 'Y')
  |> (function true -> "Four" | false -> "Three")
  |> print_endline )
let main =
    let rec main_ _ =
        let rec solve n x c =
            if c < 0
            then 0
            else if n = 0
            then if x = 0 && c = 0
            then 1
            else 0
            else if x < 0
            then 0
            else solve (n - 1) x c + solve (n - 1) (x - n) (c - 1)
        in

        Scanf.sscanf (read_line()) "%d %d" (
            fun n x ->
                if n = 0 && x = 0
                then ()
                else
                    (
                        print_int (solve n x 3);
                        print_string "\n";
                        main_ 1
                    )
        )
        in main_ 1
(*ABC 088 A *)
let () =
  Scanf.scanf "%d" (fun n ->
      Scanf.scanf " %d" (fun a ->
          match n mod 500 <= a with true -> "Yes" | false -> "No" )
      |> print_endline )

let solve h w c =
  let s = Array.make w 0 in
  let t = Array.make w 0 in
  let r = ref 0 in
  for i = 0 to h - 1 do
    if c.(i).(0) = 0 then r := 1
  done;
  for j = 0 to w - 1 do
    if c.(0).(j) = 0 then begin
      s.(j) <- 1;
      r := 1
    end
  done;
  for i = 1 to h - 1 do
    if c.(i).(0) = 0 then t.(0) <- 1;
    for j = 1 to w - 1 do
      if c.(i).(j) = 1 then t.(j) <- 0
      else begin
        let d = if s.(j) < t.(j-1) then s.(j) else t.(j-1) in
        t.(j) <- 1 + if s.(j-1) < d then s.(j-1) else d;
        if t.(j) > !r then r := t.(j)
      end
    done;
    Array.iteri (fun i e -> s.(i) <- e) t
  done;
  !r * !r

let () =
  let (h, w) = Scanf.scanf "%d %d " (fun h w -> h, w) in
  let c = Array.make_matrix h w 0 in
  for i = 0 to h - 1 do
    for j = 0 to w - 1 do
      c.(i).(j) <- Scanf.scanf "%d " (fun c -> c);
    done
  done;
  solve h w c |> Printf.printf "%d\n"
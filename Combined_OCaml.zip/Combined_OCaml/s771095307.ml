let () =
    let a = Array.init 5 (fun _ -> Scanf.scanf " %d" (fun i -> i)) in
    let f k =
        if k mod 10 = 0 then 10 else k mod 10
    in
    Array.sort (fun a b -> compare (f a) (f b)) a;
    let rec loop i time =
        if i < 0 then time else
            loop (i - 1) (((time + 9)/10*10) + a.(i))
    in
    loop 4 0 |> Printf.printf "%d\n"
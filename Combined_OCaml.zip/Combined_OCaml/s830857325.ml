let h, w, k = Scanf.scanf "%d %d %d\n" (fun h w k -> h, w, k)
let c = Array.init h (fun _ -> Scanf.scanf "%s\n" (fun s -> s))

let rec f0 i ans =
  if i = 1 lsl h then ans
  else
    let rec f1 j ans =
      if j = 1 lsl w then ans
      else
        let rec f2 h' black =
          if h' = h then black
          else
            let b = (i lsr h' land 1) = 0 in
            let rec f3 w' black =
              if w' = w then black
              else
                let b' = b && (j lsr w' land 1) = 0 && c.(h').[w'] = '#' in
                if b' then f3 (w' + 1) (black + 1)
                else f3 (w' + 1) black in
            let black = f3 0 black in
            f2 (h' + 1) black in
        let black = f2 0 0 in
        if black = k then f1 (j + 1) (ans + 1)
        else f1 (j + 1) ans in
    f0 (i + 1) (f1 0 ans)

let () =
  let ans = f0 0 0 in
  Printf.printf "%d\n" ans

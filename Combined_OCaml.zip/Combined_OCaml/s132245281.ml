open Scanf
open Printf

let divide n k = n mod k

let () = scanf "%d %d" divide |> printf "%d\n"
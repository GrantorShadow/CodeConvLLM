let check_bingo board hits =
  let check_list = [[0;1;2]; [3;4;5]; [6;7;8]; [0;3;6]; [1;4;7]; [2;5;8]; [0;4;8]; [2;4;6]] in
  let rec get_cell board l cell_values =
    match l with
    | [] -> cell_values
    | x::xs ->
       get_cell board xs ((Array.get board x)::cell_values)
  in
  let is_bingo l hits = List.for_all (fun x -> (List.mem x hits)) l in
  let rec check_bingo_sub board l =
    match l with
    | [] -> "No"
    | x::xs ->
       let check_cell_list = get_cell board x [] in
       let result = is_bingo check_cell_list hits in
       if result then "Yes" else check_bingo_sub board xs
  in
  check_bingo_sub board check_list

let rec input_boards n board =
  match n with
  | 0 -> Array.of_list (List.rev board)
  | m ->
     let new_board = Scanf.sscanf (read_line ()) "%d %d %d" (fun a b c -> c :: b :: a :: board) in
     input_boards (m-1) new_board

let input_hits n hits =
  let rec input_hits_sub n hits =
    match n with
    | 0 -> hits
    | m ->
       let hit = Scanf.sscanf (read_line ()) "%d" (fun x -> x) in
       input_hits_sub (m-1) (hit::hits)
  in
  input_hits_sub n hits

let board = input_boards 3 []
let n_hit = Scanf.sscanf (read_line ()) "%d" (fun x -> x)
let hits  = input_hits n_hit []
let ans = check_bingo board hits
let () = print_endline ans

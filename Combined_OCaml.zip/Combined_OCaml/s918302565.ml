let () = Scanf.scanf "%d %d" (fun x y ->
  if x mod y = 0 then print_endline "-1"
  else Printf.printf "%d\n" x)
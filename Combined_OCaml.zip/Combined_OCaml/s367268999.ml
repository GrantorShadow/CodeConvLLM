open Printf open Scanf
open Array

let rec gcd m n = match m,n with | m,0 -> m | m,n -> gcd n (m mod n)

module SegTree_tmp = struct
  module type S = sig
    type t
    val  op: t -> t -> t
    val ide: t
    val upd: t -> t -> t
  end
  let par i = (i-1)/2
  let chl i = 2*i+1
  let chr i = 2*i+2
  module Make (X:S) = struct
    type t = SegTree of (X.t array * int)
    let raw (SegTree (a,_)) = a
    let make raw = (* O(n) *)
      let ln = Array.length raw in
      let n =
        let n = ref 1 in
        while !n<ln do n := !n*2 done; !n in
      let a = Array.make (2*n-1) X.ide in
      for i=0 to ln-1 do
        a.(i+n-1) <- raw.(i) done;
      for i=n-2 downto 0 do
        a.(i) <- X.op a.(chl i) a.(chr i) done;
      SegTree (a,n)
    let update_destructive (SegTree(a,n)) i v =
      let i = ref @@ i+(n-1) in
      a.(!i) <- X.upd a.(!i) v;
      while !i>0 do
        i := par !i;
        a.(!i) <- X.op a.(chl !i) a.(chr !i) done
    let get_half_open (SegTree(a,n)) l r = (* O(logn), [l,r) *)
      let rec f0 i p q =
        if q<=l || r<=p then X.ide
        else if l<=p && q<=r then a.(i)
        else
          let vl = f0 (2*i+1) p ((p+q)/2) in
          let vr = f0 (2*i+2) ((p+q)/2) q in
          X.op vl vr
      in f0 0 0 n
    let get_closed seg l r = get_half_open seg l (r+1) (* [l,r] *)
  end
end

module ST = SegTree_tmp.Make(struct
  type t = int
  let op = gcd
  let ide = 0
  let upd _prev nw = nw
end)

let () = scanf " %d" @@ fun n ->
  let a = init n (fun _ -> scanf " %d" @@ fun v -> v) in
  let t = ST.make a in
  mapi (fun i _ ->
    let l = if i=0 then 0 else ST.get_closed t 0 (i-1) in
    let r = if i=n-1 then 0 else ST.get_closed t (i+1) (n-1)
    in gcd l r
  ) a
  |> fold_left max 0
  |> print_int




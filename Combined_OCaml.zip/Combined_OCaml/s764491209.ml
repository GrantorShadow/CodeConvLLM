Scanf.scanf "%d" (fun n ->
    let a = Array.init n (fun _ -> Scanf.scanf " %d %d" (fun a b -> a, b)) in
    Array.sort (fun (a1, b1) (a2, b2) -> compare (a1 - b1) (a2 - b2)) a;
    let rec loop i acc1 acc2 =
        if i = n then acc1 - acc2 else
            let (x, y) = a.(i) in
            if i mod 2 = 0 then loop (i + 1) (acc1 + x) acc2
                           else loop (i + 1) acc1 (acc2 + y)
    in
    loop 0 0 0 |> Printf.printf "%d\n"
)
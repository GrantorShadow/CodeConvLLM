let () =
  let n, m = Scanf.scanf "%d %d" (fun n m -> n, m) in
  let a = Array.init n (fun _ -> Scanf.scanf " %d %d" (fun a b -> a, b)) in
  let b = Array.init m (fun _ -> Scanf.scanf " %d %d" (fun c d -> c, d)) in
  a |> Array.map (fun (xa, ya) ->
    Array.mapi (fun i (xb, yb) -> (abs (xb-xa) + abs (yb-ya), i+1)) b
    |> Array.fold_left min (101010101010, -1))
  |> Array.iter (fun (_,i) -> Printf.printf "%d\n" i)

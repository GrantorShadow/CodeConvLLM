let lim = 330
let () =
  Scanf.scanf "%d %d" @@ fun n ww ->
  let a = Array.init n (fun _ -> Scanf.scanf " %d %d" (fun x y -> x, y)) in
  let w0 = fst a.(0) in

  let dp = Array.make_matrix lim (n+1) 0 in
  a |> Array.iter (fun (w, v) ->
    let w = w - w0 in
    for i = lim-1 downto w do
      for j = n downto 1 do
        if i + j * w0 <= ww then
          dp.(i).(j) <- max dp.(i).(j) (dp.(i-w).(j-1) + v)
    done done);

  Array.fold_left (Array.fold_left max) 0 dp
  |> Printf.printf "%d\n"
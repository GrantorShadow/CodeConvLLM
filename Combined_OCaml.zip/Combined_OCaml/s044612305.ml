#include<bits/stdc++.h>
#define rep(i,n)for(int i=0;i<n;i++)
using namespace std;

double l[20].a[20],b[20];

int main() {
	int n,m;scanf("%d%d",&n,&m);
	rep(i,n){
		scanf("%lf%lf%lf",&l[i],&a[i],&b[i]);
	}
	double Max=0;
	rep(i,1<<n){
		int cnt=0;
		rep(j,n){
			if(i>>j&1)cnt++;
		}
		if(cnt!=m)continue;
		rep(j,n){
			if(!(i>>j&1))continue;
			
		}
	}
}
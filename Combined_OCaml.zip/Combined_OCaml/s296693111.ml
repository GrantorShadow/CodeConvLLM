let s = read_line () |> Bytes.of_string
let _ = Bytes.set s 3 '8'; Printf.printf "%s\n" @@ Bytes.to_string s
open Printf
open Scanf

let () =
  let calc a b c d =
    max ((min b d) - (max a c)) 0 in
  let s = scanf "%d %d %d %d\n" calc in
  printf "%d\n" s

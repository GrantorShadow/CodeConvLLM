open Printf
open Scanf

let solve a b = (a - 1) * (b - 1)
                            
let () =
  scanf "%d %d " solve |> printf "%d\n"

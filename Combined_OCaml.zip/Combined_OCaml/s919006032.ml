Scanf.scanf "%d" (fun n ->
    let a = Array.init n (fun i -> Scanf.scanf " %d" (fun a -> (a, i))) in
    Array.sort compare a;
    let rec loop i acc =
        if i = n then acc / 2 else
            let (_, pos) = a.(i) in
            let q = abs (pos - i) mod 2 in
            loop (i + 1) (acc + q)
    in
    loop 0 0 |> Printf.printf "%d\n"
)
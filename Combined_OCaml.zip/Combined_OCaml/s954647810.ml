let gcd m n =
  let rec doit x y =
    if y <= 0 then x else doit y (x mod y) in
  doit (max m n) (min m n)

let lcm m n = m * n / (gcd m n)

let f () = Scanf.scanf "%d " (fun i -> i)

let () =
  let n = read_int () in
  let rec doit i acc =
    if i = n then acc
    else doit (i + 1) (lcm acc (f ())) in
  Printf.printf "%d\n" (doit 1 (f ()))
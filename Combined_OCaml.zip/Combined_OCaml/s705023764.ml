let n, x = Scanf.scanf " %d %d" @@ fun a b -> a, b
let ls = Array.init n @@ fun _ -> Scanf.scanf " %d" @@ (+) 0
let d = ref 0
let ans = ref 0
let _ =
  for i = 0 to n - 1 do
    if !d <= x then incr ans;
    d := !d + ls.(i)
  done;
  Printf.printf "%d\n" !ans
let rec solve a b c x y =
    match x, y with
    | 0, 0 -> 0
    | _, 0 -> min (a * x) (2 * c * x)
    | 0, _ -> min (b * y) (2 * c * y)
    | _, _ -> min (a + b) (2 * c) + solve a b c (x - 1) (y - 1)

let () =
    Scanf.scanf "%d %d %d %d %d\n" solve |> Printf.printf "%d\n"

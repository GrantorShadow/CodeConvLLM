let rec fix ~f x = f (fix ~f) x

let modulo = 1000000007
let ( *@) a b = a * b mod modulo
let rec ( **@) a n = 
  if n = 0 then 1
  else if n mod 2 = 1 then a *@ a **@ (n-1)
  else let h = a **@ (n/2) in h *@ h
let (/@) a b = a *@ (b **@ (modulo-2))

let rec factorize x =
  fix 2 x [] ~f:(fun f d y m -> 
    if y = 1 || d * d > x then
      if y > 1 then (y, 1) :: m else m
    else 
      let c, y = fix (0, y) ~f:(fun g (c, y) ->
        if y mod d > 0 then (c, y)
        else g (c+1, y / d))
      in
      f (d+1) y (if c = 0 then m else (d, c) :: m))
  |> List.rev

let () =
  Scanf.scanf "%d" @@ fun n ->
  let a = Array.init n (fun _ -> Scanf.scanf " %d" ((+) 0)) in
  let fa = Array.make 1000001 0 in
  Array.iter (fun v ->
    factorize v |> List.iter (fun (d, c) -> fa.(d) <- max fa.(d) c)) a;
  let ma = fix 2 1 ~f:(fun f i ma ->
    if i > 1000000 then ma else f (i+1) @@ ma *@ i **@ fa.(i)) in
  Array.fold_left (fun acc v -> (acc + ma /@ v) mod modulo) 0 a
  |> Printf.printf "%d\n"

open Scanf
open Printf

let () = scanf "%s %s %s" (fun s1 s2 s3 ->
  "A" ^ String.sub s2 0 1 ^ "C"
  ) |> printf "%s\n"
Scanf.scanf "%d %d %d" (fun h w k ->
    let c = Array.init h (fun _ -> Scanf.scanf " %s" (fun c -> c)) in

    let count mask =
        let rec loop_y y acc =
            let rec loop_x x acc =
                if x = w then acc else
                    let m = (1 lsl (y + w)) lor (1 lsl x) in
                    let acc = if m land mask > 0 then acc else
                        if c.(y).[x] = '.' then acc else acc + 1
                    in
                    loop_x (x + 1) acc
            in
            if y = h then acc else loop_y (y + 1) (loop_x 0 acc)
        in
        loop_y 0 0
    in

    let rec loop i acc =
        if i < 0 then acc else
            let acc = if count i = k then acc + 1 else acc in
            loop (i - 1) acc
    in
    loop ((1 lsl (h + w))-1) 0 |> Printf.printf "%d\n"
)
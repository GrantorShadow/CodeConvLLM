let n, m = Scanf.scanf "%d %d" (fun x y -> x, y)
let graph = Array.init n (fun _ -> [])
let _ = Array.init m (fun _ -> Scanf.scanf " %d %d" (fun a b ->
  graph.(a-1) <- b-1 :: graph.(a-1);
  graph.(b-1) <- a-1 :: graph.(b-1)))
let visited = Array.make n false
let rec dfs i d =
  if d >= n then 1 else
    graph.(i) |> List.map (fun j ->
      if visited.(j) then 0 else (
        visited.(j) <- true;
        let v = dfs j (d+1) in
        visited.(j) <- false;
        v
      )
    ) |> List.fold_left (+) 0

let () =
  visited.(0) <- true;
  dfs 0 1 |> Printf.printf "%d\n"
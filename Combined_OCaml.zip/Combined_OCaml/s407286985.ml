open Printf
open Scanf

let () =
  let s = read_line () and t = read_line () in
  let n = String.length s in
  let m = String.length t in
  let next = Array.make_matrix (n * 2) 26 ~-1 in
  for i = n*2-2 downto 0 do
    for j = 0 to 25 do
      if Char.code s.[i mod n] - Char.code 'a' = j then
        next.(i).(j) <- i
      else
        next.(i).(j) <- next.(i+1).(j)
    done;
  done;
  Array.init m (fun i -> t.[i])
  |> Array.fold_left (fun (i, ans) c ->
    match ans with
    | Some ans ->
        let c' = Char.code c - Char.code 'a' in
        let i' = next.(i).(c') in
        if i' <> -1 then
          ((i' + 1) mod n, Some (i'+1-i+ans))
        else
          (0, None)
    | None -> (0, None)
  ) (0, Some 0)
  |> snd
  |> (fun x -> match x with Some x -> x | None -> ~-1)
  |> printf "%d\n"

let calc = function
  | 25 -> "Christmas"
  | 24 -> "Christmas Eve"
  | 23 -> "Christmas Eve Eve"
  | 22 -> "Christmas Eve Eve Eve"
  | n  -> string_of_int n

let () =
  let n = Scanf.scanf "%d" (fun n -> n) in
  calc n |> print_endline


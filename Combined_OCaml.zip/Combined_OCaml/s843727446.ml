let id x = x
let (|>) x f = f x

let repeat f =
  let rec loop arr = function
    | 0 -> List.rev arr
    | n -> loop (f () :: arr) (n-1)
  in
  loop []

let n = Scanf.scanf "%d\n" (fun n -> n)
let a = repeat (fun () -> Scanf.scanf "%d " id) n

let select choose arr x = List.fold_left choose x arr
let max_list arr = select max arr min_int
let min_list arr = select min arr max_int

let () =
  let ma = max_list a in
  let mi = min_list a in
  Printf.printf "%d\n" (ma-mi)

module S = Set.Make (struct type t = int let compare = compare end)

let () =
    let find_root ver =
        let rec loop prev cur =
            let rec loop_2 = function
                | [] -> cur
                | (hd, _) :: tl -> if hd = prev then loop_2 tl else loop cur hd
            in
            loop_2 ver.(cur)
        in
        loop 1 (fst (List.hd ver.(1)))
    in
    let main () =
        let n = int_of_string (read_line ()) in
        let ab = Array.init (n - 1) (fun i -> Scanf.sscanf (read_line ()) "%d %d" (fun a b -> a, b, i)) in
        let ver = Array.make (n + 1) [] in
        let used = Array.make (n + 1) S.empty in
        let col = Array.make (n + 1) 0 in
        Array.iter (fun (a, b, i) ->
            ver.(a) <- (b, i) :: ver.(a);
            ver.(b) <- (a, i) :: ver.(b)) ab;
        let k = Array.fold_left (fun acc l -> max acc (List.length l)) 0 ver in
        let find_color prevc set =
            let rec loop i set = if S.mem i set then loop (i + 1) set else i in
            loop prevc set
        in
        let rec loop cur =
            let rec loop2 prevc = function
                | [] -> ()
                | (hd, edge) :: tl -> (
                    let c = if col.(edge) = 0 then (
                        let c = find_color prevc used.(cur) in
                        col.(edge) <- c;
                        used.(cur) <- S.add c used.(cur);
                        used.(hd) <- S.add c used.(hd);
                        loop hd;
                        c + 1
                    ) else prevc in
                    loop2 c tl
                )
            in
            loop2 1 ver.(cur)
        in
        let root = find_root ver in
        loop root;
        Printf.printf "%d\n" k;
        for i = 0 to n - 2 do
            Printf.printf "%d\n" col.(i)
        done
    in
    main ()
module IntPairMap = Map.Make (struct
  type t = int * int
  let compare = compare
end)

let () = Scanf.scanf "%d %d %d\n" @@ fun n ma mb ->
  let abc = Array.init n @@ fun _ ->
    Scanf.scanf "%d %d %d\n" @@ fun a b c -> a, b, c in
  Array.fold_left (fun m (a, b, c) ->
    IntPairMap.fold (fun (a', b') c' m ->
      IntPairMap.add (a + a', b + b')
        (min (c + c') (try IntPairMap.find (a + a', b + b') m with Not_found -> max_int)) m) m m) (IntPairMap.singleton (0, 0) 0) abc
  |> IntPairMap.bindings
  |> List.filter (fun ((a, b), _) -> 0 < a && 0 < b && b * ma = a * mb)
  |> List.map snd
  |> List.fold_left min max_int
  |> (fun c -> if c = max_int then print_endline "-1" else Printf.printf "%d\n" c)

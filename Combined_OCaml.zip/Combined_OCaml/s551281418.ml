let pn = 2

let pow x n =
  let rec doit i acc =
    if i = n then acc
    else doit (i + 1) (acc*x)
  in doit 0 1

let str_fold_left f init s =
  let n = String.length s in
  let rec doit i acc =
    if i = n then acc
    else doit (i + 1) (f acc s.[i])
  in doit 0 init

let () =
  let p = read_line () in
  let t = read_line () in
  let n = String.length p in
  let m = String.length t in
  let h = Array.make (n + 1) 0 in
  String.iteri (fun i c -> h.(i+1) <- h.(i)*pn + Char.code c) p;
  let ht = str_fold_left (fun acc c -> acc*pn + Char.code c) 0 t in
  let x = pow pn m in
  let rec doit i =
    if i <= n then begin
      if h.(i) - h.(i-m)*x = ht then Printf.printf "%d\n" (i - m);
      doit (i + 1)
    end in
  doit m
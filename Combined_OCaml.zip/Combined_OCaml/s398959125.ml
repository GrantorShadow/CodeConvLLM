open Batteries
class union_find n = object (self)
  val mutable par = ( [| |] : int array)
  method init = 
    par <- Array.init n (fun a -> a)
  method get_par = par

  method root s = 
    let rec loop x =
      if par.(x) = x then x else (par.(x) <- loop par.(x); par.(x))
    in loop s

  method rank s =
    let rec loop x n =
      if par.(x) = x then n else loop par.(x) (n+1)
    in loop s 1

  method unite x y =
    let xrank = self#rank x in
    let yrank = self#rank x in
    let rx = self#root x in
    let ry = self#root y in
    if rx != ry then (if xrank < yrank then par.(rx) <- ry else par.(ry) <- rx)

  method same x y = self#root x = self#root y

  method members x = (* 要素xが属する木の全ての要素を返す *) 
    let r = self#root x in Array.fold_left (fun a y -> if self#root y = r then y :: a else a) [] par

  method roots = (* 全ての根 *) Array.fold_left (fun x y -> if List.mem y x then x else y :: x) [] par

  method tree_count = (* 木の数 *) List.length @@ self#roots
end

let n, m = Scanf.sscanf (read_line()) "%d %d" (fun n m -> n,m)
let h = read_line () |> String.split_on_char ' ' |> List.map int_of_string |> Array.of_list

let tree = new union_find n
let _ = tree#init

let rec loop i =
  if i >= m then () else
  (
    Scanf.sscanf (read_line()) "%d %d" (fun a b -> tree#unite (a-1) (b-1)); loop (i+1)
  )

let _ = loop 0

let rec check_loop i ans =
  if i >= n then ans else (
    let i_height = h.(i) in
    let members = tree#members i in
    let rec check lst =
      match lst with
      | [] -> true
      | first :: rest ->
        if first = i then check rest else (
          if i_height <= h.(first) then false else check rest
        )
    in if check members then check_loop (i+1) (ans+1) else check_loop (i+1) ans
  )

let _ = Printf.printf "%d\n" ((check_loop 0 0) - 1)


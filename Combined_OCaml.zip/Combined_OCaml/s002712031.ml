open Str

let () =
  let (n, _) = Scanf.scanf "%d %d" (fun a b -> a, b) in
  let ai = List.map int_of_string (Str.split (Str.regexp "[^0-9]+") (read_line ())) in
  let sum = List.fold_left (+) 0 ai in
  if sum > n then
    print_int (-1)
  else
    print_int (n - sum)

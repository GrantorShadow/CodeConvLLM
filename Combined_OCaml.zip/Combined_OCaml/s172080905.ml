open Printf
open Scanf

let solve h1 m1 h2 m2 k = h2 * 60 + m2 - h1 * 60 - m1 - k

let () =
  scanf "%d %d %d %d %d " solve |> printf "%d\n"

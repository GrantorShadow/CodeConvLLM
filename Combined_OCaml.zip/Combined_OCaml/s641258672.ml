module IntSet = Set.Make (struct type t = int let compare = compare end)

let () =
  let n = Scanf.scanf "%d\n" (fun n -> n) in
  let as_ = Array.init n (fun _ -> Scanf.scanf "%d " (fun a -> a)) in
  Array.fold_left (fun (s, n) a ->
    if 1 <= a && a <= 399 then (IntSet.add 0 s, n)
    else if 400 <= a && a <= 799 then (IntSet.add 1 s, n)
    else if 800 <= a && a <= 1199 then (IntSet.add 2 s, n)
    else if 1200 <= a && a <= 1599 then (IntSet.add 3 s, n)
    else if 1600 <= a && a <= 1999 then (IntSet.add 4 s, n)
    else if 2000 <= a && a <= 2399 then (IntSet.add 5 s, n)
    else if 2400 <= a && a <= 2799 then (IntSet.add 6 s, n)
    else if 2800 <= a && a <= 3199 then (IntSet.add 7 s, n)
    else (s, n + 1)) (IntSet.empty, 0) as_
  |> (fun (s, n) -> (max 1 (IntSet.cardinal s), min 8 (IntSet.cardinal s + n)))
  |> (fun (max, min) -> Printf.printf "%d %d\n" max min)
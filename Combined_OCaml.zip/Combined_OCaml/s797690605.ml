let () =
  Scanf.scanf "%d" @@ fun l ->
  let a = Array.init (l+1) @@ fun i ->
    if i = 0 then 0
    else Scanf.scanf " %d" ((+) 0)
  in

  let dp = Array.init 5 (fun _ -> Array.make (l+1) 0) in

  for i = 1 to l do
    dp.(0).(i) <- dp.(0).(i-1) + a.(i);
  done;

  for i = 1 to l do
    dp.(1).(i) <- min dp.(0).(i) @@
      dp.(1).(i-1) + if a.(i) = 0 then 2 else a.(i) mod 2;
  done;

  for i = 1 to l do
    dp.(2).(i) <- min dp.(1).(i) @@
      dp.(2).(i-1) + (a.(i) + 1) mod 2;
  done;

  for i = 1 to l do
    dp.(3).(i) <- min dp.(2).(i) @@
      dp.(3).(i-1) + if a.(i) = 0 then 2 else a.(i) mod 2;
  done;

  for i = 1 to l do
    dp.(4).(i) <- min dp.(3).(i) @@ dp.(4).(i-1) + a.(i);
  done;

  Printf.printf "%d\n" dp.(4).(l)


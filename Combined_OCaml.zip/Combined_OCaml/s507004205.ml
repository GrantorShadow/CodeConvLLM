let check_bingo board hits =
  (* ビンゴ対象となる配列のインデックス *)
  let check_list = [[0;1;2]; [3;4;5]; [6;7;8]; [0;3;6]; [1;4;7]; [2;5;8]; [0;4;8]; [2;4;6]] in
  (* インデックスを値に変換 *)
  let rec get_cell board l cell_values =
    match l with
    | [] -> cell_values
    | x::xs ->
       get_cell board xs ((Array.get board x)::cell_values)
  in
  (* ある列/行/斜めがビンゴかチェック *)
  let is_bingo l hits = List.for_all (fun x -> (List.mem x hits)) l in
  let rec check_bingo_sub board l =
    match l with
    | [] -> "No"
    | x::xs ->
       let check_cell_list = get_cell board x [] in
       let result = is_bingo check_cell_list hits in
       if result then "Yes" else check_bingo_sub board xs
  in
  check_bingo_sub board check_list

(* 盤面入力 *)
let rec input_boards n board =
  match n with
  | 0 -> Array.of_list (List.rev board)
  | m ->
     let new_board = Scanf.scanf "%d %d %d\n" (fun a b c -> c :: b :: a :: board) in
     input_boards (m-1) new_board

(* 当たりの入力 *)
let rec input_hits n hits =
  match n with
  | 0 -> hits
  | m ->
     let input = read_int () in
     input_hits (m-1) (input::hits)

let _ =
  let board = input_boards 3 [] in
  let n_hit = read_int () in
  let hits  = input_hits n_hit [] in
  let ans = check_bingo board hits in
  print_endline ans

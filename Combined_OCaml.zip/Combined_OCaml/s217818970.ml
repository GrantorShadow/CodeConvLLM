Scanf.scanf "%d" (fun n ->
    let len = Array.make n 0 in
    for i = 1 to n do
        Scanf.scanf " %d" (fun p ->
            let p = p - 1 in
            len.(p) <- 1;
            if p > 0 && len.(p - 1) > 0 then (
                len.(p) <- len.(p - 1) + 1;
                len.(p - 1) <- 0
            )
        )
    done;
    Printf.printf "%d\n" @@ n - Array.fold_left max 0 len
)
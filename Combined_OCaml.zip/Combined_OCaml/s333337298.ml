Scanf.scanf "%d" (fun n ->
    let lr = Array.init n (fun i -> Scanf.scanf " %d %d" (fun l r -> l, r)) in

    let rec loop i bestl besti =
        if i = n then besti else
            let l, r = lr.(i) in
            if l > bestl then loop (i + 1) l i
                         else loop (i + 1) bestl besti
    in
    let p = loop 0 0 0 in
    let rec loop i bestr besti =
        if i = n then besti else
            let l, r = lr.(i) in
            if r < bestr then loop (i + 1) r i
                         else loop (i + 1) bestr besti
    in
    let q = loop 0 max_int 0 in
    let lp, rp = lr.(p) in
    let lq, rq = lr.(q) in

    let result = if p = q then (
        let l0, r0 = lr.(p) in
        let rec loop j acc =
            if j = n then acc + r0 - l0 + 1 else
            if j = p then loop (j + 1) acc else
                let l1, r1 = lr.(j) in
                loop (j + 1) (max acc (r1 - l1 + 1))
        in
        loop 0 0
    ) else (
        let work = Array.map (fun (l, r) -> max (r - lp + 1) 0, max (rq - l + 1) 0) lr in
        Array.sort (fun (a0, b0) (a1, b1) -> compare (a0, -b0) (a1, -b1)) work;
        let work2 = Array.init (n + 1) (fun _ -> [| 0; 0 |]) in
        work2.(0).(1) <- rq - lq + 1;
        work2.(n).(0) <- rp - lp + 1;
        for i = 1 to n do
            let _, b = work.(i - 1) in
            work2.(i).(1) <- min work2.(i - 1).(1) b;
        done;
        for i = n - 1 downto 0 do
            let a, _ = work.(i) in
            work2.(i).(0) <- min work2.(i + 1).(0) a;
        done;

        Array.fold_left (fun acc arr -> max acc (arr.(0) + arr.(1))) 0 work2
    )
    in
    Printf.printf "%d\n" result
)
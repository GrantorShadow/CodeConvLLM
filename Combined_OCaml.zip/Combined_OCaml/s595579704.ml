let () =
    let main () =
        let m = 1_000_000_000 + 7 in
        let (+@) a b = (a + b) mod m in
        let s = read_line () in
        let a = Array.make 13 0 in
        let l = String.length s in
        let rec loop i a =
            if i = l then a else
                let b = Array.make 13 0 in
                let () =
                    if s.[i] = '?' then (
                        for j = 0 to 12 do
                            for k = 0 to 9 do
                                b.((j * 10 + k) mod 13) <- b.((j * 10 + k) mod 13) +@ a.(j)
                            done
                        done
                    ) else (
                        let k = int_of_char s.[i] - int_of_char '0' in
                        for j = 0 to 12 do
                            b.((j * 10 + k) mod 13) <- b.((j * 10 + k) mod 13) +@ a.(j)
                        done
                    )
                in
                loop (i + 1) b
        in
        let a = loop 0 (Array.init 13 (fun i -> if i = 0 then 1 else 0)) in
        Printf.printf "%d\n" a.(5)
    in
    main ()
open Printf
open Scanf

let n, a = scanf "%d %d" (fun n a -> n, a)

let () =
  print_endline @@ if (n mod 500) <= a then "Yes" else "No"

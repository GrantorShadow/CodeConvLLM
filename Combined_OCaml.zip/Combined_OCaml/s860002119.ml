module M = Map.Make (struct type t = int let compare = compare end)
module S = Set.Make (struct type t = int let compare = compare end)

let () =
    let main () =
        let n = Scanf.sscanf (read_line ()) "%d" (fun n -> n) in
        let xy = Array.init n (fun _ -> Scanf.sscanf (read_line ()) "%d %d" (fun x y -> x, y)) in
        let xmap = Array.fold_left (fun map (x, y) ->
            M.add x (S.add y (try M.find x map with _ -> S.empty)) map) M.empty xy in
        let ymap = Array.fold_left (fun map (x, y) ->
            M.add y (S.add x (try M.find y map with _ -> S.empty)) map) M.empty xy in
        let cx = Array.make 100002 true in
        let cy = Array.make 100002 true in
        let rec dfs_x px set ax ay =
            cx.(px) <- false;
            S.fold (fun py ((ax, ay) as acc) ->
                if cy.(py) then dfs_y py (M.find py ymap) ax ay else acc) set (ax + 1, ay)
        and dfs_y py set ax ay =
            cy.(py) <- false;
            S.fold (fun px ((ax, ay) as acc) ->
                if cx.(px) then dfs_x px (M.find px xmap) ax ay else acc) set (ax, ay + 1)
        in
        let acc = M.fold (fun x set acc ->
            if cx.(x) && S.cardinal set > 0 then let sx, sy = dfs_x x set 0 0 in acc + sx * sy else acc) xmap 0 in
        let acc = M.fold (fun y set acc ->
            if cy.(y) && S.cardinal set > 0 then let sx, sy = dfs_y y set 0 0 in acc + sx * sy else acc) ymap acc in
        Printf.printf "%d\n" (acc - n)
    in
    main ()
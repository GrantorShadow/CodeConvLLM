module ISet=Set.Make(struct type t=int let compare=compare end);;
Array.(Scanf.scanf" %d %d %d %d %d %d"@@fun a b c d e f->
	let w =
		init (f/a/100+1) (fun i->
			init (f/b/100+1) (fun j->j))
		|>
		fold_left (fun (i,s) ar->
			i+1,snd @@ fold_left (fun (j,s) v->
				let w = 100*a*i+100*b*j in
				j+1,if w<=f then ISet.add w s else s
			) (0,s) ar
		) (0,ISet.empty) |> snd |> ISet.elements |> of_list
	in let s = 
		init (f/c+1) (fun i->
			init (f/d+1) (fun j->j))
		|>
		fold_left (fun (i,s) ar->
			i+1,snd @@ fold_left (fun (j,s) v->
				let w = c*i+d*j in
				j+1,if w<=f then ISet.add w s else s
			) (0,s) ar
		) (0,ISet.empty) |> snd |> ISet.elements |> of_list
	in
	fold_left (fun (d,p,q) w->
		let d',w,s = fold_left (fun (d,p,q) s->
			if w+s>f || w/100*e<s || w+s=0 then (d,p,q)
			else let d'=100. *. (float s) /. (float w +. float s) in
			if d'>d then (d',w,s) else (d,p,q)
		) (d,p,q) s in
		if d'>d then (d',w,s) else (d,p,q)
	) (0.,100*a,0) w
	|> (fun (d,w,s)->Printf.printf "%d %d\n" (w+s) s))
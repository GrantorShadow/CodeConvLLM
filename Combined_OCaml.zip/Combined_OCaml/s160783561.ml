let arr_of_str_i s = Array.init (String.length s) (fun i -> i, s.[i])
let () =
  let s = Scanf.scanf "%s" arr_of_str_i in
  let b = s
  |> Array.map (fun (i, c) -> Array.fold_left (fun b (j, d) -> b && (i = j || c <> d)) true s)
  |> Array.fold_left (&&) true in
  print_endline @@ if b then "yes" else "no"

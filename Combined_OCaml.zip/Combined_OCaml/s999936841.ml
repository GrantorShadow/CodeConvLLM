let a, b = Scanf.scanf "%f %f\n" @@ fun a b -> a, b
let ans = int_of_string (ceil ((a +. b) /. 2.))
let () = print_int ans
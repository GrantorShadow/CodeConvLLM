open Batteries
open BatPrintf

let scan fmt f =
  Scanf.sscanf (read_line ()) fmt f

let scan_list cnv =
  read_line ()
  |> String.split_on_char ' '
  |> List.map cnv

let scan_listn n cnv =
  (0 --^ n) /@ (fun _ -> (cnv % read_line) ())

let rec zip xs ys =
  match xs, ys with
  | [], _ -> []
  | _, [] -> []
  | x::xs, y::ys ->
    (x, y) :: zip xs ys

let n = scan "%d" identity
let s = scan_listn n identity

module SMap = Map.Make (struct
    type t = string
    let compare = String.IString.compare
  end)

let () =
  let map = fold (fun m k -> SMap.modify_opt k
                     (function
                       | None -> Some 0
                       | Some n -> Some (n + 1)) m) SMap.empty s in
  let m = SMap.fold (fun _ v m -> if v > m then v else m) map 0 in
  SMap.filter (fun _ n -> n = m) map
  |> SMap.keys
  |> List.of_enum
  |> List.sort String.compare
  |> String.concat "\n"
  |> printf "%s\n"

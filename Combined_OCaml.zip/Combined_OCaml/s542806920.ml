let rec print_array xs =
    let len = Array.length xs in
    if len = 0 then print_newline ()
    else if len = 1 then Printf.printf " %d\n" xs.(0)
    else (
        for i = 0 to len - 1 do
            Printf.printf " %d" xs.(i);
        done;
        print_newline ();
    )
;;
 
let make_house () = Array.make_matrix 3 10 0
 
let () = 
    let house = [| make_house (); make_house (); make_house (); make_house ();|] in
    let n = Scanf.scanf "%d\n" (fun x -> x) in
    for _ = 1 to n do
        let (b, f, r, v) = Scanf.scanf "%d %d %d %d\n" (fun a b c d -> (a - 1, b - 1, c - 1, d)) in
        house.(b).(f).(r) <- house.(b).(f).(r) + v;
    done;
    for i = 0 to 3 do
        for j = 0 to 2 do
            print_array house.(i).(j);
        done;
        print_endline "####################";
    done;
;;

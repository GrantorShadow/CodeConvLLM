module Matrix =
  struct
    type t = {a: float; b: float; c: float; d: float}
    let init a b c d = {a = a; b = b; c = c; d = d}
    let mul m1 m2 = init (m1.a *. m2.a +. m1.b *. m2.c) (m1.a *. m2.b +. m1.b *. m2.d) (m1.c *. m2.a +. m1.d *. m2.c) (m1.c *. m2.b +. m1.d *. m2.d)
    let inv m =
      let det = m.a *. m.d -. m.b *. m.c in
      init (m.d /. det) ((-1.0) *. m.b /. det) ((-1.0) *. m.c /. det) (m.a /. det)
  end

let id x = x

let solve x1 y1 x2 y2 x3 y3 =
  let stm = Matrix.mul (Matrix.inv (Matrix.init (y1 -. y2) (y3 -. y1) (x2 -. x1) (x1 -. x3))) (Matrix.init (0.5 *. (x3 -. x2)) (0.0) (0.5 *. (y3 -. y2)) (0.0)) in
  let cx = x1 +. 0.5 *. (x2 -. x1) +. stm.Matrix.a *. (y1 -. y2) in
  let cy = y1 +. 0.5 *. (y2 -. y1) +. stm.Matrix.a *. (x2 -. x1) in
  let r = sqrt ((cx -. x1) ** 2.0 +. (cy -. y1) ** 2.0) in
  (cx, cy, r)

let _ = 
  let n = Scanf.scanf "%d\n" id in
  let rec loop n = 
    if n = 0 then ()
    else
      begin
        let cx, cy, r = Scanf.scanf "%f %f %f %f %f %f\n" solve in
        Printf.printf "%.3f %.3f %.3f\n" cx cy r;
        loop (n - 1)
      end
  in loop n
let () =
  Scanf.scanf "%d\n"
    (fun x -> if x = 3 || x = 5 || x = 7 then "YES" else "NO") |> print_string

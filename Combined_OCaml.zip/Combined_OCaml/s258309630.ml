let () =
  let n = Scanf.sscanf (input_line stdin) "%d" (fun a -> a) in
  let x1 = float_of_int n /. 1.08 in
  let x1' = int_of_float x1 in
  let x2' = x1' + 1 in
  let ans =
    if int_of_float (float_of_int x1' *. 1.08) = n then string_of_int x1' 
    else if int_of_float (float_of_int x2' *. 1.08) = n then string_of_int x2'
    else ":("
  in
  print_string ans;
  print_newline ()

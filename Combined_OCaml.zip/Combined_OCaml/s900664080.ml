open Printf
open Scanf

let primes = Array.make 1000000 0;;
let np = ref 0;;

let input_int () =
  scanf "%d\n" (fun k -> k)

let is_prime k =
  let n = !np in
  let rec loop i =
    if i=n then
      true
    else if k mod primes.(i) = 0 then
      false
    else
      loop (i+1)
  in
  loop 0

let next_prime () =
  let n = !np in
  let rec loop k =
    if is_prime k then
      begin
        primes.(n) <- k;
        np := n + 1;
        k
      end
    else
      loop (k+2)
  in
  loop primes.(n-1)

let find_pow n p =
  let rec loop c k =
    if k mod p = 0 then
      loop (c+1) (k / p)
    else
      (c, k)
  in
  loop 0 n

let find_factor m =
  let n = !np in
  let rec loop2 () =
    let x = next_prime () in
    if m mod x = 0 then
      x
    else
      loop2 ()
  in
  let rec loop i =
    if i=n then
      loop2 ()
    else if m mod primes.(i) = 0 then
      primes.(i)
    else
      loop (i+1)
  in
  loop 0

let h n =
  let rec loop c k =
    if k=1 then
      c
    else
      let p = find_factor k in
      let (m, k) = find_pow k p in
      loop ((m + 1) * c) k
  in
  if n mod 2 = 0 then
    let (m, n) = find_pow n 2 in
    loop (m + 1) n
  else
    loop 1 n
      
let f () =
  let n = input_int () in
  let rec loop tot c =
    (* printf "%d\n" c; *)
    if c = n then
      tot
    else
      loop (tot + h (n - c)) (c+1)
  in
  loop 0 1

let () =
  primes.(0) <- 2;
  primes.(1) <- 3;
  np := 2;
  let tot = f () in
  printf "%d\n" tot

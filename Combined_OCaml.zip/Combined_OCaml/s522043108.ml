open Printf
open Scanf

module IntSet = Set.Make(struct type t = int let compare = compare end)

let solve n =
  let f s x = IntSet.add x s in
  let st = Array.fold_left f IntSet.empty @@ Array.init n @@ fun _ -> scanf "%d " @@ fun x -> x in
  if IntSet.cardinal st = n then "YES" else "NO"

let () =
  scanf "%d " solve |> printf "%s\n"

Scanf.sscanf (read_line ()) "%d %d"
(fun x a -> Printf.printf "%d\n" (if x < a then 0 else 10))
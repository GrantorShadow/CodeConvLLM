open Printf
open Scanf

let id x = x

let n, m, k = scanf "%d %d %d\n" (fun n m k -> n, m, k)
let aa = Array.init n (fun i -> scanf "%d " id)
let bb = Array.init m (fun i -> scanf "%d " id)

exception Break

let main () =
    let ai = ref 0 in
    let bi = ref 0 in
    let result = ref 0 in
    let total = ref 0 in
    try
        while true do
            if !ai < n && !bi < m then begin
                let ta = aa.(!ai) in
                let tb = bb.(!bi) in
                if ta = tb then begin
                    let aii = ref (!ai + 1) in
                    let bii = ref (!bi + 1) in
                    let aIsSmaller = ref true in
                    try
                        while true do 
                            if !aii = n && !bii = m then
                                raise Break
                            else if !aii < n && !bii = m then
                                raise Break
                            else if !aii = n && !bii < m then begin
                                aIsSmaller := false;
                                raise Break
                            end else if aa.(!aii) < bb.(!bii) then
                                raise Break
                            else if aa.(!aii) > bb.(!bii) then begin
                                aIsSmaller := false;
                                raise Break
                            end else begin
                                incr aii;
                                incr bii
                            end
                        done
                    with
                        Break -> begin
                            if !aIsSmaller then begin
                                if !total + ta <= k then begin
                                    total := !total + ta;
                                    incr ai;
                                    incr result
                                end else begin
                                    raise Break
                                end
                            end else begin
                                if !total + tb <= k then begin
                                    total := !total + tb;
                                    incr bi;
                                    incr result
                                end else begin
                                    raise Break
                                end
                            end
                        end
                end else if ta < tb then begin
                    if !total + ta <= k then begin
                        total := !total + ta;
                        incr ai;
                        incr result
                    end else begin
                        raise Break
                    end
                end else begin
                    if !total + tb <= k then begin
                        total := !total + tb;
                        incr bi;
                        incr result
                    end else begin
                        raise Break
                    end
                end
            end else if !ai < n && !bi = m then begin
                let ta = aa.(!ai) in
                if !total + ta <= k then begin
                    total := !total + ta;
                    incr ai;
                    incr result
                end else begin
                    raise Break
                end
            end else if !ai = n && !bi < m then begin
                let tb = bb.(!bi) in
                 if !total + tb <= k then begin
                    total := !total + tb;
                    incr bi;
                    incr result
                end else begin
                    raise Break
                end
            end else begin
                raise Break
            end
        done
    with
        Break ->
            Printf.printf "%d\n" !result

let () = main ()

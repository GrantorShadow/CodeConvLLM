let bin_search x ary =
  let rec doit l r =
    if l >= r then false
    else begin
      let m = (l + r) / 2 in
      if x = ary.(m) then true
      else if x < ary.(m) then doit l m
      else doit (m + 1) r
    end
  in
  doit 0 (Array.length ary)

let () =
  let read_seq () = List.map int_of_string (Str.split (Str.regexp " ") (read_line ())) in
  let _ = read_int () in
  let s = Array.of_list (read_seq ()) in
  let _ = read_int () in
  let t = read_seq () in
  Printf.printf "%d\n" (List.fold_left (fun acc e -> acc + (if bin_search e s then 1 else 0)) 0 t)
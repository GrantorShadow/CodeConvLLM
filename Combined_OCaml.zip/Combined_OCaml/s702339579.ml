let id x = x

let s = 1000000007

let repeat f =
  let rec aux accu = function
    | 0 -> accu
    | n -> aux (f () :: accu) (n - 1) in
  aux []

let pow k =
  let rec aux accu k = function
  | 0 -> accu
  | n when n mod 2 == 0 -> aux accu (k*k mod s) (n/2)
  | n -> aux (accu*k mod s) (k*k mod s) (n/2) in
  aux 1 k

let inv k = pow k (s-2)

let rec bc n = function 0 -> 1 | k -> ((bc (n-1) (k-1))*(n*inv(k) mod s) mod s)

let () =
  let n = Scanf.scanf "%d\n" id in
  let l = repeat (fun () -> Scanf.scanf "%d %d\n" (fun a b -> (a,b))) n in
  let (maxa, maxb) = List.fold_left (fun (c,d) (a,b) -> (max a c, max d b)) (0, 0) l in
  let sal = List.sort (fun (a,b) (c,d) -> compare c a) l in
  let dp = Array.make (1 + 2 * maxb) 0 in
  let solve =
    let rec auxr sl accu m =
      match sl with
      | [] -> accu
      | (a, b) :: tl when a = m-maxa -> auxr tl ((accu+dp.(b+maxb)) mod s) m
      | _ -> Array.iteri (fun i x -> dp.(i) <- (x + if i > 0 then dp.(i-1) else 0) mod s) dp; auxr sl accu (m+1) in
    let rec auxl sl m =
      if m > maxa then (Array.iteri (fun i x -> dp.(i) <- (x + if i > 0 then dp.(i-1) else 0) mod s) dp; auxr (List.rev sal) 0 m)
        else match sl with
             | (a, b) :: tl when a = maxa-m -> dp.(maxb-b) <- (dp.(maxb-b) +1) mod s; auxl tl m
             | _ -> Array.iteri (fun i x -> dp.(i) <- (x + if i > 0 then dp.(i-1) else 0) mod s) dp; auxl sl (m+1) in
    auxl sal 0 in
  let x = List.fold_left (fun x (a,b) -> (x + bc (2*a+2*b) (2*a)) mod s) 0 l in
    if solve < x then print_int ((s+solve - x)/2) else print_int ((solve-x)/2);
module Geometry = struct

  type t = { x : float; y : float }

  let make x y = { x; y }

  let eps = 1e-10

  let diff a b = { x = a.x -. b.x; y = a.y -. b.y }

  let norm p = p.x *. p.x +. p.y *. p.y

  let dot a b = a.x *. b.x +. a.y *. b.y

  let cross a b = a.x *. b.y -. a.y *. b.x

  let ccw p0 p1 p2 =
    let a = diff p1 p0 in
    let b = diff p2 p0 in
    let c = cross a b in
    if c > eps then 1 (* COUNTER_CLOCKWISE *)
    else if c < (-. eps) then (-1) (* CLOCKWISE *)
    else if dot a b < (-. eps) then 2 (* ONLINE_BACK *)
    else if norm a < norm b then (-2) (* ONLINE_FRONT *)
    else 0 (* ON_SEGMENT *)

  let convex_p p0 p1 p2 p3 =
    let c = ccw p0 p1 p2 in
    List.for_all (fun e -> c = e) [ccw p1 p2 p3; ccw p2 p3 p0; ccw p3 p0 p1]

end

module G = Geometry

let () =
  try
    while true do
      let (xa, ya, xb, yb, xc, yc, xd, yd) =
        Scanf.scanf "%f,%f,%f,%f,%f,%f,%f,%f " (fun xa ya xb yb xc yc xd yd ->
          xa, ya, xb, yb, xc, yc, xd, yd) in
      print_endline
        (if G.convex_p (G.make xa ya) (G.make xb yb) (G.make xc yc) (G.make xd yd)
         then "YES"
         else "NO")
    done
  with _ -> ()
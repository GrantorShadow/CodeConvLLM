open Printf
open Scanf
let bcr x y z = 
	if x < y && y < z then printf "Yes\n" 
	else printf "No\n";;
scanf "%d %d %d" bcr;;
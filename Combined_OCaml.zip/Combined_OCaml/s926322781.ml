let cube n =
    int_of_float (float_of_int(n) ** 3.0)

let n = read_int () ;;
Printf.printf "%d\n" (cube n) ;;
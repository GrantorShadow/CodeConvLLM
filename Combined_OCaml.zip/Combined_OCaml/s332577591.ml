let id x = x
let n = Scanf.scanf "%d" id

let rec power n x =
if n = 0 then x else power (n-1) (x*n mod 1000000007) 

let ans = power n 1

let () = Printf.printf "%d\n" ans
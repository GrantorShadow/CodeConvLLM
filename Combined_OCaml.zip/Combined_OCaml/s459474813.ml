type tree = Nil | Node of int * tree * tree

let create () = Nil

let insert x t =
  let rec doit = function
    | Nil -> Node (x, Nil, Nil)
    | Node (y, l, r) when x < y -> Node (y, doit l, r)
    | Node (y, l, r) -> Node (y, l, doit r)
  in doit t

let preorder f t =
  let rec doit = function
    | Nil -> ()
    | Node (x, l, r) -> (f x; doit l; doit r)
  in doit t

let inorder f t =
  let rec doit = function
    | Nil -> ()
    | Node (x, l, r) -> (doit l; f x; doit r)
  in doit t

let print t =
  let f e = print_string " "; print_int e in
  inorder f t;
  print_newline ();
  preorder f t;
  print_newline ()

let split str delim =
  let open String in
  let rec doit s acc =
    match
      try Some (rindex s delim) with _ -> None
    with
    | None -> s :: acc
    | Some i ->
        let s1 = sub s 0 i in
        doit s1 (sub s (i + 1) (length s - length s1 - 1) :: acc)
  in doit str []

let () =
  let m = read_int () in
  let rec read i t =
    if i < m then begin
      match split (read_line ()) ' ' with
      | ["print"] -> (print t; read (i + 1) t)
      | ["insert"; n] -> read (i + 1) (insert (int_of_string n) t)
      | _ -> ()
    end in
  read 0 (create ())
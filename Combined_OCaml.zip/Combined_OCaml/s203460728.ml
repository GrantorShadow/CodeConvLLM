open Batteries

let sqrt_int x = int_of_float @@ sqrt @@ float_of_int x

let nearest x =
  let rec pow i  =
    if i * i <=  x then pow @@ succ i
    else
      let p = pred i in
      ( * ) p p in
  let rec aux i =
    if i == 1 then 1
    else
      aux @@ pred i
      |> max @@ pow i in
  aux @@ sqrt_int x

let main () =
  int_of_string @@ input_line stdin
  |> nearest
  |> print_int

let () = main ()

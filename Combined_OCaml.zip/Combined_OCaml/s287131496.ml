let () =
  Scanf.scanf "%s %s" (fun a b -> match String.compare a b with
  | _ when String.length a < String.length b -> "LESS"
  | _ when String.length a > String.length b -> "GREATER"
  | -1 -> "LESS"
  | 1 -> "GREATER"
  | _ -> "EQUAL") |> print_endline

let m a b = a mod b + if a mod b < 0 then abs b else 0
let rec f n a = if n = 0 then a else f ((n - m n ~-2) / -2) (m n ~-2 :: a)
let _ = print_newline @@ match f (read_int ()) [] with [] -> print_int 0 | a -> List.iter print_int a
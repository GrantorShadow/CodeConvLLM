let cul a op b = match op with
    '+' -> Printf.printf "%d\n" (a + b)
  | '-' -> Printf.printf "%d\n" (a - b)
  | '*' -> Printf.printf "%d\n" (a * b)
  | '/' -> Printf.printf "%d\n" (a / b)
  | _ -> raise Not_found ;;
let checker a op b = (op <> '?') ;;
let parrot () =
  let s = ref "" in
  while (s := read_line(); (Scanf.sscanf !s "%d %c %d" checker))
  do
    Scanf.sscanf !s "%d %c %d" cul
  done ;;
parrot();;

let (+@) a b = (a + b) mod 1000000007
let rec f xs v =
  if v = 0 then xs else f (v mod 2 :: xs) (v / 2)

let solve n =
  let d = f [] n in
  let x, y, z = List.fold_left (fun (x,y,z) b ->
    if b = 0 then
      (x +@ y, y, y +@ 3 * z)
    else
      (x, x +@ y, 2 * y +@ 3 * z)
    ) (1,0,0) d
  in x +@ y +@ z

let () = Scanf.scanf "%d" solve |> Printf.printf "%d\n"
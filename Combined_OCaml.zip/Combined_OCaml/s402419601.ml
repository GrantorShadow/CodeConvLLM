let () =
    let main () =
        let a = Scanf.sscanf (read_line ()) "%d" (fun a -> a) in
        let n = 3 * a * a in
        Printf.printf "%d\n" n
    in
    main ()
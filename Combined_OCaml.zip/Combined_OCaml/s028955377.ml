open Array
let () =
  let arr = List.concat (to_list (init 3 @@ fun _ -> Scanf.scanf "%d %d %d\n" @@ fun a b c -> [a; b; c])) in
  let n = read_int () in
  let brr = Array.init n @@ fun _ -> Scanf.scanf "%d\n" @@ fun d -> d in
  let check = Array.make_matrix 3 3 false in
  for i = 0 to n-1 do
    let x = brr.(i) in
    if List.mem x arr then List.iteri (fun i a -> if a = x then check.(i / 3).(i mod 3) <- true) arr
  done;
  let ans = ref false in
  for i = 0 to 2 do
    if check.(i).(0) && check.(i).(1) && check.(i).(2) then ans := true (* 横 *)
    else if check.(0).(i) && check.(1).(i) && check.(2).(i) then ans := true (* たて *)
  done;
  if check.(0).(0) && check.(1).(1) && check.(2).(2) then ans := true;
  if check.(0).(2) && check.(1).(1) && check.(2).(0) then ans := true;
  print_endline (if !ans then "Yes" else "No")
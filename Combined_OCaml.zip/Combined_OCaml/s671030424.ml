open Printf
open Scanf

let solve n k = if n mod k = 0 then 0 else 1

let () =
  scanf "%d %d " solve |> printf "%d\n"

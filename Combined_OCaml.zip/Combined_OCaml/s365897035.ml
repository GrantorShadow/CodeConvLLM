let n = read_int ()
let s = read_line ()
let t, u = ref s, ref ""
let f s x = let n = ref 0 in String.iter (fun c -> if c = x then incr n) s; !n
let l, r = while !u <> !t do u := !t; t := Str.(global_replace (regexp "()") "" !u) done; f !t ')', f !t '('
let _ = String.(Printf.printf "%s%s%s\n" (make l '(') s (make r ')'))
let s = read_line ()
let ans = ref max_int
let _ = for i = 0 to String.length s - 3 do ans := min !ans @@ abs @@ 753 - int_of_string (String.sub s i 3) done; Printf.printf "%d\n" !ans
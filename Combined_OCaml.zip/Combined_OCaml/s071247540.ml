let () =
	let n, k, x, y = Scanf.scanf "%d\n%d\n%d\n%d\n" (fun a b c d -> a,b,c,d) in
    Printf.printf "%d\n" ((if n<=k then 0 else (n-k)*y) + n*x)
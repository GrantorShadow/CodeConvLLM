open Printf
open Scanf

let solve r1 r2 = r1 *. r2 /. (r1 +. r2)

let () =
  scanf "%f %f " solve |> printf "%.10f\n"

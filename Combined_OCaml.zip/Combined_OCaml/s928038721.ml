let () = Scanf.scanf "%d %d\n" @@ fun n m -> print_int @@
  let sum = ref 0 in
  for i=1 to m do
    if i<m 
    then Scanf.scanf " %d" @@ fun a -> sum := !sum + a
    else Scanf.scanf " %d\n" @@ fun a -> sum := !sum + a
  done;
  if !sum <= n
  then n - !sum
  else -1
    
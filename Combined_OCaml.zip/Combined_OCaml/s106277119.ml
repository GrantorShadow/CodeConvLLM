let calc a b c = List.fold_left2 (fun x y z -> x + y * z) c a b
let () =
  try
    let (n, m, c) = Scanf.scanf "%d %d %d\n" (fun a b c -> (a, b, c)) in
    let b = Array.to_list
        (Array.init m (fun _ -> Scanf.scanf "%d " (fun x -> x))) in
    let a = Array.to_list
        (Array.init (n-1) (fun _ -> Array.to_list (Array.init m (fun _ -> Scanf.scanf "%d " (fun x -> x))))) in
    List.length (List.filter (fun lst -> calc lst b c > 0) a) |> print_int
  with
    End_of_file -> ()

let answer a b =
  let sa = a - b in
    if (sa mod 2) = 1 then
      "IMPOSSIBLE"
    else
      if sa < 0 then
        sa / 2 * (-1) |> string_of_int
      else
        sa / 2 |> string_of_int


let () = Scanf.scanf "%d %d" (fun a b -> print_endline (answer a b))

let rec gcd n m =
  if m = 0 then n
  else gcd m (n mod m)

let lcm a b = a / gcd a b * b

let () = Scanf.scanf "%d\n" @@ fun n ->
  let ts = Array.init n @@ fun _ ->
    Scanf.scanf "%d\n" @@ fun t -> t in
  Printf.printf "%d\n" @@ Array.fold_left lcm 1 ts


Scanf.scanf "%d" (fun n ->
    let a = Array.init n (fun i -> Scanf.scanf " %d" (fun a -> a, i)) in
    Array.sort (fun a b -> compare b a) a;

    let dp = Array.make_matrix (n + 1) n 0 in

    Array.iteri (fun i (act, pos) ->
        for j = 0 to i do
            dp.(i + 1).(j    ) <- max dp.(i + 1).(j)     (dp.(i).(j) + abs (pos - (n - 1 - i + j)) * act);
            if j + 1 < n then
            dp.(i + 1).(j + 1) <- max dp.(i + 1).(j + 1) (dp.(i).(j) + abs (pos - j) * act)
        done
    ) a;
    Array.fold_left max 0 dp.(n) |> Printf.printf "%d\n"
)
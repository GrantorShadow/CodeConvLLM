let n = read_int ()

let rec read_ints accu = function
  | 0 -> List.rev accu
  | k -> read_ints ((Scanf.scanf " %d" (fun x -> x)) :: accu) (k-1)

let a = read_ints [] (2*n-1)

let max3 a b c = max (max a b) c
let min3 a b c = min (min a b) c

let median a b c = a + b + c - (max3 a b c) - (min3 a b c)

let rec medians a b = function
  | [] -> []
  | hd :: tl -> (median a b hd) :: (medians b hd tl)


let rec top = function
  | [] -> 0
  | [a] -> a
  | a :: b :: tl -> top (medians a b tl)


let () = print_int (top a)

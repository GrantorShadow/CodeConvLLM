Scanf.scanf "%d %d %d %d" (fun n m x y ->
    let xx = Array.init n (fun _ -> Scanf.scanf " %d" (fun xx -> xx)) in
    let yy = Array.init m (fun _ -> Scanf.scanf " %d" (fun yy -> yy)) in
    Array.sort compare xx;
    Array.sort compare yy;
    let z = min yy.(0) y in
    print_endline @@
    if x < z && z <= y && yy.(0) >= z && xx.(n - 1) < z then "No War" else "War"
)
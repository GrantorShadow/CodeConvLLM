let solve a b =
  match a, b with
    1, 1 -> "Draw"
  | 1, b -> "Alice"
  | a, 1 -> "Bob"
  | _, _ -> if a > b then "Alice"
            else if a = b then "Draw"
            else "Bob";;

let a, b = Scanf.bscanf Scanf.Scanning.stdin "%d %d" (fun x y -> x, y);;

print_string (solve a b);
print_newline ()

let rec floor_sqrt acc acc_x_2_x_r sq_acc_minus_z r sq_r =
  if r = 0 then acc
  else
    let sq_acc_minus_z' = sq_acc_minus_z + acc_x_2_x_r + sq_r in
    ( if sq_acc_minus_z' <= 0 then
        floor_sqrt (acc + r) ((acc_x_2_x_r lsr 1) + sq_r) sq_acc_minus_z'
      else
        floor_sqrt acc (acc_x_2_x_r lsr 1) sq_acc_minus_z) (r lsr 1) (sq_r lsr 2)
let floor_sqrt z = floor_sqrt 0 0 (~-z) (1 lsl 30) (1 lsl 60)

let () = Scanf.scanf "%d %d\n" @@ fun n d ->
  let xss =
    Array.init n @@ fun _ ->
      Array.init d @@ fun _ -> Scanf.scanf "%d " @@ fun x -> x in
  Printf.printf "%d\n" @@ 
  Array.fold_left (Array.fold_left ( + )) 0 @@
  Array.init n @@ fun i ->
    Array.init i @@ fun j ->
      let sqd = 
        Array.fold_left ( + ) 0 @@ 
        Array.init d @@ fun k ->
          (xss.(i).(k) - xss.(j).(k)) * (xss.(i).(k) - xss.(j).(k)) in
      let d = floor_sqrt sqd in
      if d * d = sqd then 1 else 0


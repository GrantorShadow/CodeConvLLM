module M = Map.Make (struct type t = int let compare (a:int) (b:int) = compare a b end)

let () =
    let split s =
        let rec loop i cur flag acc =
            if i = String.length s then ( if flag then cur :: acc else acc) else ( match flag, s.[i] with
                | true,  ' ' -> loop (i + 1) "" false (cur :: acc)
                | false, ' ' -> loop (i + 1) "" false acc
                | true,  v   -> loop (i + 1) (Printf.sprintf "%s%c" cur v) true acc
                | false, v   -> loop (i + 1) (Printf.sprintf "%s%c" cur v) true acc
            )
        in
        List.map int_of_string (List.rev (loop 0 "" false []))
    in
    let m = 1 lsl 20 in
    let main () =
        let n = int_of_string (read_line ()) in
        let p = Array.of_list (split (read_line ())) in
        let rec loop i map acc =
            if i = n then acc else
                let next = M.fold (fun org v next ->
                    let first = org / m in
                    let second = org mod m in
                    let key = if p.(i) > first then p.(i) * m + first else
                        if p.(i) > second then first * m + p.(i) else org
                    in
                    M.add key (v + try M.find key next with _ -> 0) next) map M.empty
                in
                let acc = acc + M.fold (fun org v acc -> (org mod m) * v + acc) next 0 in
                loop (i + 1) (M.add (p.(i) * m) 1 next) acc
        in
        let r = loop 1 (M.singleton (p.(0) * m) 1) 0 in
        Printf.printf "%d\n" r
    in
    main ()
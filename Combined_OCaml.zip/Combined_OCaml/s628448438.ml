open Batteries
let contests = Array.init 26 @@ fun a -> String.of_seq @@ List.to_seq ['A'; char_of_int (65+a); 'C']
let d = read_int ()
let c = read_line () |> String.split_on_char ' ' |> List.map int_of_string |> Array.of_list

let sort x y = if x.(0) < y.(0) then -1 else 1

(* 最後の26日間に使うやつ *)
(* let c2 = List.sort sort @@  List.init d @@ fun o -> [|c.(o); o|] *)

let s = Array.make_matrix (d+1) 27 0
let rec s_loop i =
  if i >= d then () else (
    let rec loop lst i2 =
      match lst with
      | [] -> ()
      | first :: rest -> s.(i).(i2) <- first; loop rest (i2+1)
    in loop (read_line () |> String.split_on_char ' ' |> List.map int_of_string) 0; s_loop (i+1)
  )

let rec c_where i day item =
  if i >= 26 then "" else
  if s.(day).(i) = item then contests.(i) else c_where (i+1) day item


(* listのmax *)
let max_ lst_ = 
  let rec search_max lst value = 
    match lst with
     [] -> value
    | first :: rest -> if first > value then search_max rest first else search_max rest value
  in search_max lst_ 0

let _ = s_loop 0
let last_day = Array.init d @@ fun _ -> 0
let rec day_loop day =
  if day >= d then () else (
    let m = max_ @@ Array.to_list s.(day) in
    print_endline @@ c_where 0 day m; day_loop (day+1)
  )

let _ = day_loop 0
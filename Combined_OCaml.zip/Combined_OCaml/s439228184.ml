let ms = Array.make_matrix 51 51 ~-1
let rec c n k = if ms.(n).(k) > -1 then ms.(n).(k) else (ms.(n).(k) <- if n < k then 0 else if n = k then 1 else if k = 0 then 1 else c (n - 1) (k - 1) + c (n - 1) k; ms.(n).(k))
let a, b, vs = Scanf.(scanf "%d %d %d" @@ fun n a b -> a - 1, b - 1, Array.init n @@ fun _ -> scanf " %d" (+) 0)
let m, s = Array.(sort (fun x y -> y - x) vs; vs.(0), sub vs 0 (a + 1))
let f = Array.(fold_left (fun c v -> if v = vs.(a) then c + 1 else c)) 0
let t = f vs
let _ = Array.(Printf.printf "%.6f\n%d\n" (float (fold_left (+) 0 s) /. (float a +. 1.)) @@ if vs.(a) = m then let s = ref 0 in for i = a + 1 to b + 1 do s := !s + c t i done; !s else c t (f s))
let () =
  let rec f i j = match i with
    | 0 -> ""
    | _ -> (if j = 0 then "#" else ".") ^ f (i-1) ((j+1) mod 2) in
  let rec loop () = 
    let h, w = Scanf.scanf "%d %d\n" (fun h w -> h, w) in
    if h = 0 && w = 0 then ()
    else
      (for i = 1 to h do
        print_endline (f w ((i+1) mod 2))
      done;
      print_endline "";
      loop ())
  in loop ()
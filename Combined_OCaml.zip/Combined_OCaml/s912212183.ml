open Batteries

let solve lst =
  let rec solve_loop (a, b) = function
    | [] -> a + b
    | first :: xs ->
        let (x, y) = first in
        let ratio = max ((a-1)/x+1) ((b-1)/y+1) in
        solve_loop (x*ratio,y*ratio) xs
  in
  solve_loop (1,1) lst

let () =
  IO.lines_of stdin
  |> Enum.skip 1
  |> Enum.map (fun l -> Scanf.sscanf l "%d %d" (fun x y -> (x, y)))
  |> List.of_enum
  |> solve
  |> Int.print stdout

let rec pow n = function 1 -> n | m -> n * pow n (m-1)
let _ = Scanf.scanf "%d %d" (fun d n -> if d = 0 then n else (pow 100 d) * n) |> Printf.printf "%d"
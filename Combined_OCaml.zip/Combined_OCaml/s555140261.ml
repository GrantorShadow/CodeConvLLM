let rec solve i n = function
  | [] | [_] -> n
  | p :: p' :: ps ->
      if i = p then
        solve (i + 1) (n + 1) (p :: ps)
      else
        solve (i + 1) n (p' :: ps)
let solve = solve 1 0

let () =
  let n = Scanf.scanf "%d\n" (fun n -> n) in
  let ps = Array.to_list @@ Array.init n (fun _ -> Scanf.scanf "%d " (fun p -> p)) in
  Printf.printf "%d\n" @@ solve ps
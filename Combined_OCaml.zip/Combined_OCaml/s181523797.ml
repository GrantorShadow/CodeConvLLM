let () = Scanf.scanf "%d %d\n" @@ fun n k ->
  let hs = Array.init n @@ fun _ -> Scanf.scanf "%d " @@ fun h -> h in
  Array.sort compare hs;
  Printf.printf "%d\n" @@ 
  Array.fold_left ( + ) 0 @@
  Array.init (max 0 (n - k)) @@ fun i -> hs.(i)

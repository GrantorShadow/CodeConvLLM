let rec lenN n =
  if n = 0 then 1
  else 3 + 2 * lenN (n - 1)

let rec lenB n =
  if n = 0 then 0
  else 2 + 2 * lenB (n - 1)

let lenP n =
  lenN n - lenB n

let rec calc n x =
  if x <= n then 0
  else if x >= (lenN n - 1) / 2 then
  1 + lenP (n-1) + calc (n-1) (x-((lenN n - 1)/2)-1)
  else calc (n-1) (x-1)

let () =
  Scanf.scanf "%d %d" (fun n x ->
      let ans =
        calc n x
      in
      Printf.printf "%d" ans
    )

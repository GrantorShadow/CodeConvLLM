open Batteries
let n = read_int ()
let a = read_line () |> String.split_on_char ' ' |> List.map int_of_string
let q = read_int ()

let dp = Array.init 100010 @@ fun _ -> 0
let rec dp_loop lst result =
  match lst with
  | [] -> result
  | first :: rest -> dp.(first) <- dp.(first)+1; dp_loop rest (result+first)
let all = dp_loop a 0

let rec q_loop i now_all =
  if i >= q then () else (
    Scanf.sscanf (read_line()) "%d %d" (fun b c -> 
    let new_all = (now_all - (dp.(b)*b) - (dp.(c)*c) + ((dp.(b)+dp.(c))*c)) in
      Printf.printf "%d\n" new_all;
      (* Printf.printf "dp(b)*b: %d, dp(b): %d\n" (dp.(b)*b) (dp.(b));
      Printf.printf "dp(c)*c: %d, dp(c): %d\n" (dp.(c)*c) dp.(c); *)
      dp.(c) <- dp.(c) + dp.(b);
      dp.(b) <- 0;
      q_loop (i+1) new_all
    )
  )

let _ = q_loop 0 all
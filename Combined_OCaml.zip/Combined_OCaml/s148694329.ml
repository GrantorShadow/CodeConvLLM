let s = read_line ()
let _ = print_endline @@ if String.length s >= 4 && String.sub s 0 4 = "YAKI" then "Yes" else "No"
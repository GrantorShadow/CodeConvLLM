open List


let read () =  
  let open Scanf in
  let rec reads n ls =
    if n = 1 then scanf "%s\n" (fun x -> float_of_string x :: ls)
    else let x = scanf "%s " float_of_string in reads (n - 1) (x :: ls) in
  let n = scanf "%s\n" int_of_string in
  let ts = rev @@ reads n [] in
  let vs = rev @@ reads n [] in n, ts, vs

let rec mkfs ts vs t_cur =
  match ts, vs with
  | [], [] -> []
  | t::ts, v::vs -> 
    (fun x -> if x < t_cur then v +. t_cur -. x
      else if x > t_cur +. t then v -. t_cur -. t +. x 
      else v) :: mkfs ts vs (t_cur +. t)
  | _, _ -> failwith "die"

let () =
  let n, ts, vs = read () in
  let t_sum = fold_left (+.) 0. ts in
  let fs = (fun x -> x) :: ((mkfs ts vs 0.) @ [fun x -> t_sum -. x]) in 
  let calc_min x fs = fold_left (fun acc f -> min acc (f x)) 500. fs in
  let rec calc x sum vo vn =
    if x +. 0.5 > t_sum then sum else
      calc (x +. 0.5) (sum +. 0.25 *. (vo +. vn)) vn (calc_min (x +. 1.0) fs) in 
  calc 0. 0. 0. (calc_min 0.5 fs) |> print_float; print_newline ()

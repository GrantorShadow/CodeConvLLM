open Printf
open Scanf

let solve s1 s2 =
  let f ct i = if String.get s1 i = String.get s2 i then ct + 1 else ct in
  List.fold_left f 0 [0; 1; 2]

let () =
  scanf "%s %s " solve |> printf "%d\n"

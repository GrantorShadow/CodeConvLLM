let n, a, b, c, d, s = Scanf.scanf " %d %d %d %d %d %s" @@ fun a b c d e f -> a, b - 1, c - 1, d - 1, e - 1, f
let s2 = String.sub s a @@ max c d - a + 1
let s3 = String.sub s (b - 1) @@ min (n - b + 1) @@ d - b + 3
let _ =
  try Str.search_forward (Str.regexp "##") s2 0 |> ignore; print_endline "No"; exit 0 with _ -> ();
  print_endline @@ if d < c then
    try Str.search_forward (Str.regexp "\\.\\.\\.") s3 0 |> ignore; "Yes" with _ -> "No"
  else "Yes"
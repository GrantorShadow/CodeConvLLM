module Int = struct
  type t = int
  let compare = compare
end
module IntMap = Map.Make (Int)

let () =
  let n = Scanf.scanf "%d\n" (fun n -> n) in
  let as_ = Array.init n (fun _ -> Scanf.scanf "%d " (fun a -> a)) in
  Array.fold_left (fun m a ->
    IntMap.add a (1 + try IntMap.find a m with Not_found -> 0) m) IntMap.empty as_
  |> IntMap.bindings
  |> (fun l ->
      List.length @@ List.filter (fun (_, n) -> n mod 2 = 0) l,
      List.length @@ List.filter (fun (_, n) -> n mod 2 = 1) l)
  |> (fun (evens, odds) -> evens + odds - evens mod 2)
  |> Printf.printf "%d\n"
let rec transpose l = match l with
  | [] -> []
  | [] :: xss -> transpose xss
  | (x::xs) :: xss -> (x :: List.map List.hd xss) :: transpose (xs :: List.map List.tl xss)

let () =
  let r, c = Scanf.scanf "%d %d\n" (fun x y -> x, y) in
  let rec getLine l = match l with
    | 0 -> []
    | n -> (read_line () |> Str.split (Str.regexp " ") |> List.map int_of_string) :: getLine (l-1) in
  let table = List.rev (getLine r) in
  let sum = List.fold_left (+) 0 in
  
  List.combine table (List.map sum table)
    |> List.map (function (x, y) -> x @ [y])
    |> List.map (List.map string_of_int)
    |> List.map (String.concat " ")
    |> String.concat "\n"
    |> Printf.printf "%s\n";
  transpose table
    |> List.map sum
    |> List.map string_of_int
    |> String.concat " "
    |> Printf.printf "%s";
  Printf.printf " %d\n" (List.map sum table |> sum)
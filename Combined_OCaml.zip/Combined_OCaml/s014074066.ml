open Printf
open Scanf

let id x = x

let solve n k =
  let aa = Array.init n @@ fun _ -> scanf "%d " id in
  for i = k to n - 1 do
    printf "%s\n" @@ if aa.(i-k) < aa.(i) then "Yes" else "No"
  done

let () =
  scanf "%d %d " solve

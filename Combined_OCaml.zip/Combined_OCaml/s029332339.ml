let () =
    read_line ()
    |> Str.split (Str.regexp "")
    |> List.filter ((=) "o")
    |> List.length
    |> (( * ) 100)
    |> (( + ) 700)
    |> string_of_int
    |> print_endline

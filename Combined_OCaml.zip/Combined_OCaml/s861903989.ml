(*
ocamlfind ocamlopt -package batteries -linkpkg main.ml -o a.out
*)
open Batteries

let n, m, c = Scanf.sscanf (read_line ()) "%d %d %d" (
        fun n m c -> 
                n, m, c
)
let blst = 
        Str.split (Str.regexp " ") (read_line ())
        |> List.map int_of_string
let alst =
        List.init n (
                fun _ -> 
                        Str.split (Str.regexp " ") (read_line ())
                        |> List.map int_of_string
        )

let dot_product = List.fold_left2 (fun a b c -> a + b * c) 0
let rec f lst =
        match lst with
                [] -> 0
                | first :: rest -> 
                        let fdot = c + dot_product first blst in
                                if fdot > 0 then
                                        1 + (f rest)
                                else
                                        f rest

let () =
        f alst
      |> Printf.printf "%d\n"

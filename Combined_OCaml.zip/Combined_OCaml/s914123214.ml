open Printf
open Scanf

let solve a b x =
  if a <= x && x <= a + b then "YES" else "NO"

let () =
  scanf "%d %d %d " solve |> printf "%s\n"

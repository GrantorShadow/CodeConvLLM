let a, b = Scanf.scanf " %d %d" @@ fun a b -> a, b
let s = Scanf.scanf " %s" @@ fun s -> s
let is_digit c = 48 <= Char.code c && Char.code c <= 57
let c = Array.fold_left (+) 0 @@ Array.init (a + b + 1) @@ fun i -> if is_digit s.[i] then 1 else 0
let _ = print_endline @@ if c = a + b && s.[a] = '-' then "Yes" else "No"
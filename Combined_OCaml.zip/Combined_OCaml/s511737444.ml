let () = Scanf.scanf "%d" @@ fun r ->
  print_endline @@
  if r < 1200 then "ABC"
  else if r < 2800 then "ARC"
  else "AGC"
let () =
  let i = read_line () in
  let a,b = Scanf.sscanf i "%d %d" (fun a b -> a * b, 2*(a+b)) in
  print_endline (sprintf "%d %d" a b)
open Batteries
let n, k = Scanf.sscanf (read_line()) "%d %d" (fun n k -> n,k)
let a = Array.init n @@ fun _ -> Scanf.scanf " %d" @@ fun a -> a

let get_hyoutei start ed=
  let rec loop i result =
    if i > ed then result else (
      loop (i+1) result * a.(i)
    )
  in loop start 1

let rec hyoutei_loop i result =
  if i + k > n then List.rev result else (
    hyoutei_loop (i+1) (get_hyoutei i (i+k-1) :: result)
  )

let rec loop old lst =
  match lst with
  | [] -> ()
  | first :: rest ->
    if first > old then print_endline "Yes" else print_endline "No"; loop first rest

let r = hyoutei_loop 0 []
let () = loop (List.hd r) @@ List.tl r
let judge a b = if a = b then print_string "a == b\n"
                else if a < b then print_string "a < b\n"
                else print_string "a > b\n" ;;
let f s = Scanf.sscanf s "%d %d" judge ;;
f (read_line()) ;;


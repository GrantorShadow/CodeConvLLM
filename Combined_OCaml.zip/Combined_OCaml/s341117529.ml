let solve h w h0 w0 = (h - h0) * (w - w0)

let read_ints () = read_line () |> Str.split (Str.regexp " ") |> List.map int_of_string

let _ =
  match read_ints () with
  | [h; w] ->
    (match read_ints () with
    | [h0; w0] -> solve h w h0 w0 |> string_of_int |> print_endline
    | _ -> ())
  | _ -> ()
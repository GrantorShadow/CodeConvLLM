let (x,y,z) = Scanf.scanf "%d %d %d \n" (fun x y z-> (x, y, z))

let ans = (x-z)/(y+z)  

    let _ =  Printf.printf "%d\n" ans
;;
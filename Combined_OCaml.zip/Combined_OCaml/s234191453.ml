let () =
  let check x = if x = 2 then 1 else 0
  Scanf.scanf "%d\n" @@ fun n ->
  Printf.printf "%d\n" 
  ((check (n mod 10))+(check ((n mod 100) / 10))+(check ((n mod 1000) / 100))+(check (n / 1000)))

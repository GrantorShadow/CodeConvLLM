let id x = x
let n = Scanf.scanf "%d\n" id

let array = Array.init n (fun _ -> Scanf.scanf "%d " id)
let () = Array.sort compare array  
let list = Array.to_list array

let rec func list list' list'' =
  match list with
  | [] -> (list',list'')
  | hd :: rest ->
     if hd <= 399 && not (List.mem 1 list') then func rest (1::list') list'' else
       if hd >= 400 && hd <= 799 && not (List.mem 2 list') then func rest (2::list')  list'' else
         if hd >= 800 && hd <= 1199 && not (List.mem 3 list') then func rest (3::list')  list'' else
           if hd >= 1200 && hd <= 1599 && not (List.mem 4 list') then func rest (4::list') list'' else
             if hd >= 1600 && hd <= 1999 && not (List.mem 5 list') then func rest (5::list') list'' else
               if hd >= 2000 && hd <= 2399 && not (List.mem 6 list') then func rest (6::list') list'' else
                 if hd >= 2400 && hd <= 2799 && not (List.mem 7 list') then func rest (7::list') list'' else
                   if hd >= 2800 && hd <= 3199 && not (List.mem 8 list') then func rest (8::list')  list'' else
                     if  hd >= 3200 then func rest list' (1::list'') else func rest list' list''
                       
let (x',y') = func list [] [] 
let (x,y) = (List.length x',List.length y')

let min = if x = 0 then 1 else x
let max = x + y

let () =
  Printf.printf "%d %d\n" min max
open Str

let read_list f =
  split (regexp " +") (read_line ()) |> List.map f

let rec derangement ct ix = function
    [] -> ct
  | [h] when h = ix -> ct + 1
  | h :: _ :: t when h = ix -> derangement (ct + 1) (ix + 2) t
  | h :: t -> derangement ct (ix+1) t

let () =
  let _ = read_line () in
  let lst = read_list int_of_string in
  derangement 0 1 lst |> string_of_int |> print_endline

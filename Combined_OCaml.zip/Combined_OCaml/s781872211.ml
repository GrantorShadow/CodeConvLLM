let partition (a : int array) p r =
  let x = a.(r) in
  let swap i j = let t = a.(i) in a.(i) <- a.(j); a.(j) <- t
  in
  let rec doit i j =
    if j >= r then i
    else begin
      if a.(j) <= x then (swap (i + 1) j; doit (i + 1) (j + 1))
      else doit i (j + 1)
    end
  in
  let i = doit (p - 1) p in
  swap (i + 1) r;
  i + 1

let () =
  let n = read_int () in
  let a = Array.init n (fun _ -> Scanf.scanf "%d " (fun i -> i)) in
  let k = partition a 0 (n - 1) in
  Array.iteri (fun i e ->
    Printf.printf (if i = 0 then "%d" else if i = k then " [%d]" else " %d") e) a;
  print_newline ()
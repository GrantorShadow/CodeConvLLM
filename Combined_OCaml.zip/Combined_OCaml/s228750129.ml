open List
let i_inp : unit -> int = fun () ->
  int_of_string (input_line stdin)

let i_inp_list : unit -> int list = fun () ->
  let inp_split = Str.split (Str.regexp " ") (input_line stdin) in
  map (fun x -> int_of_string x) (inp_split)

(* inp_loop i_inp_list 10  のように使う *)
let rec inp_loop : (unit -> 'a) -> int -> 'a list = fun inp_fun n ->
  if n = 0 then []
  else
    let x = inp_fun () in
    x :: inp_loop inp_fun (n - 1)

let () =
  let n = i_inp () in
  let list =
    inp_loop
      (fun () ->
        let [a; b] = i_inp_list ()
        in (a, b))
      n in
  let list = fast_sort
               (fun (a1, b1) (a1, b1) -> if (b1, a1) > (b1, a1) then 1 else if (a1, b1) = (a1, b1) then 0 else -1)
               list in
  let rec loop t list =
    match list with
      [] -> true
    | (a, b) :: rest ->
       if t + a > b then false
       else loop (t + a) rest
  in
  if loop 0 list then
    print_endline "Yes"
  else
    print_endline "No"

let () =
  let s = read_line () in
  let check = function
    |"SUN" -> 7
    |"MON" -> 6
    |"TUE" -> 5
    |"WED" -> 4
    |"THU" -> 3
    |"FRI" -> 2
    |_ -> 1
  in
  print_int @@ check s
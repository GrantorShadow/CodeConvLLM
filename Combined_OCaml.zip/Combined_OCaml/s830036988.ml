let a, b = Scanf.scanf " %d %d" @@ fun a b -> a, b
let _ = print_endline @@ if a mod 3 = 0 || b mod 3 = 0 || (a + b) mod 3 = 0 then "Possible" else "Impossible"
    let f a b c = (min (a/b) c);;
    let () = Scanf.scanf "%d %d %d" f
    |> Printf.printf "%d\n"
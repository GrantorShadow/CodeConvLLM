let string_to_list str =
  let rec loop i limit =
    if i = limit then []
    else (String.get str i) :: (loop (i + 1) limit)
  in
  loop 0 (String.length str)


let fwd arr_length n = if n = (arr_length - 1) then 0 else n+1
let prev arr_length n = if n = 0 then arr_length - 1 else n-1
let flip c = if c = 'S' then 'W' else 'S'
let print_chars arr = Array.iter (fun x -> Printf.printf "%c" x) arr; Printf.printf "\n"
           
let fill arr arr_length n by =
  if (arr.(n) == 'S' && by = 'o') || (arr.(n) == 'W' && by = 'x') then
    begin
      arr.(fwd arr_length n) <- arr.(prev arr_length n);
    end
  else
    begin
      arr.(fwd arr_length n) <- flip arr.(prev arr_length n);
    end    

let rec extend answers ans_length cursor ret = match answers with
  | [] -> ret
  | 'o'::rest ->
     fill ret ans_length cursor 'o';
     extend rest ans_length (cursor+1) ret
  | 'x'::rest ->
     fill ret ans_length cursor 'x';
     extend rest ans_length (cursor+1) ret
  | _ -> ret

let check arr arr_length by n =
  if (arr.(n) == 'S' && by = 'o') || (arr.(n) == 'W' && by = 'x') then
    arr.(fwd arr_length n) = arr.(prev arr_length n)
  else
    arr.(fwd arr_length n) <> arr.(prev arr_length n)

let make_list f t step =
  let rec make_list_inner c t lst =
    if c >= t then lst else make_list_inner (c+step) t (c::lst)
  in
  List.rev (make_list_inner f t [])

let check_all pos_ans length pairs =
  let checks = List.map (fun (x,y) -> check pos_ans length y x) pairs in
  List.fold_left (fun x y -> x && y) true checks

let array_make length a b =
  let ret = (Array.make length a) in
  ret.(length - 1) <- b;
  ret

let solve str =
  let str_list = (string_to_list str) in
  let length = List.length str_list in
  let pairs = List.combine (make_list 0 length 1) str_list in
  let pos_ans = extend str_list length 0 (array_make length 'S' 'S') in
  if check_all pos_ans length pairs then pos_ans else
    let pos_ans = extend str_list length 0 (array_make length 'S' 'W') in
    if check_all pos_ans length pairs then pos_ans else
      let pos_ans = extend str_list length 0 (array_make length 'W' 'W') in
      if check_all pos_ans length pairs then pos_ans else
        let pos_ans = extend str_list length 0 (array_make length 'W' 'S') in
        if check_all pos_ans length pairs then pos_ans else
          [||]
  
let () =
  let _ = read_int() in
  let str = read_line () in
  let ans = solve str in
  if ans = [||] then
    Printf.printf ("-1")
  else
    Array.iter (fun x -> Printf.printf "%c" x) ans;
  Printf.printf "\n"
;;

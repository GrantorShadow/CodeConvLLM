let kKMax = 3000
let x, y, z, k = Scanf.scanf " %d %d %d %d" @@ fun a b c d -> a, b, c, d
let a_s = Array.init x @@ fun _ -> Scanf.scanf " %d" @@ (+) 0
let bs = Array.init y @@ fun _ -> Scanf.scanf " %d" @@ (+) 0
let cs = Array.init z @@ fun _ -> Scanf.scanf " %d" @@ (+) 0
let ab_s = Array.make (x * y) 0
let ans = Array.make (kKMax * z) 0
let _ =
  for i = 0 to x - 1 do
    for j = 0 to y - 1 do
      ab_s.(i * y + j) <- a_s.(i) + bs.(j) done done;
  Array.sort (fun x y -> y - x) ab_s;
  for i = 0 to min (x * y - 1) @@ kKMax - 1 do
    for j = 0 to z - 1 do
      ans.(i * z + j) <- ab_s.(i) + cs.(j) done done;
  Array.sort (fun x y -> y - x) ans;
  for i = 0 to k - 1 do
    Printf.printf "%d\n" ans.(i) done
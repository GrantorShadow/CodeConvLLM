let may_month = function "01" | "02" | "03" | "04" | "05" | "06" | "07" | "08" | "09" | "10"
                                | "11" | "12" -> true | _ -> false

let may_year  _ = true

let () =
  let s = Scanf.scanf "%s\n" (fun s -> s) in
  let s1, s2 = String.sub s 0 2, String.sub s 2 2 in
  (if may_year s1 && may_month s2 && may_month s1 && may_year s2 then "AMBIGUOUS"
   else if may_year s1 && may_month s2 then "YYMM"
   else if may_month s1 && may_year s2 then "MMYY"
   else "NA"
  ) |> print_string

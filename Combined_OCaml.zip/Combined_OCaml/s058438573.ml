let id x = x
let (a,b,c) = Scanf.scanf "%d %d %d\n" (fun a b c -> (a,b,c))

let rec func a b c n =
  if ((a mod 2) = 1) || ((b mod 2) = 1) || ((c mod 2) = 1) then n
  else
    func ((b+c)/2) ((a+c)/2) ((a+b)/2) (n+1)

let ans = if (a = b) && (b = c) then -1 else func a b c 0

let () =
  Printf.printf "%d\n" ans

let () =
  let s = read_line () in
  print_endline @@ String.init ((String.length s + 1) / 2) (fun i -> s.[2 * i])

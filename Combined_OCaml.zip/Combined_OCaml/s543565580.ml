let rec($)i x=if i=0then Printf.printf"%.0f
"x else(i-1)$(floor(ceil(x*.1.05/.1000.)*.1000.));;(read_int())$100000.
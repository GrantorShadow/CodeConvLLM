let () =
  let rec read () =
    try let l = read_line () |> Str.split (Str.regexp " ")
                   |> List.map float_of_string |> Array.of_list in
        let xa1,ya1,xa2,ya2,xb1,yb1,xb2,yb2 = l.(0),l.(1),l.(2),l.(3),l.(4),l.(5),l.(6),l.(7) in
        if (xb1 > xa2) || (xb2 < xa1) || (yb1 > ya2) || (yb2 < ya1) then
          print_endline "NO"
        else
          print_endline "YES"
        ;read ()
    with End_of_file -> ()
  in read ()
;;
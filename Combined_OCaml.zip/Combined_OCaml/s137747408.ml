let a, b, c, d = Scanf.scanf " %c%c%c%c" @@ fun a b c d -> a, b, c, d
let res = if a = b then c = d && b <> c else if a = c then b = d && c <> b else if a = d then b = c && d <> b else false
let _ = print_endline @@ if res then "Yes" else "No"
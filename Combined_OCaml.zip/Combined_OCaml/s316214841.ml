let () = Scanf.scanf "%s" @@ fun s ->
  if s = "AAA" || s = "BBB"
  then print_endline "No"
  else print_endline "Yes"
let (a, b) = Scanf.sscanf (read_line ()) "%d %f" @@ fun a b -> (a, b)

let () = Printf.printf "%d\n" @@ int_of_float @@ (float a /. 10. *. b *. 10.)
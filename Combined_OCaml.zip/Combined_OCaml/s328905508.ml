let split s =
  Str.split (Str.regexp_string " ") s |> List.map (fun x -> float_of_string x);;

let rec read () =
  try let l = read_line () |> split |> Array.of_list in
      let (a, b) = (l.(2)-.l.(0), l.(3)-.l.(1)) and
          (c, d) = (l.(6)-.l.(4), l.(7)-.l.(5)) in
      if abs_float ((a*.c) +. (b*.d)) < 0.0000000001 then
        print_endline "YES"
      else
        print_endline "NO"
      ; read ()
  with End_of_file -> ();;

let () = read ();;
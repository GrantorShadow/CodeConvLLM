module IntSet = Set.Make (struct
  type t = int
  let compare = compare
end)

let () = Scanf.scanf "%d" @@ fun s ->
  let rec solve n an set =
    if IntSet.mem an set then n
    else solve (n + 1) (if an mod 2 = 0 then an / 2 else 3 * an + 1) (IntSet.add an set) in
  Printf.printf "%d" @@ solve 1 s IntSet.empty
open Printf
open Scanf

let read_intlist: unit -> int list = fun () ->
  let sl = Str.split (Str.regexp " ") @@ read_line () in
  List.map (fun s -> sscanf s "%d" (fun x -> x)) sl

let n = sscanf (read_line ()) "%d" (fun x -> x)
let a: int array array = Array.make (n+1) [|0|]
let () = for y = 1 to n do
           a.(y) <- 0 :: (read_intlist ()) @ [0] |> Array.of_list
         done

(*  *)
let ans = ref 0
let inds = Array.make (n+1) 1

let () =
  let bflag = ref true in
  while !bflag do
    let dp = Array.make (n+1) false in
    let flag = ref true in

    for i = 1 to n do
      let x = inds.(i) in
      if not dp.(i) && x < n then begin
        let target = a.(i).(x) in
        if not dp.(target) && a.(target).(inds.(target)) = i then begin
            dp.(i) <- true;
            dp.(target) <- true;

            inds.(i) <- inds.(i) + 1;
            inds.(target) <- inds.(target) + 1;

            if !flag then
              flag := false
          end
        end;
    done;

    if !flag then
      let hoge = List.tl (Array.to_list inds)
                 |> List.for_all (fun e -> e = n) in
      if hoge then
        bflag := false
      else begin
          ans := -1;
          bflag := false
        end
    else
      incr ans
  done

let () = print_endline @@ string_of_int !ans
        
               

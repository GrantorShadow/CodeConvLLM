open Printf open Scanf
open Array

let count_substr s t =
  let ln = String.length in
  init (ln s - ln t + 1) (fun i ->
    if init (ln t) (fun j -> s.[i+j] = t.[j])
    |> fold_left (&&) true then 1 else 0
  ) |> fold_left (+) 0

let () = scanf " %d" @@ fun n ->
  let arr = init n (fun _ -> scanf " %s" @@ fun s -> s)
  in
  let kba,kbx,kxa,kab = ref 0,ref 0,ref 0,ref 0 in
  iter (fun s ->
    let bx = s.[0] = 'B' in
    let xa = s.[String.length s-1] = 'A' in
    let ab = bx && xa in
    if ab then incr kab
    else if bx then incr kbx
    else if xa then incr kxa;
    kab := !kab + count_substr s "AB"
  ) arr;
  let kba,kbx,kxa,kab = !kba,!kbx,!kxa,!kab in
  print_int @@ kab +
    if kba >= 1 then (
      (* B-A^B-A^...^B-A *)
      let pair_ba = kba - 1 in
      (* B-A^B-A^...^B-A ^ B- *)
      let add,kbx =
        if kbx > 0 then 1,kbx-1 else 0,kbx in
      (* -A ^ B-A^B-A^...^B-A*)
      let add,kxa =
        if kxa > 0 then add+1,kxa-1 else add,kxa in
      pair_ba + add + min kbx kxa
    ) else
      (* -A^B- ... -A^B- *)
      min kbx kxa




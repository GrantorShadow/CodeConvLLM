let s = read_line ()
let _ = Printf.printf "%d\n" @@ String.rindex s 'Z' - String.index s 'A' + 1
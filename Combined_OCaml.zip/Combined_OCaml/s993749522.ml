Scanf.scanf " %d %d %d" @@ fun n a b ->
  Printf.printf "%d %d" (min a b) (max (a+b-n) 0)
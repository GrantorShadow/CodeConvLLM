let a = read_line ()
let b = read_line ()
let _ = print_endline @@ [|"LESS"; "EQUAL"; "GREATER"|].(String.(if length a > length b then 1 else if length a < length b then -1 else compare a b) + 1)
(* O(n) *)
let n = Scanf.scanf " %d" @@ (+) 0
let a1s = Array.init n @@ fun _ -> Scanf.scanf " %d" @@ (+) 0
let a2s = Array.init n @@ fun _ -> Scanf.scanf " %d" @@ (+) 0
let c1, c2 = ref 0, ref 0
let acc1 = Array.make (n + 1) 0
let acc2 = Array.make (n + 1) 0
let ans = ref 0
let _ =
  for i = 0 to n - 1 do
    c1 := !c1 + a1s.(i); acc1.(i + 1) <- !c1;
    c2 := !c2 + a2s.(i); acc2.(i + 1) <- !c2
  done;
  for i = 0 to n - 1 do
    ans := max !ans @@ acc1.(i + 1) - acc1.(0) + acc2.(n) - acc2.(i)
  done;
  Printf.printf "%d\n" !ans
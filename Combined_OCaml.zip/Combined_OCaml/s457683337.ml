let () =
  Scanf.scanf "%d" @@ fun n ->
  let s = Array.init n (fun _ -> Scanf.scanf " %s" (fun x -> x)) in
  let s = Array.init (2*n-1) (fun i ->
    Array.init (2*n-1) (fun j -> s.(i mod n).[j mod n])) in
  Array.init n (fun i ->
      [(i, 0); (0, i)] |> List.sort_uniq compare |> List.fold_left (fun c (dx, dy) ->
        let sym =
          Array.init (n*n) (fun j ->
            s.(dx + j/n).(dy + j mod n) = s.(dx + j mod n).(dy + j/n))
          |> Array.fold_left (&&) true
        in
        c + if sym then n-i else 0) 0)
  |> Array.fold_left (+) 0
  |> Printf.printf "%d\n"
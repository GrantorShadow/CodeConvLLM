let map_tuple f (a, b) = (f a, f b)
let () =
  let (a, b) = map_tuple int_of_string (String.split (read_line ()) " ") in                                   
  Printf.printf "%s\n" (if a < b then "a < b" else if a > b then "a > b" else "a == b")
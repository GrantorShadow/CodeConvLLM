module A = Array
module C = Char
module I = Int64
module L = List
module Q = Queue

let pf = Printf.printf
let sf = Scanf.scanf
let ssf = Scanf.sscanf

let read_int () = sf "%d " (fun x -> x)
let read_float () = sf "%f " (fun x -> x)
let read_str () = sf "%s " (fun x -> x)
let read_array n read () = A.init n (fun _ -> read ())
let err s = raise (Failure s)

let range s t = A.init (t - s) @@ (+) s
let foreach fold_f init s t map_f =
  range s t |> A.map map_f |> A.fold_left fold_f init

let inf = int_of_float 1e18
let eps = 1e-11

module S = struct
  include String
  let of_array a = String.init (A.length a) (A.get a)
  let to_array s = A.init (String.length s) (String.get s)
end;;

let () =
  let n = read_int () in
  let a = read_int () in
  let b = read_int () in
  let res = min (n * a) b in
  pf "%d\n" res

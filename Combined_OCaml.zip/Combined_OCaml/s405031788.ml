let () =
  let n = Scanf.scanf "%d " (fun n -> n) in
  let a = Array.init n (fun _ -> Scanf.scanf "%d " (fun i -> i)) in
  let (e, o) = Array.fold_left (fun (x, y) e -> if e mod 2 = 0 then (x + 1, y) else (x, y + 1)) (0, 0) a in
  print_endline (if e = 0 || e = o || e <= o + 2 then "No" else "Yes")
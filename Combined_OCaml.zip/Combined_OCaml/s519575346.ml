let a = ref 0;;
let b = ref 0;;
Scanf.scanf "%d %d" (fun x y -> a := x; b := y);;

let p =
  if !a >= 13 then !b
  else if !a >= 6 then !b / 2
  else 0 in
  print_endline(string_of_int p)
;;
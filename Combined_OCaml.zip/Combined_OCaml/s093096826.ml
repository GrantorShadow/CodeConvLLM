Scanf.scanf "%d" (fun l ->
    let a = Array.init l (fun _ -> Scanf.scanf " %d" (fun a -> a)) in

    let min3 a b c     = min a (min b c) in
    let min4 a b c d   = min (min a b) (min c d) in
    let min5 a b c d e = min (min a b) (min3 c d e) in

    let rec loop i f0 f1 f2 f3 f4 =
        if i = l then min5 f0 f1 f2 f3 f4 else
            let g0 = f0 + a.(i) in
            let g1 =
                if a.(i) = 0       then min f0 f1 + 2 else
                if a.(i) mod 2 = 1 then min f0 f1 + 1 else
                                        min f0 f1
            in
            let g2 =
                if a.(i) = 0       then min3 f0 f1 f2 + 1 else
                if a.(i) mod 2 = 1 then min3 f0 f1 f2     else
                                        min3 f0 f1 f2 + 1
            in
            let g3 =
                if a.(i) = 0       then min4 f0 f1 f2 f3 + 2 else
                if a.(i) mod 2 = 1 then min4 f0 f1 f2 f3 + 1 else
                                        min4 f0 f1 f2 f3
            in
            let g4 = a.(i) + min5 f0 f1 f2 f3 f4 in
            loop (i + 1) g0 g1 g2 g3 g4
    in
    loop 0 0 0 0 0 0 |> Printf.printf "%d\n"
)
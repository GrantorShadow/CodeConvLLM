let () = Scanf.scanf "%d %d\n" @@ fun w h ->
  begin
    Array.to_list (Array.init w (fun _ ->
      Scanf.scanf "%d\n" (fun p -> (p, true)))) @
    Array.to_list (Array.init h (fun _ ->
      Scanf.scanf "%d\n" (fun q -> (q, false))))
  end
  |> List.sort compare
  |> List.fold_left (fun (cost, (a, b)) -> function
    | (p, true) ->
        (* p_i は，∀j. (i, j)と(i + 1, j)を結ぶコスト *)
        (cost + p * b, (a - 1, b))
    | (q, false) ->
        (* q_j は，∀i. (i, j)と(i, j + 1)を結ぶコスト *)
        (cost + q * a, (a, b - 1))) (0, (w + 1, h + 1))
  |> fst
  |> Printf.printf "%d\n"
open Scanf
open Printf
open Big_int

let multiplication lst =
  let rec loop lst total = match lst with
      [] -> big_int_of_int 1
    | first :: rest ->
        if gt_big_int total (big_int_of_int 1000000000000000000) then big_int_of_int (-1)
        else mult_big_int first (loop rest (mult_big_int total first))
  in int_of_big_int (loop lst (big_int_of_int 1))

let n = sscanf (read_line ()) "%d" (fun n -> n)
let a_list = List.map (fun n -> big_int_of_string n) (String.split_on_char ' ' (read_line ()))
let () = printf "%d\n" (multiplication a_list)
Scanf.scanf "%d %s" (fun k s ->
    let n = String.length s in
    if n <= k then print_endline s
        else Printf.printf "%s...\n" (String.sub s 0 k)
)
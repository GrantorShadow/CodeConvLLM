open Scanf
open Printf
open String;;

(* sscanf (read_line ()) "%d %d" 
   (fun x y -> printf "%d" ((x-1)*(y-1)));; *)



(* let abb s = (sub s 0 1) 
            ^ (string_of_int (length s - 2))
            ^ (sub s (length s - 1) 1);;

sscanf (read_line ()) "%s"
          (fun s -> printf "%s" (abb s));; *)

(*

let judge l =
  let len = List.length l in
  let f l = List.fold_left 
              (fun (x,l') y -> if y mod 4==0 then (x+1,l') else (x,y::l')) (0,[]) l in
  let g l = List.fold_left (fun x y -> x + if y mod 2!=0 then 1 else 0) 0 l in
  let (four, fourl) = f l in
  four >= len/2 || g fourl <= four

let usage n = 
  let list = ref [] in
  for i = 1 to n do
    list := (scanf (if i < n then "%d " else "%d") (fun x -> x))::!list
  done; !list;;

sscanf (read_line ()) "%d" 
   (fun x -> printf "%s" (if judge (usage x) then "Yes" else "No"));;

*)

let usage n = 
  let list = ref [] in
  for i = 1 to n do
    list := (scanf (if i < n then "%d " else "%d") (fun x -> x))::!list
  done; List.rev !list;;

let rec print_list = function
    [x] -> print_endline (string_of_int x)
  | x::xs -> print_string ((string_of_int x) ^ " "); print_list xs

and print_ll = function
    [] -> ()
  | x::xs -> print_list x; print_ll xs;;

let rec make_list ini = function
    0 -> []
  | n -> ini :: make_list ini (n-1);;

let make_line l =
  let rec make col = function
      [] -> []
    | x::xs -> make_list col x :: make (col+1) xs
  in List.concat (make 1 l);;

let rec take n = function
    [] -> []
  | x :: rest when n = 0  -> [] 
  | x :: rest -> x :: take (n-1) rest;;

let rec drop n = function
    [] -> []
  | x :: rest when n <= 0 -> x :: drop (n-1) rest 
  | x :: rest -> drop (n-1) rest;;

let rec proc m n = function
  _ when n <= 0 || m <= 0 -> []
  | [] -> []
  | l when m mod 2 = 0 -> List.rev (take n l) :: proc (m-1) n (drop n l)
  | l when m mod 2 = 1 -> take n l :: proc (m-1) n (drop n l);;

sscanf (read_line ()) "%d %d" (fun m n ->
         scanf "%d" (fun x -> print_ll (proc m n (usage x))));;





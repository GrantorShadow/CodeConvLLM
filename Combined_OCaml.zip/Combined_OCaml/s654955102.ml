let for_range s e step f =
  let rec loop i =
    if i <= e then begin f i;loop (i + step) end
  in loop s;;

let sieve num =
  let p = Array.init num (fun x -> x mod 2) in
  let rec loop i =
    if i*i < num then
      begin
        if p.(i) = 1 then for_range (i*i) num (i*2) (fun x -> p.(x) <- 0);
        loop (i+2)
      end
  in
  p.(0) <- 0; p.(1)<-(0);p.(2)<-1;loop 3;
  for i = 3 to num-1 do
    p.(i) <- p.(i) + p.(i-1);
  done;
  p
;;

let _ =
  let p = sieve 1000000 in
  let rec read () =
    try let n = read_int () in
        Printf.printf "%d\n" p.(n);
        read ()
    with End_of_file -> ()
  in read ()
;;
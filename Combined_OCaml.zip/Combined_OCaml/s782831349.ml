let a, b, x = Scanf.scanf " %f %f %f" @@ fun a b c -> a, b, c
let f r = 180. *. r /. acos (-1.) |> Printf.printf "%.10f\n"
let _ = f @@ if x <= b *. a *. a /. 2. then let d = 2. *. x /. (a *. b) in let k = sqrt (b *. b +. d *. d) in acos @@ 2. *. x /. (a *. k) /. b
  else let s = a *. b -. x /. a in let l = 2. *. s /. a in acos @@ a /. sqrt (a *. a +. l *. l)
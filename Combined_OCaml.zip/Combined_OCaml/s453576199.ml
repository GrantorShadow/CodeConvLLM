open Array
let n, m = Scanf.scanf "%d %d\n" @@ fun a b -> a, b
let a = init n @@ fun _ -> Scanf.scanf "%d " @@ fun d -> d
let m4 = (fold_left (+) 0 a) / (4 * m)
let ans =
  if List.length (List.filter (fun x -> x >= m4) (to_list a)) >= m
  then "Yes" else "No"
let () = print_endline ans
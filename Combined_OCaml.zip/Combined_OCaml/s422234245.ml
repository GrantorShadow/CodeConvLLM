let split_on_char sep s =
  let open String in
  let r = ref [] in
  let j = ref (length s) in
  for i = length s - 1 downto 0 do
    if get s i = sep then begin
      r := sub s (i + 1) (!j - i - 1) :: !r;
      j := i
    end
  done;
  sub s 0 !j :: !r

let parent i = int_of_float ((float_of_int (i - 1)) /. 2.)

let left i = 2*i + 1

let right i = 2*i + 2

let to_pow_of_2 n =
  let rec doit i =
    if i >= n then i
    else doit (i * 2) in
  doit 1

let update (s : int array) n i x =
  let j = n + i - 1 in
  s.(j) <- x;
  let rec doit j =
    if j > 0 then begin
      let j = parent j in
      s.(j) <- if s.(left j) < s.(right j) then s.(left j) else s.(right j);
      doit j
    end in
  doit j

let find s n a b =
  let rec doit a b k l r =
    if r <= a || b <= l then 2147483647
    else if a <= l && r <= b then s.(k)
    else begin
      let v = doit a b (left k) l ((l + r) / 2) in
      let w = doit a b (right k) ((l + r) / 2) r in
      if v < w then v else w
    end in
  doit a b 0 0 n

let solve n q =
  let n = to_pow_of_2 n in
  let s = Array.make (2*n-1) 2147483647 in
  let rec doit i =
    if i < q then begin
      begin match List.map int_of_string (split_on_char ' ' (read_line ())) with
      | 0 :: x :: y :: _ -> update s n x y
      | 1 :: x :: y :: _ -> Printf.printf "%d\n" (find s n x (y + 1))
      | _ -> ()
      end;
      doit (i + 1)
    end in
  doit 0

let () =
  match List.map int_of_string (split_on_char ' ' (read_line ())) with
  | [n; q] -> solve n q
  | _ -> ()
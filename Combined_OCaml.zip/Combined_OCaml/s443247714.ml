let () =
  let s = read_line () in
  let n = String.length s in
  Printf.printf "%c%d%c\n" s.[0] (n - 2) s.[n-1]
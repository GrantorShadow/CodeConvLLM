open Scanf
open Printf

let rotates s = let rec f n = if n = String.length s
                 then []
                 else (String.sub s n (String.length s - n) ^ String.sub s 0 n) :: f (n+1)
  in s :: (f 1)

let f s t = List.fold_left ( || ) false (List.map (fun u -> u = t) @@ rotates s)

let () = if scanf "%s\n%s\n" f
    then printf "Yes\n"
    else printf "No\n"
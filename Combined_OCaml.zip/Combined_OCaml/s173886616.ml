Scanf.scanf "%d" (fun n ->
    let a = Array.init n (fun _ -> Scanf.scanf " %d" (fun a -> a)) in
    Array.sort compare a;
    Printf.printf "%d\n" @@ a.(n - 1) - a.(0)
)
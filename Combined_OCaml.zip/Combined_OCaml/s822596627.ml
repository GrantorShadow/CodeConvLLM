type 'a t = {
  mutable front : int;
  mutable mask  : int;
  mutable index : int;
  mutable length : int;
  mutable elems : (string * int) array
}

let capacity (t: (string * int) t) = t.mask + 1

let is_empty (t: (string * int) t) = t.length = 0

let create ?(capacity=1) () =
  { front = 0;
    mask  = capacity - 1;
    index = 0;
    length = 0;
    elems = Array.make capacity ("",0)}

let enq (t: (string * int) t) (a: string * int) =
  let (elems: (string * int) array) = t.elems in
  elems.(t.index) <- a;
  t.length <- t.length + 1;
  t.index <- if t.mask=t.index then 0 else t.index + 1

let deq (t: (string * int) t) =
  let (elems: (string * int) array) = t.elems in
  let (front: int) = t.front in
  let (res: string * int) = elems.(front) in
  t.front <- if t.mask=t.front then 0 else t.front+1;
  t.length <- t.length - 1;
  res

let () =
  let (n:int),(quantum:int) = Scanf.scanf "%d %d\n" (fun a b -> a,b) in
  let (q:(string * int) t) = create ~capacity:n () in
  for i=1 to n do
    enq q (Scanf.scanf "%s %d\n" (fun a b -> a,b));
  done;
  let (sum:int ref) = ref 0 in
  while not (is_empty q) do
    let (p:string),(t:int) = deq q in
    if t <= quantum then (sum := !sum+t; Printf.printf "%s %d\n" p !sum)
    else (enq q (p,t-quantum); sum := !sum+quantum)
  done
let modulo = 998244353
let ( +@ ) a b = (a+b) mod modulo
let ( *@ ) a b = (a*b) mod modulo
let rec mod_pow a n =
  if n <= 0 then 1
  else if n mod 2 = 1 then a *@ mod_pow a (n-1)
  else let h = mod_pow a (n/2) in h *@ h
let ( /@ ) a b = a *@ mod_pow b (modulo - 2)

let rec for_fold a b v f = if a > b then v else for_fold (a+1) b (f v a) f

let () =
  Scanf.scanf "%d %d %d %d" @@ fun n a b k ->
  let comb = Array.make (n+1) 1 in
  for r = 1 to n do comb.(r) <- comb.(r-1) *@ (n+1-r) /@ r done;

  for_fold 0 n 0 (fun s r ->
    if k < r * a || (k - r * a) mod b > 0 then s
    else
      let m = (k - r * a) / b in
      if m > n then s else s +@ comb.(r) *@ comb.(m))
  |> Printf.printf "%d\n"
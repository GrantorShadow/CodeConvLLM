Scanf.sscanf(read_line()) "%d"
  (fun a ->
    let num = a/2 in
    if(a == 1) then print_int(1)
    else if (a mod 2 == 0) then print_float((float_of_int num)/.(float_of_int a) )
    else print_float((float_of_int (num+1))/.(float_of_int a))
  );;
print_string "\n";;

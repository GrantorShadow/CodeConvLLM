let n = Scanf.sscanf (read_line ()) "%d" @@ fun n -> n
let s = Array.init n @@ fun _ -> read_line ()

let tbl = Hashtbl.create 4

let () =
  Array.iter (fun s -> Hashtbl.add tbl s 1 ) s;
  Printf.printf "AC x %d\n" @@ List.length @@ Hashtbl.find_all tbl "AC";
  Printf.printf "WA x %d\n" @@ List.length @@ Hashtbl.find_all tbl "WA";
  Printf.printf "TLE x %d\n" @@ List.length @@ Hashtbl.find_all tbl "TLE";
  Printf.printf "RE x %d\n" @@ List.length @@ Hashtbl.find_all tbl "RE";

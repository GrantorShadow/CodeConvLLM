let css = Array.init 3 @@ fun _ -> Array.init 3 @@ fun _ -> Scanf.scanf " %d" @@ (+) 0 in
let a_s = Array.make 3 0 in
let bs = Array.make 3 0 in
bs.(0) <- css.(0).(0);
bs.(1) <- css.(0).(1);
bs.(2) <- css.(0).(2);
a_s.(1) <- css.(1).(0) - bs.(0);
a_s.(2) <- css.(2).(0) - bs.(0);
for i = 0 to 2 do
  for j = 0 to 2 do
    if css.(i).(j) <> a_s.(i) + bs.(j) then begin print_endline "No"; exit 0 end
  done
done;
print_endline "Yes"
let to_list str =
  let n = String.length str in
  let rec doit i acc =
    if i = n then acc
    else doit (i + 1) (str.[i] :: acc)
  in
  doit 0 []

let to_int c = int_of_char c - int_of_char '0'

let plus l1 l2 =
  let rec doit i acc = function
    | ([], [], 1) -> (i + 1, 1 :: acc)
    | ([], [], _) -> (i, acc)
    | ([], hd :: tl, carry) ->
        let x = to_int hd + carry in
        if x <= 9 then doit (i + 1) (x :: acc) ([], tl, 0)
        else doit (i + 1) (x mod 10 :: acc) ([], tl, 1)
    | (hd :: tl, [], carry) ->
        let x = to_int hd + carry in
        if x <= 9 then doit (i + 1) (x :: acc) (tl, [], 0)
        else doit (i + 1) (x mod 10 :: acc) (tl, [], 1)
    | (a :: b, c :: d, carry) ->
        let x = to_int a + to_int c + carry in
        if x <= 9 then doit (i + 1) (x :: acc) (b, d, 0)
        else doit (i + 1) (x mod 10 :: acc) (b, d, 1)
  in
  doit 0 [] (to_list l1, to_list l2, 0)

let () =
  let n = read_int () in
  let rec doit i =
    if i < n then begin
      let l1 = read_line () in
      let l2 = read_line () in
      let n1 = String.length l1 in
      let n2 = String.length l2 in
      if n1 > 80 || n2 > 80 then print_endline "overflow"
      else if n1 < 10 && n2 < 10 then Printf.printf "%d\n" (int_of_string l1 + int_of_string l2)
      else begin
        let z, ans = plus l1 l2 in
        if z > 80 then print_endline "overflow"
        else (List.iter (fun e -> print_int e) ans; print_newline ())
      end;
      doit (i + 1)
    end
  in
  doit 0
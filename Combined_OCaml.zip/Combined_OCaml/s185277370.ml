let n, ans = read_int (), ref 0
let rec g n = if n < 10 then n else g (n / 10)
let f i j = let c = ref 0 in for k = 1 to n do if k mod 10 = j && g k = i then incr c done; !c
let _ = for i = 1 to 9 do for j = 1 to 9 do ans := !ans + f i j * f j i done done; Printf.printf "%d\n" !ans
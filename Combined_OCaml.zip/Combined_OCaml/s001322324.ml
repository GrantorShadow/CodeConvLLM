let solve list =
  let already = Hashtbl.create (List.length list) in
  let rec inner last rest = match rest with
    | [] -> true
    | x::xs ->
       if (String.length last > 0) && (String.get x 0) <> (String.get last (String.length last - 1)) then false
       else
         begin
           if Hashtbl.mem already x then false
           else
             begin
               Hashtbl.add already x 1;
               inner x xs
             end
         end
  in
  inner "" list

let read_list_of_string () =
  let rec read_list_of_string_inner lst =
    try let ans = (Scanf.scanf "%s\n" (fun x->x)) in
        read_list_of_string_inner (ans::lst)
    with End_of_file ->
      List.rev lst
  in
  read_list_of_string_inner []

let () =
  let _ = read_int() in
  let list = read_list_of_string () in
  let ans = solve list in
  Printf.printf "%s\n" (if ans then "Yes" else "No")
;;

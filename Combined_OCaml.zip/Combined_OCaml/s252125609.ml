module WeightedGraph
  (Vertex : sig
    type t
    val compare : t -> t -> int
  end)
  (Weight : sig
    type t
    val compare : t -> t -> int
  end) :
sig
  val prim :
    (* 隣接リスト *)
    (Vertex.t -> (Vertex.t * Weight.t) list) ->
    (* 始点 *)
    Vertex.t ->
    (* 最小全域木に含まれる辺のリスト *)
    (Vertex.t * Vertex.t * Weight.t) list
end =
struct
  module VSet = Set.Make (Vertex)
  module WMap = Map.Make (Weight)
 
  (*
   * プリム法のメインループ
   * es : 隣接リスト
   * vs : 訪れた頂点の集合
   * q : 訪れた頂点から伸びる辺が重み順に入ったヒープ
   * acc : 最小全域木に使うのが確定した辺を入れるやつ
   *)
  let rec prim_aux es acc vs q =
    match WMap.min_binding q with
    | exception Not_found -> acc
    | (w, []) -> prim_aux es acc vs (WMap.remove w q)
    | (w, (u, v) :: rest) ->
        if VSet.mem v vs then
          (* vは既に訪れていた *)
          prim_aux es acc vs (WMap.add w rest q)
        else
          (* vはまだ訪れていなかった *)
          prim_aux es ((u, v, w) :: acc) (VSet.add v vs) @@
            (* vから伸びる辺をキューに追加 *)
            List.fold_left (fun q (u, w) ->
              (* 現時点で既に訪れている頂点への辺は追加しない *)
              if VSet.mem u vs then q
              else WMap.add w ((v, u) :: try WMap.find w q with Not_found -> []) q) (WMap.add w rest q) (es v)
 
  let prim es s =
    prim_aux es [] (VSet.singleton s) @@
      (* 始点から伸びる辺をキューに入れておく *)
      List.fold_left (fun q (v, w) ->
        WMap.add w ((s, v) :: try WMap.find w q with Not_found -> []) q) WMap.empty (es s)
end

module Int = struct
  type t = int
  let zero = 0
  let ( + ) = ( + )
  let compare = compare
end

module G = WeightedGraph (Int) (Int)
 
let () = Scanf.scanf "%d\n" (fun n ->
  let xys = Array.to_list @@ Array.init n (fun i -> Scanf.scanf "%d %d\n" (fun x y -> x, y, i)) in
  let es = Array.make n [] in
  begin match List.sort (fun (x, _, _) (x', _, _) -> compare x x') xys with
  | [] -> ()
  | (x, y, i) :: rest ->
      ignore @@ List.fold_left (fun (x, y, i) (x', y', j) ->
        es.(i) <- (j, min (abs (x - x')) (abs (y - y'))) :: es.(i);
        es.(j) <- (i, min (abs (x - x')) (abs (y - y'))) :: es.(j);
        (x', y', j)) (x, y, i) rest
  end;
  begin match List.sort (fun (_, y, _) (_, y', _) -> compare y y') xys with
  | [] -> ()
  | (x, y, i) :: rest ->
      ignore @@ List.fold_left (fun (x, y, i) (x', y', j) ->
        es.(i) <- (j, min (abs (x - x')) (abs (y - y'))) :: es.(i);
        es.(j) <- (i, min (abs (x - x')) (abs (y - y'))) :: es.(j);
        (x', y', j)) (x, y, i) rest
  end;
  G.prim (fun i -> es.(i)) 0
  |> List.map (fun (_, _, w) -> w)
  |> List.fold_left ( + ) 0
  |> Printf.printf "%d\n")
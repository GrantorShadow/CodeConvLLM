let n, m, c = Scanf.scanf " %d %d %d" @@ fun a b c -> a, b, c
let bs = Array.init m @@ fun _ -> Scanf.scanf " %d" (+) 0
let a_ss = Array.init n @@ fun _ -> Array.init m @@ fun _ -> Scanf.scanf " %d" (+) 0
let f ans a_s =
  let s = ref c in for i = 0 to m - 1 do s := !s + a_s.(i) * bs.(i) done; ans + if !s > 0 then 1 else 0
let _ = Array.fold_left f 0 a_ss |> Printf.printf "%d\n"
open Batteries
open Printf
open Scanf

let ($) g f x = g (f x)
let nil = ()

module MyList = struct
  include List
  let foldl = fold_left
  let foldr = fold_right
  
  let flatmap f ls = concat @@ map f ls

  let zipf = map2
  let zipfi = map2i
end

module L = MyList

let atoi = int_of_string
let itoa = string_of_int
let atof = float_of_string
let ftoa = string_of_float
let ctoi = int_of_char
let itoc = char_of_int

let stocl = String.to_list
let cltos = String.of_list
let spsp s = String.split_on_char ' ' s

module MyString = struct
  include String

  let map' f s = L.map f (stocl s)
  let mapi' f s = L.map f (stocl s)

  let zipf f a b = L.zipf f (stocl a) (stocl b)
  let zipfi f a b = L.zipfi f (stocl a) (stocl b)

  let mkstr f sep ls =
    L.foldl (fun acc x -> acc ^ sep ^ (f x)) (f @@ L.hd ls) (List.tl ls)
end

module S = MyString

let tup2 a b = (a, b)
let tup3 a b c = (a, b, c)
let tup4 a b c d = (a, b, c, d)

let rds () = read_line ()
let rds2 () = scanf "%s %s\n" tup2

let rdi () = atoi @@ rds ()
let rdi2 () = scanf "%d %d\n" tup2
let rdi3 () = scanf "%d %d %d\n" tup3
let rdi4 () = scanf "%d %d %d %d\n" tup4

let rdhs () = spsp @@ rds ()
let rdhi () = rdhs () |> L.map atoi

let rdvs n rdf = L.init n (fun _ -> rdf ())

let rdvi n = rdvs n rdi
let rdvi2 n = rdvs n rdi2
let rdvi3 n = rdvs n rdi3
let rdvi4 n = rdvs n rdi4

let puts s = print_endline s

let _ =
  let (s, t) = scanf "%s\n%s\n" tup2 in
  puts (if S.starts_with t s then "Yes" else "No");;


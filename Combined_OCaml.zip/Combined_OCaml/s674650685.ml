let solve x = 800 * x - x / 15 * 200

let () = read_int () |> solve |> string_of_int |> print_endline

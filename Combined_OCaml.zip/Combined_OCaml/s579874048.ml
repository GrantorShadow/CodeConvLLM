let () =
  let r = Scanf.scanf "%f\n" (fun a -> a) in
  let pi = 3.1415926535 in
  Printf.printf "%f %f\n" (pi *. r *. r) (2.0 *. pi *. r)
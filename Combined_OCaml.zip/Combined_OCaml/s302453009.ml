let (%) f g x = f (g x);;
let f a b c = String.concat "" (List.map ((%) (String.make 1) (String.uppercase)) [a.[0];b.[0];c.[0]]);;
Scanf.scanf "%s %s %s"
f
|> Printf.printf "%s\n"
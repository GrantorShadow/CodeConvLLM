let main () =
  let a, b = Scanf.scanf "%d %d\n" (fun a b -> a, b) in
  Printf.printf "%d\n" @@ if a <= b then a else a - 1

let _ = main ()

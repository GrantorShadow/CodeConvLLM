let lower_bound arr v =
  let rec f l r =
    if l >= r then r
    else
      let m = (l+r) / 2 in
      if arr.(m) >= v then f l m else f (m+1) r in
  f 0 (Array.length arr)

let () =
  let n = Scanf.scanf "%d" (fun n -> n) in
  let a = Array.init n (fun _ -> Scanf.scanf " %d" (fun x -> x)) in
  let b = Array.init n (fun _ -> Scanf.scanf " %d" (fun x -> x)) in
  let bm = Array.make n 0 in
  Array.sort (-) a;
  Array.init 29 (fun i ->
    let m, mm = 1 lsl i, 2 lsl i in
    b |> Array.iteri (fun i e -> bm.(i) <- e mod mm);
    Array.sort (-) bm;
    a |> Array.map (fun x ->
      let xm = x mod mm in
      let i1 = lower_bound bm (1 * m - xm) in
      let i2 = lower_bound bm (2 * m - xm) in
      let i3 = lower_bound bm (3 * m - xm) in
      let i4 = lower_bound bm (4 * m - xm) in
      (i2-i1) + (i4-i3))
    |> Array.fold_left (+) 0
    |> (fun s -> (s mod 2) lsl i))
  |> Array.fold_left (+) 0 |> Printf.printf "%d\n"

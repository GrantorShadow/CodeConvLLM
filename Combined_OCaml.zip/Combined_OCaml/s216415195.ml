let () = Scanf.scanf "%d\n" @@ fun n ->
  let abs = Array.init n @@ fun _ -> Scanf.scanf "%d %d\n" @@ fun a b -> a, b in
  Array.sort (fun (a, b) (a', b') -> compare (a' + b') (a + b)) abs;
  Printf.printf "%d\n" @@ Array.fold_left ( + ) 0 @@ Array.init n @@ fun i ->
    if i mod 2 = 0 then fst abs.(i) else ~- (snd abs.(i))
    


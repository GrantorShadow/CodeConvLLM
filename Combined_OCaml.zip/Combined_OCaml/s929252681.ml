let s = read_line ()
let l, r = String.index s 'A', Str.search_backward (Str.regexp "Z") s @@ String.length s - 1
let _ = Printf.printf "%d\n" @@ r - l + 1
let () =
  let n = read_int () in
  let rec loop = function
      0 -> ()
    | i ->(
      let (xa, ya, ra, xb, yb, rb)
        = Scanf.scanf "%f %f %f %f %f %f\n" (fun xa ya ra xb yb rb->(xa, ya, ra, xb, yb, rb)) in
      let d = sqrt((xa-.xb)**2. +. (ya-.yb)**2.) in
      if d +. rb <= ra then print_endline "2"
      else if d +. ra <= rb then print_endline "-2"
      else if d < ra +. rb then  print_endline "1"
      else if d > ra +. rb then print_endline "0"
    );loop (i-1)
  in loop n
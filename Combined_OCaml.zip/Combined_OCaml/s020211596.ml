(* quite naive implementation *)
let rec dikjstra ( +. ) ( < ) q edge d =
  match q with
  | [] -> ()
  | u :: q ->
      let u, q = 
        List.fold_left (fun (u, q') u' ->
          if d.(u) < d.(u') then (u, u' :: q')
          else (u', u :: q')) (u, []) q in
      List.iter (fun (v, c) ->
        if c +. d.(u) < d.(v) then
          d.(v) <- c +. d.(u)) (edge u);
      dikjstra ( +. ) ( < ) q edge d

let array_of_string s = Array.init (String.length s) (fun i -> s.[i])

let () =
  let h, w = Scanf.scanf "%d %d\n" (fun h w -> h, w) in
  let ss = Array.init h (fun _ -> Scanf.scanf "%s\n" (fun s -> s)) in
  let dp = Array.make (h * w) infinity in
  dp.(0) <- 0.;
  dikjstra ( +. ) ( < )
    (Array.init (h * w) (fun i -> i)
      |> Array.to_list
      |> List.filter (fun i ->
        let x = i mod w in
        let y = i / w in
        ss.(y).[x] = '.'))
    (fun i ->
      let x = i mod w in
      let y = i / w in
      [(x + 1, y); (x - 1, y); (x, y + 1); (x, y - 1)]
      |> List.filter (fun (x, y) -> 0 <= x && x < w && 0 <= y && y < h)
      |> List.filter (fun (x, y) -> ss.(y).[x] = '.')
      |> List.map (fun (x, y) -> (y * w + x, 1.))) dp;
  if dp.(h * w - 1) = infinity then print_endline "-1"
  else begin
    Array.map array_of_string ss
    |> Array.map Array.to_list
    |> Array.map (List.filter (( = ) '.'))
    |> Array.map List.length
    |> Array.fold_left ( + ) 0
    |> (fun i -> i - int_of_float dp.(h * w - 1) - 1)
    |> Printf.printf "%d\n"
  end
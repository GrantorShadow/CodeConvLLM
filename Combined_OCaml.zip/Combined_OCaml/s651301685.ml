let uppercase_p c = c >= 'A' && c <= 'Z'

let lowercase_p c = c >= 'a' && c <= 'z'

let uppercase c = Char.chr ((Char.code c) - (Char.code 'a') + (Char.code 'A'))

let lowercase c = Char.chr ((Char.code c) - (Char.code 'A') + (Char.code 'a'))

let rec repl () =
  let c = input_char stdin in
  if uppercase_p c then print_char (lowercase c)
  else if lowercase_p c then print_char (uppercase c)
  else print_char c;
  repl ()

let () =
  try repl () with End_of_file -> ()
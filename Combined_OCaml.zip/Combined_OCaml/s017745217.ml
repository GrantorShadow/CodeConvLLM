let rec seq s t f = if s > t then []
                    else (f s) :: seq (s + 1) t f
let _ =
  let n::k::_ = List.map int_of_string @@ Str.split (Str.regexp "[ \t]+") (read_line ()) in
  let hs = List.map int_of_string @@ Str.split (Str.regexp "[ \t]+") (read_line ()) in
  print_endline @@ string_of_int @@
    List.fold_left (+) 0 @@
      List.map2 (-) (seq 0 (n-1) (fun x -> List.hd hs + x)) hs

let toOp op = match op with
    | "+" -> ( + )
    | "-" -> ( - )
    | "*" -> ( * )
    | "/" -> ( / )
;;


let rec f _ = 
    let (a, op, b) = Scanf.sscanf(read_line()) "%d %s %d" (fun x y z -> (x, y, z)) in
    if op = "?" then ()
    else (
        Printf.printf "%d\n" ((toOp op) a b);
        f ()
    );;

f ();;

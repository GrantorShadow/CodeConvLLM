module MakeBinaryHeap (M : sig type t val compare : t -> t -> int end) = struct
  type t = { node : M.t array; mutable size : int }

  let make n (init : M.t) = { node = Array.make n init; size = 0 }

  let empty_p t = if t.size = 0 then true else false

  let pop t =
    let ret = t.node.(1) in
    t.node.(1) <- t.node.(t.size);
    t.size <- t.size - 1;
    let rec max_heapify i =
      let l = 2*i in
      let r = 2*i + 1 in
      let m = if l <= t.size && M.compare t.node.(l) t.node.(i) > 0 then l else i in
      let m = if r <= t.size && M.compare t.node.(r) t.node.(m) > 0 then r else m in
      if m <> i then begin
        let tmp = t.node.(i) in t.node.(i) <- t.node.(m); t.node.(m) <- tmp;
        max_heapify m
      end in
    max_heapify 1;
    ret

  let push x t =
    t.size <- t.size + 1;
    t.node.(t.size) <- x;
    let parent i = int_of_float (floor (float_of_int i) /. 2.) in
    let rec doit i =
      if i > 1 && M.compare t.node.(parent i) t.node.(i) < 0 then begin
        let tmp = t.node.(i) in t.node.(i) <- t.node.(parent i); t.node.(parent i) <- tmp;
        doit (parent i)
      end in
    doit t.size
end

module H = MakeBinaryHeap(struct type t = (int * int) let compare x y = snd x - snd y end)

let dijkstra g n =
  let h = H.make 100000 (0, 0) in
  let d = Array.make n max_int in
  let b = Array.make n false in
  d.(0) <- 0;
  b.(0) <- true;
  H.push (0, 0) h;
  let rec doit () =
    if not (H.empty_p h) then begin
      let (u, x) = H.pop h in
      b.(u) <- true;
      if d.(u) >= -x then duduwa u g.(u);
      doit ()
    end
  and duduwa u = function
    | [] -> ()
    | (v, c) :: tl when b.(v) = true || d.(v) <= d.(u) + c -> duduwa u tl
    | (v, c) :: tl ->
      begin
        d.(v) <- d.(u) + c;
        H.push (v, -d.(v)) h;
        duduwa u tl
      end in
  doit ();
  d

let rec make_pair acc = function
  | [] -> acc
  | v :: c :: tl -> make_pair ((v, c) :: acc) tl
  | _ -> exit 1

let () =
  let n = read_int () in
  let g = Array.make n [] in
  let rec read i =
    if i < n then
      match List.map int_of_string (Str.split (Str.regexp " ") (read_line ())) with
      | u :: _ :: l -> (g.(u) <- make_pair [] l; read (i + 1))
      | _ -> exit 1
  in read 0;
  Array.iteri (fun i e -> print_int i; print_string " "; print_int e; print_string "\n") (dijkstra g n)
open Printf
open Scanf

let solve a b c = if a + b + c > 21 then "bust" else "win"

let () =
  scanf "%d %d %d " solve |> printf "%s\n"

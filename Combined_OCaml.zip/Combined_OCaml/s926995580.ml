(* O(2^|s| |s|) *)
let s = read_line () in
let slen = String.length s in
let f bits =
  let m = slen - 1 in
  let b = Buffer.create @@ 2 * slen in
  Buffer.add_char b s.[0];
  for i = 1 to m do
    if bits lsr (m - i) land 1 = 1 then Buffer.add_char b '+';
    Buffer.add_char b s.[i];
  done;
  Buffer.to_bytes b |> Bytes.to_string |> Str.split (Str.regexp "+")
  |> List.map int_of_string |> List.fold_left (+) 0 in
Array.init (1 lsl (slen - 1)) f |> Array.fold_left (+) 0 |> Printf.printf "%d\n"
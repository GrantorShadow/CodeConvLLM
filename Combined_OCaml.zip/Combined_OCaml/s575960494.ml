type point = { x: int; y: int; black: bool }

let () =
  let (n, k) = Scanf.scanf "%d %d\n" (fun n k -> (n, k)) in
  let ps = Array.make n { x = 0; y = 0; black = true } in
  for i = 0 to n-1 do
    Scanf.scanf "%d %d %s\n" (fun x y s -> ps.(i) <- { x = x mod (2 * k); y = y mod (2 * k); black = (s = "B")})
  done;
  let max_num = ref 0 in
  for x = -k to k-1 do
    for y = -k to k-1 do
      let num = ref 0 in
      for i = 0 to n - 1 do
        let p = ps.(i) in
        let black = (x <= p.x && p.x < x + k) && (y <= p.y && p.y < y + k) in
        if black = p.black then num := !num + 1 else ();
      done;
      max_num := max !max_num !num;
    done
  done;
  print_int !max_num
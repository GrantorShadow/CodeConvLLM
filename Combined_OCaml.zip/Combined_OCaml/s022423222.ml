let solve s =
  let t = Array.make 26 false in
  String.iter (fun c -> t.(Char.code c - Char.code 'a') <- true) s;
  let rec doit i =
    if i = 26 then "None"
    else if not t.(i) then i + Char.code 'a' |> Char.chr |> String.make 1
    else doit (i + 1) in
  doit 0

let () = read_line () |> solve |> print_endline
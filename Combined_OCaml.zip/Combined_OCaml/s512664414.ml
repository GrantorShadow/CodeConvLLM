print_endline @@ Scanf.scanf "%d %d %d %d" @@ fun n m x y ->
let xM = Array.init n (fun _ -> Scanf.scanf " %d" ((+) 1)) |> Array.fold_left max (-100) in
let ym = Array.init m (fun _ -> Scanf.scanf " %d" ((+) 0)) |> Array.fold_left min 100 in
if max xM (x+1) <= min ym y then "No War" else "War"
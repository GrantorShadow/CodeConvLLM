let () =
  Scanf.scanf "%d %d" @@ fun m k ->
  if m <= 1 then
    if k = 0 then begin
      for i = 0 to (1 lsl m) - 1 do
        Printf.printf "%d %d " i i
      done;
      print_newline ()
    end
    else print_endline "-1"
  else if k < (1 lsl m) then begin
      for j = (1 lsl m) - 1 downto 0 do
        if j <> k then Printf.printf "%d " j
      done;
      Printf.printf "%d " k;
      for j = 0 to (1 lsl m) - 1 do
        if j <> k then Printf.printf "%d " j
      done;
      Printf.printf "%d " k;
      print_newline ()
  end else print_endline "-1"


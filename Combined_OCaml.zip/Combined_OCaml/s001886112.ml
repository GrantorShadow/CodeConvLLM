let as_num_list s =
  let splitted = String.split_on_char ' ' s in
  List.map int_of_string splitted

let rec gcd a b =
  if b = 0
  then a
  else gcd b (a mod b)

let main () =
  let n = Scanf.sscanf (read_line ()) "%d" (fun x -> x) in
  let as_str = read_line () in
  let a_list = as_num_list as_str in
  let sum = ref 0 in
  let isPairwise = ref true in
  (
    for i = 0 to n - 2 do
      for j = i + 1 to n - 1 do
        if gcd (List.nth a_list i) (List.nth a_list j) <> 1
        then isPairwise := false
      done
    done;
    if !isPairwise
    then Printf.printf "pairwise coprime"
    else
      if List.fold_left gcd (List.hd (List.sort compare a_list)) a_list = 1
      then Printf.printf "setwise coprime"
      else Printf.printf "not coprime";
    print_newline ()
  )

let _ = main ()

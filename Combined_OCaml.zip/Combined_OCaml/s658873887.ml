module IntSet = Set.Make (struct
  type t = int
  let compare = compare
end)

let () = Scanf.scanf "%d %d\n" @@ fun n m ->
  let ass = Array.init n @@ fun _ ->
    Scanf.scanf "%d " @@ fun k ->
      let as_ = Array.init k @@ fun _ -> Scanf.scanf "%d " @@ fun a -> a in
      IntSet.of_list @@ Array.to_list as_ in
  Printf.printf "%d\n" @@ IntSet.cardinal @@ Array.fold_left IntSet.inter ass.(0) ass

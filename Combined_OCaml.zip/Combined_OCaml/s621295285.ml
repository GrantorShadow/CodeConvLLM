(*
ocamlfind ocamlopt -package batteries -linkpkg main.ml -o a.out
*)
open Batteries

let () =
        Str.split (Str.regexp "[B|D|E|F|H|I|J|K|L|M|N|O|P|Q|R|S|U|V|W|X|Y|Z]") (read_line ())
        |> List.max
        |> String.length
        |> Printf.printf "%d\n"

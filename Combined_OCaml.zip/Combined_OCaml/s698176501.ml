let sum : int  -> int -> int =  fun x y ->
try x + y with
s when s > 9 -> print_int s;
_ -> print_string "error";
;;
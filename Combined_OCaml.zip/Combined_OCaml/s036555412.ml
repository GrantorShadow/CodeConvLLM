let () =
  Scanf.scanf "%d %d\n" @@ fun h w ->
  Printf.printf "%d\n"
    (if h mod 2 = 0 then h / 2 * w
     else if w mod 2 = 0 then h * (w / 2)
     else h * (w / 2) + h / 2 + 1)
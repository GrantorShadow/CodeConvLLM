Scanf.scanf "%d %f" (fun a b -> print_int (a * int_of_float (b *. 100.) / 100))

let rec read list = function
    0 -> list
  | i ->
     let n = read_int () in read (n::list) (i-1)
;;

let get_sum3 list =
  let sorted = List.sort compare list |> List.rev in
  let rec f sum l = function
      3 -> sum
    | i -> f (sum + (List.hd l)) (List.tl l) (i+1)
  in f 0 sorted 0
;;

let () =
  let w = read [] 10 |> get_sum3 and
      k = read [] 10 |> get_sum3 in
  Printf.printf "%d %d\n" w k
;;
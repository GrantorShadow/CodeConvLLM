Scanf.scanf "%s" (fun s ->
    let rec loop i acc =
        if i = 16 then acc else
            let acc = if s.[i] <> "CODEFESTIVAL2016".[i] then acc + 1 else acc in
            loop (i + 1) acc
    in
    loop 0 0 |> Printf.printf "%d\n"
)
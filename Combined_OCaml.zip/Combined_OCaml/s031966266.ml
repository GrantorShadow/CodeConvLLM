let () =
  let (n, k) = Scanf.scanf "%d %d " (fun n k -> (n, k)) in
  let a = Array.init n (fun _ -> Scanf.scanf "%d " (fun i -> i)) in
  Array.fast_sort (fun a b -> b - a) a;
  let ans = ref 0 in
  for i = 0 to k - 1 do
    ans := !ans + a.(i);
  done;
  Printf.printf "%d\n" !ans
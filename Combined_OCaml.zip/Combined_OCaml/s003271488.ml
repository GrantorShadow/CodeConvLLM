Scanf.scanf "%d %d %d %d" (fun a b c d ->
    let q = a + b in
    let r = c + d in
    print_endline @@
    if q > r then "Left" else
        if q < r then "Right" else "Balanced"
)
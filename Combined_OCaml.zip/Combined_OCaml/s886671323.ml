open Batteries
open Printf
let () =
  let a,b = Scanf.scanf "%d %d " (fun a b -> a,b) in
  Printf.printf "%s\n" @@
    if a + b >= 10 then "error" else string_of_int (a+b)

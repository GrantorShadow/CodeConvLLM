let () =
  Scanf.scanf " %d %d %d" @@ fun n m k ->
  let arr1 = Array.init n (fun _ -> Scanf.scanf " %d" (fun x -> x)) in
  let arr2 = Array.init m (fun _ -> Scanf.scanf " %d" (fun x -> x)) in
  let lst1 = Array.to_list arr1 in
  let lst2 = Array.to_list arr2 in
  let time = ref k in
  let rec g lst n = match lst with
   | [] -> n
   | first :: rest -> if first <= !time then (time := !time - first; g rest (n + 1))
                      else n in
  let rec f l1 l2 n = match (l1, l2) with
  | ([], []) -> n
  | ([], _) -> g l2 n
  | (_, []) -> g l1 n
  | (first1 :: rest1, first2 :: rest2) ->
    if first1 <= !time || first2 <= !time then 
    (if first1 < first2 then (time := !time - first1; f rest1 l2 (n + 1))
     else (time := !time - first2; f l1 rest2 (n + 1)))
    else n in
  Printf.printf "%d" (f lst1 lst2 0)
  
let rec fix f x = f (fix f) x;;
Scanf.(Array.(scanf " %d %d" @@ fun n m ->
  let e = make n [] in
  let e_rev = make n [] in
  init (n-1+m) (fun i -> scanf " %d %d" @@ fun u v ->
    let u,v = u-1,v-1 in
    e.(u) <- v :: e.(u);
    e_rev.(v) <- u :: e_rev.(v)
  ) |> ignore;
  let root = fst @@ fold_left (fun (root,i) ls ->
    (if List.length ls = 0 then i else root),i+1
  ) (0,0) e_rev in
  let q = Queue.create () in
  let v_left = init n (fun i -> List.length e_rev.(i)) in
  Queue.add root q;
  let par = make n 0 in
  while not @@ Queue.is_empty q do
    let i = Queue.pop q in
    List.iter (fun j ->
      v_left.(j) <- v_left.(j) - 1;
      if v_left.(j) = 0 then (
        par.(j) <- i + 1;
        Queue.add j q;
      )
    ) e.(i)
  done;
  iter (Printf.printf "%d\n") par
))
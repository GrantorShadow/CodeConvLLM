Scanf.scanf "%d %d" (fun n c ->
    let ch = Array.make c [] in
    for i = 1 to n do
        Scanf.scanf " %d %d %d" (fun s t c -> ch.(c - 1) <- (s, t) :: ch.(c - 1))
    done;
    let fr = Array.make 100001 0 in
    for i = 0 to c - 1 do
        let rec loop prevend = function
            | [] -> if prevend >= 0 then fr.(prevend) <- fr.(prevend) - 1
            | (s, t) :: tl ->
                    if s = prevend then loop t tl else (
                        if prevend >= 0 then fr.(prevend) <- fr.(prevend) - 1;
                        fr.(s - 1) <- fr.(s - 1) + 1;
                        loop t tl
                    )
        in
        loop (-1) (List.sort compare ch.(i))
    done;
    let asm = Array.make 100001 0 in
    asm.(0) <- fr.(0);
    for i = 1 to 100000 do
        asm.(i) <- asm.(i - 1) + fr.(i)
    done;
    Array.fold_left max 0 asm |> Printf.printf "%d\n"
)
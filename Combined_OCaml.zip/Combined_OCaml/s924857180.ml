let () =
  Scanf.scanf "%d %d %d" (fun a b c -> 
      (a + b + c) - (max a (max b c))) |> Printf.printf "%d\n"
let p=4.*.atan 1.;;let r=read_float();;Printf.printf"%f %f
"(p*.r*.r)(2.*.p*.r)
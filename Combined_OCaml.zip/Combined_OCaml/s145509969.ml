open Batteries
open Printf
let () =
  let n = Scanf.scanf "%d " (fun a -> a) in
  let a_lst = Array.to_list @@ Array.init n (fun _ -> Scanf.scanf "%d " (fun a -> a)) in

  let ma = List.max a_lst in
  let mi = List.min a_lst in

  Printf.printf "%d\n" @@
  ma - mi

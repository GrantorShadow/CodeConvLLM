open Batteries
open Printf
let () =
  let n,k = Scanf.scanf "%d %d " (fun a b -> a,b) in

  Printf.printf "%d\n" @@
  n mod k


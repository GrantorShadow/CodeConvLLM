let make_gate_list l r =
  let rec hoge l r =
    if l > r then
      []
    else
      l :: hoge (l + 1) r
  in
    hoge l r


let hikaku_lst lst1 lst2 =
  let hikaku n =
    List.filter (fun m -> n = m) lst2
  in
    List.map hikaku lst1 |> List.concat


let () = Scanf.scanf "%d %d\n" (fun n m ->
    let card_lst = make_gate_list 1 n in
    let rec loop i lst =
      if i = m then
      card_lst else
        let i = i + 1 in
        Scanf.scanf "%d %d\n" (fun l r ->
          let gate_list = make_gate_list l r in
          let ok_list = hikaku_lst gate_list lst in
          hikaku_lst ok_list (loop i ok_list)
        )
      in
    let lst = loop 0 card_lst in
     Printf.printf "%d" (List.length lst)
)

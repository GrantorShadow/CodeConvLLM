let () = Scanf.scanf "%d" (fun n -> 
let ans =
	let rec solve ans' = 
	if ans' - 111 < n then ans' 
	else solve (ans' - 111)
   	in solve 999
    in 
 Printf.printf "%d" ans)
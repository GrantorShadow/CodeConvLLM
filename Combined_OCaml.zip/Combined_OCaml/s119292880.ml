exception Break

let _ =
  let a_cards = read_line () in
  let b_cards = read_line () in
  let c_cards = read_line () in
  let a_index = ref 0 in
  let b_index = ref 0 in
  let c_index = ref 0 in
  let next = ref 'a' in
  try
    while true do
      let cards =
        match !next with
        | 'a' -> a_cards
        | 'b' -> b_cards
        | _   -> c_cards in
      let index =
        match !next with
        | 'a' -> a_index
        | 'b' -> b_index
        | _   -> c_index in
      if !index >= String.length cards
      then (print_char (Char.uppercase_ascii !next);
            print_newline ();
            raise Break
           )
      else (next := String.get cards !index;
            index := !index + 1
           )
    done
  with Break -> ()

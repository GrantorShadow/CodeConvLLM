open Batteries
open BatPrintf

let scan fmt f =
  Scanf.sscanf (read_line ()) fmt f

let scan_list cnv =
  read_line ()
  |> String.split_on_char ' '
  |> List.map cnv

let scan_listn n cnv =
  List.range 1 `To n |> List.map (fun _ -> (cnv % read_line) ())

let bsearch_ge arr a =
  let l = Array.length arr in
  match Array.bsearch Int.ord arr a with
  | `All_lower -> l
  | `All_bigger -> 0
  | `Just_after n -> l - n -1
  | `At n -> l - n
  | `Empty -> 0

let rec zip xs ys =
  match xs, ys with
  | [], _ -> []
  | _, [] -> []
  | x::xs, y::ys ->
    (x, y) :: zip xs ys

let square x = x * x

let dbg n = Printf.eprintf "%s\n" @@ dump n; n

let (n, m) = scan "%d %d" Tuple.Tuple2.make
let l = scan_listn m (fun s -> String.split_on_char ' ' s
                               |> List.map Int.of_string
                               |> (fun l -> (List.at l 0, List.at l 1)))

let () =
  printf "-1"
(* let arr = Array.make n None in
 * List.fold_left (fun r (s, c) ->
 *     match arr.(s-1) with
 *     | None -> arr.(s-1) <- Some c; r && true
 *     | Some n -> r && if n = c then true else false
 *   ) true l
 * |> (fun ans -> printf "%s\n"
 *        (if ans then
 *           match arr.(0) with
 *           | Some 0 -> "-1"
 *           | _ -> if arr.(0) = None then arr.(0) <- Some 1;
 *             Array.map (function | None -> "0" | Some c -> String.of_int c) arr
 *             |> Array.to_list
 *             |> String.concat ""
 *         else "-1")) *)

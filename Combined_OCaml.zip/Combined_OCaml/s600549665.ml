let x = read_int ()
let () = print_endline @@ if x >= 30 then "Yes" else "No"

let () =
    let main () =
        let a, p = Scanf.sscanf (read_line ()) "%d %d" (fun a p -> a, p) in
        Printf.printf "%d\n" ((a * 3 + p) / 2)
    in
    main ()
let () =
  let (n, a, b) = Scanf.sscanf (input_line stdin) "%d %d" (fun n a b -> (n, a, b)) in
  if n * a <= b then
    (print_int (n * a);
     print_newline ())
  else
    (print_int b;
     print_newline ())    

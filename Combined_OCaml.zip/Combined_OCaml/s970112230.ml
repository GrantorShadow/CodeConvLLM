let () =
  let n = Scanf.scanf "%d\n" (fun n -> n) in
  let as_ = Array.init n (fun _ -> Scanf.scanf "%d " (fun a -> a)) in
  let lst = Array.fold_left (fun xs a -> a :: xs) [] as_ in
  match lst with
    [] -> print_newline()
   |first :: rest ->
    begin
      print_int first;
      List.iter (Printf.printf " %d") rest
    end ;
    print_newline() ;;

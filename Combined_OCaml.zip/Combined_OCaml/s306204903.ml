et calc a b s =
    let f v i c = v && (if i = a then c = '-' else c <> '-') in
    BatString.fold_lefti f true s

let a1 = calc 3 4 "269-6650"
let a2 = calc 1 1 "---"
let a3 = calc 1 2 "7444"

let main =
    let [a; b] = read_line () |> BatString.split_on_char ' ' |> List.map int_of_string in
    let s = read_line () in
    let v = (calc a b s) in
    print_endline (if v then "Yes" else "No")

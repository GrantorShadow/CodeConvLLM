open Scanf
open Printf
open String

(* Scanf.sscanf (read_line ()) "%d %d" 
             (fun x y -> Printf.printf "%d" ((x-1)*(y-1)));; *)

let abb s = (sub s 0 1) 
            ^ (string_of_int (length s - 2))
            ^ (sub s (length s - 1) 1);;

sscanf (read_line ()) "%s"
          (fun s -> printf "%s" (abb s));;

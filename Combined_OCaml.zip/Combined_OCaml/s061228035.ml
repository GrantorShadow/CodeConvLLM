let get_index = function
    "A" -> 0
  | "B" -> 1
  | "C" -> 2
  | _ -> -1

let swap a i j =
  let temp = a.(i) in
  a.(i) <- a.(j);
  a.(j) <- temp;;

let () =
  let cup = [|1;0;0|] in
  let rec read () =
    try let l = read_line ()
                |> Str.split (Str.regexp_string ",")
        in
        swap cup (get_index (List.nth l 0)) (get_index (List.nth l 1));
        read ()
    with End_of_file ->
      if cup.(0) = 1 then
        print_endline "A"
      else if cup.(1) = 1 then
        print_endline "B"
      else if cup.(2) = 1 then
        print_endline "C"
      else
        print_endline ""
  in read ()
;;
(*
ocamlfind ocamlopt -package batteries -linkpkg main.ml -o a.out
*)
open Batteries

let h = Scanf.sscanf (read_line ()) "%d" (
        fun h -> 
                h
)

let rec f h =
        if h = 1 then
                1
        else
                2 * (f (h / 2)) + 1

let () =
        f h
        |> Printf.printf "%d\n"

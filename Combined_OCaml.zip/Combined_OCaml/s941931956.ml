let () = Scanf.scanf "%d %d\n" @@ fun k q ->
  let ds = Array.init k @@ fun _ -> Scanf.scanf "%d " @@ fun d -> d in
  for i = 0 to q - 1 do
    Scanf.scanf "%d %d %d\n" @@ fun n x m ->
      let acc = Array.make (k + 1) 0 in
      for i = 0 to k - 1 do
        acc.(i + 1) <- (if ds.(i) mod m = 0 then m else ds.(i) mod m) + acc.(i)
      done;
      Printf.printf "%d\n" @@
      n - 1 - (x + acc.(k) * ((n - 1) / k) + acc.((n - 1) mod k)) / m + x / m
  done
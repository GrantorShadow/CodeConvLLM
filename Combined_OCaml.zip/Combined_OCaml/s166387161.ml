let (+@) a b = (a + b) mod 998244353
let () =
  Scanf.scanf "%s" @@ fun s ->
  let n = String.length s in
  let thres_b = Array.init (2*n+1) (fun i ->
    if i = 0 then 0
    else if i <= n then int_of_char s.[i-1] - int_of_char '0'
    else 0) in
  for i = 1 to 2*n do thres_b.(i) <- thres_b.(i) + thres_b.(i-1) done;
  let thres_r = Array.init (2*n+1) (fun i -> 2 * (min i n) - thres_b.(i)) in

  let r, b = thres_r.(n), thres_b.(n) in
  let dp = Array.init (r+1) (fun _ -> Array.make (b+1) 0) in
  dp.(0).(0) <- 1;
  for w = 1 to 2*n do
    for r = max 0 (w - thres_b.(w)) to min w thres_r.(w) do
      let b = w - r in
      if r > 0 then dp.(r).(b) <- dp.(r).(b) +@ dp.(r-1).(b);
      if b > 0 then dp.(r).(b) <- dp.(r).(b) +@ dp.(r).(b-1);
    done;
  done;

  Printf.printf "%d\n" dp.(r).(b)
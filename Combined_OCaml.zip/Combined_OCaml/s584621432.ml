let f = compare
let i, j = Scanf.scanf "%s %s" @@ fun a b -> String.(f (length a) (length b)), f a b
let _ = print_endline @@ [|"LESS"; "EQUAL"; "GREATER"|].(1 + if i = 0 then j else i)
let a, b, x = Scanf.scanf " %d %d %d" @@ fun a b c -> a, b, c
let f k = k / x + 1
let _ = Printf.printf "%d\n" @@ f b - if a = 0 then 0 else f @@ a - 1
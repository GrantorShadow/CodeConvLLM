let rec solve n k candidates =
  if k < n
  then List.nth candidates k
  else
    let n', candidates' =
      List.fold_left (fun (n', candidates') x ->
        match x mod 10 with
        | 0 -> (n' + 2, 10 * x + 1 :: 10 * x :: candidates')
        | 9 -> (n' + 2, 10 * x + 9 :: 10 * x + 8 :: candidates')
        | _ -> (n' + 3, 10 * x + x mod 10 + 1 :: 10 * x + x mod 10 :: 10 * x + x mod 10 - 1 :: candidates')) (0, []) candidates in
    solve n' (k - n) @@ List.rev candidates'
let solve k = solve 9 k [1; 2; 3; 4; 5; 6; 7; 8; 9]

let () = Scanf.scanf "%d" @@ fun k ->
  Printf.printf "%d\n" @@ solve @@ k - 1
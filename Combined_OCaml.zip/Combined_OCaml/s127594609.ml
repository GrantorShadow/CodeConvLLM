open Batteries
(* purpose
       集会場所の座標PとN人の人が住んでいる座標リストから距離の2乗の総和を求める 
*)
(* function type
        solver : int -> int list -> int
*)
let rec solver p lst =
        match lst with
                  [] -> 0
                | first :: rest -> 
                        ((first - p) * (first - p)) + (solver p rest)

(* purpose
 * 距離の総和が最小になるPがnからmまでのどこかにある時の距離の総和の最小値を求める
*)
(* function type
        solver2 : int -> int -> int list -> int(ac) -> int
*)
let rec solver2 n m lst = 
                if m = (n + 1) then
                        solver n lst
                else
                        let p = (n + m) / 2 in
                        let lp = (n + p) / 2 in
                        let rp = (p + 1 + m) / 2 in
                        let lsum = solver lp lst in
                        let rsum = solver rp lst in
                                if lsum < rsum then
                                        solver2 n p lst
                                else
                                        solver2 (p + 1) m lst

let lst = Scanf.scanf "%d\n" (
        fun n -> 
                Str.split (Str.regexp " ") (read_line ()) 
                |> List.map int_of_string
)

let () = 
        let minlst = List.min lst in
        let maxlst = List.max lst in
                solver2 minlst maxlst lst
                |> Printf.printf "%d\n"


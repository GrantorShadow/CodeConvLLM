let rec fix f x = f (fix f) x;;
(0,read_line())|>fix(fun f (i,s)->
	if i>=String.length s then [] else s.[i]::f (i+1,s))
	|> List.fold_left(fun (c,p) v->(if p=v then c else c+1),v)(-1,':')
	|> fst |> print_int
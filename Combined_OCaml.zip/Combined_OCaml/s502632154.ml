let levenshtein_distance s t =
  let m = String.length s in
  let n = String.length t in
  let d = Array.make_matrix (m + 1) (n + 1) 0 in
  let rec dudu i =
    if i <= m then begin
      d.(i).(0) <- i;
      dudu (i + 1)
    end in
  let rec wa i =
    if i <= n then begin
      d.(0).(i) <- i;
      wa (i + 1)
    end in
  let rec doit = function
    | (i, _) when i > n -> d.(m).(n)
    | (i, j) when j > m -> doit (i + 1, 1)
    | (i, j) ->
      let c = if s.[i-1] = t.[j-1] then 0 else 1 in
      d.(i).(j) <- if d.(i-1).(j) + 1 < d.(i).(j-1) + 1 then d.(i-1).(j) + 1 else d.(i).(j-1) + 1;
      d.(i).(j) <- if d.(i-1).(j-1) + c < d.(i).(j) then d.(i-1).(j-1) + c else d.(i).(j);
      doit (i, j + 1) in
  dudu 1; wa 1; doit (1, 1)

let () =
  let s1 = read_line () in
  let s2 = read_line () in
  Printf.printf "%d\n" (levenshtein_distance s1 s2)
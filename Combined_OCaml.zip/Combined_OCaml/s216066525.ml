module IntSet = Set.Make (struct
  type t = int
  let compare = compare
end)

let () =
  let n = Scanf.scanf "%d\n" (fun n -> n) in
  let as_ = Array.init n @@ fun i -> Scanf.scanf "%d " @@ fun a -> i, a in
  Array.to_list as_
    |> List.sort (fun (_, a) (_, a') -> compare a a')
    |> List.fold_left (fun (acc, s) (j, a) ->
        let (lt, _, gt) = IntSet.split j s in
        let i = try IntSet.max_elt lt with Not_found -> -1 in
        let k = try IntSet.min_elt gt with Not_found -> n in
        (acc + (k - j) * (j - i) * a, IntSet.add j s)) (0, IntSet.empty)
    |> fst
    |> Printf.printf "%d\n"

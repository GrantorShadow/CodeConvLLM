let applepie a p = (a * 3 + p) / 2

let a, p = Scanf.sscanf (read_line ()) "%d %d" (fun a p -> (a, p))
let () = Printf.printf "%d\n" (applepie a p)
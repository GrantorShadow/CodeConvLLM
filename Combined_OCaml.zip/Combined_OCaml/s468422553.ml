let scan_string () = Scanf.scanf " %s" (fun x -> x)
let print_int n = Printf.printf "%d\n" n

let () =
  let s = scan_string() and t = scan_string() in
  let judge i = if (s.[i] == t.[i]) then 1 else 0 in
  print_int (judge 0 + judge 1 + judge 2)

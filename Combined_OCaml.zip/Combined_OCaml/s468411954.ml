let memoize n f =
  let dp = Hashtbl.create n in
  let rec get x =
    try Hashtbl.find dp x with
    | Not_found ->
        let result = f get x in
        Hashtbl.add dp x result;
        result in
  get

let () =
  let n, z, w = Scanf.scanf "%d %d %d\n" (fun n z w -> n, z, w) in
  let as_ = Array.init n (fun _ -> Scanf.scanf "%d " (fun a -> a)) in
  let as' = Array.init (n + 2) (function 0 -> z | 1 -> w | i -> as_.(i - 2)) in
  let solve = memoize (n * n) (fun self i j ->
    if j = n + 1 then abs (as'.(i) - as'.(j)), abs (as'.(i) - as'.(j))
    else
      Array.init (n - j + 1) (fun k -> self j (1 + k + j))
      |> Array.fold_left (fun (z, w) (x, y) -> (max z x, min w y)) (min_int, max_int)) in
  Printf.printf "%d\n" @@ fst @@ solve 0 1
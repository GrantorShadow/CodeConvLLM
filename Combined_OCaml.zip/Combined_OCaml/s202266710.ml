let () =
  print_endline @@
  Scanf.scanf "%2d %2d" @@ fun a b ->
  if 1 <= a && a <= 12 && 1 <= b && b <= 12 then "AMBIGUOUS"
  else if 1 <= a && a <= 12 then "MMYY"
  else if 1 <= b && b <= 12 then "YYMM"
  else "NA"

read_int ()
|> (fun x -> x*x*x)
|> print_int;

print_newline
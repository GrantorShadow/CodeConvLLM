let () =
    let n = read_line () in
    let k = read_int () in
    let l = String.length n in
    let arr = Array.make l 0 in
    for i = 0 to l - 1 do
        arr.(i) <- int_of_char n.[i] - int_of_char '0'
    done;

    let rec loop i border_num c0 c1 c2 c3 =
        if i = l then (
            let c1 = if border_num = 1 then c1 + 1 else c1 in
            let c2 = if border_num = 2 then c2 + 1 else c2 in
            let c3 = if border_num = 3 then c3 + 1 else c3 in
            if k = 1 then c1 else if k = 2 then c2 else c3
        ) else
            loop (i + 1) (if arr.(i) <> 0 then border_num + 1 else border_num) 
            (c0 +                                                                 if border_num = 0 && arr.(i) > 0 then 1 else 0)
            (c1 + c0 * 9 + if border_num = 0 && arr.(i) > 0 then arr.(i) - 1 else if border_num = 1 && arr.(i) > 0 then 1 else 0)
            (c2 + c1 * 9 + if border_num = 1 && arr.(i) > 0 then arr.(i) - 1 else if border_num = 2 && arr.(i) > 0 then 1 else 0)
            (c3 + c2 * 9 + if border_num = 2 && arr.(i) > 0 then arr.(i) - 1 else if border_num = 3 && arr.(i) > 0 then 1 else 0)
    in
    loop 0 0 0 0 0 0 |> Printf.printf "%d\n"
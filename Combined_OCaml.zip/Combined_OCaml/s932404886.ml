let split str =
  let rec split_inner ct b=
    if String.length str = ct then [b]
    else
      match str.[ct] with
        ' ' -> b::split_inner (ct+1) ""
      | c -> split_inner (ct+1) (b^(Char.escaped c))
  in split_inner 0 "";;

let () =
  let _n = read_line ()
  and s = read_line () in
  let l = split s in
  let result =
    List.fold_left (fun x y -> y^" "^x) "" l
  in
  Printf.printf "%s\n" result;;
(*
ocamlfind ocamlopt -package batteries -linkpkg main.ml -o a.out
*)
open Batteries

let x, n = Scanf.sscanf (read_line ()) "%d %d" ( fun x n -> x, n)
let lst = Str.split (Str.regexp " ") (read_line ())
          |> List.map int_of_string

let () = 
        let (ans, _) = 
                (
                        if lst = [] then
                                (x, 0)
                        else
                                let set = 
                                        (
                                                let max = List.max lst in
                                                let pset = List.range (-1) `To (max + 1)
                                                           |> Set.of_list in
                                                let sset = Set.of_list lst in
                                                        Set.diff pset sset 
                                        ) in
                                let lst = Set.to_list set in
                                        List.map (fun elmnt -> (elmnt, abs (elmnt - x))) lst 
                                        |> List.sort (fun (el1, diff1) (el2, diff2) -> compare diff1 diff2)
                                        |> List.hd
                ) in
                Printf.printf "%d\n" ans

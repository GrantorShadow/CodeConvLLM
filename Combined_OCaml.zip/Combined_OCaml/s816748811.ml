let s = read_line ()
let w = read_int ()
let _ = String.iteri (fun i c -> if i mod w = 0 then print_char c) s; print_newline ()
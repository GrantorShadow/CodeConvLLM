let width a b =
  if a * b > 0 then
    max (abs a) (abs b)
  else
    (abs a) + (abs b) + (min (abs a) (abs b))

let make_list f t step =
  let rec make_list_inner c t lst =
    if c >= t then lst else make_list_inner (c+step) t (c::lst)
  in
  List.rev (make_list_inner f t [])
  
let solve n k list = match list with
  | x::[] -> x
  | _ ->
     let arr = Array.of_list list in
     let widths = List.map (fun s ->width arr.(s) arr.(s + k - 1)) (make_list 0 (n-k) 1) in
     List.fold_left (fun x acc -> min x acc) (max_int) widths

let read_list_of_int () =
  let rec read_list_of_int_inner lst =
    try let ans = (Scanf.scanf "%d " (fun x->x)) in
        read_list_of_int_inner (ans::lst)
    with End_of_file ->
      List.rev lst
  in
  read_list_of_int_inner []

let () =
  let n, k = (Scanf.scanf "%d %d\n" (fun x y -> x,y)) in
  let list = read_list_of_int () in
  let ans = solve n k list in
  Printf.printf "%d\n" ans;
;;

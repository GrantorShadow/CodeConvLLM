let max_m = 2000

let make_dp a n =
  let dp = Array.make_matrix (n + 1) (max_m + 1) false in
  let rec duduwa i =
    if i <= n then begin
      dp.(i).(a.(i-1)) <- true;
      duduwa (i + 1)
    end in
  let rec doit = function
    | (i, _) when i > n -> dp
    | (i, j) when j > max_m -> doit (i + 1, 1)
    | (i, j) ->
      if dp.(i-1).(j) then dp.(i).(j) <- true
      else if j > a.(i-1) && dp.(i-1).(j-a.(i-1)) then dp.(i).(j) <- true;
      doit (i, j + 1) in
  duduwa 1;
  doit (1, 1)

let () =
  let read_ns () = List.map int_of_string (Str.split (Str.regexp " ") (read_line ())) in
  let n = read_int () in
  let a = Array.of_list (read_ns ()) in
  let _ = read_int () in
  let dp = make_dp a n in
  let m = read_ns () in
  List.iter (fun e -> print_endline (if dp.(n).(e) then "yes" else "no")) m
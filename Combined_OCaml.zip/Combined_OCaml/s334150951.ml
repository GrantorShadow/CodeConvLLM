let () =
  Scanf.scanf "%d\n" @@ fun n ->
  let d = Array.init n @@ fun _ -> Scanf.scanf "%d " @@ fun n -> n in
  let ans = ref 0 in
  for i = 0 to n - 2 do
    for j = i + 1 to n - 1 do
      ans := !ans + d.(i)*d.(j)
    done;
  done;
  Printf.printf "%d\n" !ans
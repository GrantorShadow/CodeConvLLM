let () =
let a, b, x = Scanf.scanf "%d %d %d\n" (fun a b c -> a, b, c) in
Printf.printf "%s\n" (if a <= x && x <= a+b then "YES" else "NO")
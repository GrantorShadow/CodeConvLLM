let () = Scanf.scanf "%d %d\n" @@ fun n t ->
  let abs = Array.init n @@ fun _ -> Scanf.scanf "%d %d\n" @@ fun a b -> a, b in
  Array.sort compare abs;
  let dp = Array.make 6001 0 in
  Array.iter (fun (a, b) ->
    for i = a + t - 1 downto a do
      dp.(i) <- max dp.(i) (b + dp.(i - a))
    done) abs;
  Printf.printf "%d\n" @@ Array.fold_left max min_int dp


let () =
  let w,h,x,y,r = Scanf.sscanf (read_line()) "%d %d %d %d %d" (fun a b c d e -> a, b, c, d, e) in
  print_string (if r <= x && x+r <= w && r <= y && y+r <= h then "Yes\n" else "No\n")
;;

let () =
  let n, k = Scanf.scanf "%d %d\n" (fun n k -> n, k) in
  let s = Scanf.scanf "%s\n" (fun s -> s) in
  let tmp = ref "" in
  for i = 0 to n - 1 do
    if i = k - 1 then tmp := !tmp ^ (String.sub s i 1 |> String.lowercase)
    else tmp := !tmp ^ (String.sub s i 1)
  done;
  !tmp |> print_string
open Scanf
open Printf

let multiplication lst =
  let ans = List.fold_right ( * ) lst 1 in
    if ans > 1000000000000000000 then -1 else ans

let n = read_int ()
let a_list = List.map (fun n -> int_of_string n) (String.split_on_char ' ' (read_line ()))
let () = printf "%d\n" (multiplication a_list)
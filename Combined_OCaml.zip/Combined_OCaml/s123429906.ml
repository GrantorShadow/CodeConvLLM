let n = read_int ()
let a_s = Array.init n @@ fun _ -> Scanf.scanf " %d" (+) 0
let s, l = ref 0, ref 0
let _ = Array.(sort (-) a_s; iteri (fun i a -> if i > 0 then s := !s + a_s.(i - 1); if a > 2 * !s then l := i) a_s); Printf.printf "%d\n" @@ n - !l
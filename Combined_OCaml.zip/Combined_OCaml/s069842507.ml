class dice init =
  let rot_n (x1,x2,x3,x4,x5,x6):int*int*int*int*int*int = (x2,x6,x3,x4,x1,x5) and
      rot_e (x1,x2,x3,x4,x5,x6):int*int*int*int*int*int = (x4,x2,x1,x6,x5,x3) in
  let rot_s l = rot_n l |> rot_n |> rot_n and
      rot_w l = rot_e l |> rot_e |> rot_e in
  let all_init =
    let rec rotate d list = function
        0 -> list
      | i -> rotate (rot_e d) (d::list) (i-1) in
    let rotate2 n l = rotate n l 4 in
    rotate2 init []
    |> rotate2 (rot_e init |> rot_s)
    |> rotate2 (rot_w init |> rot_s)
    |> rotate2 (rot_n init)
    |> rotate2 (rot_s init)
    |> rotate2 (rot_n init |> rot_n) in
object (self: 'self)
  val mutable faces:int*int*int*int*int*int = init
  val all:'a list = all_init

  method get_face = faces
  method get_all = all
  method equals (other:'self) = self#contains other#get_face
  method contains fc =
    let rec find l = match l with
        [] -> false
      | (x1,x2,x3,x4,x5,x6)::tl -> if (x1,x2,x3,x4,x5,x6) = fc then true
                                   else find tl
    in find all
end;;

let split_int s = Str.split (Str.regexp_string " ") s |> List.map int_of_string;;
let () =
  let f n = (n 0,n 1,n 2,n 3,n 4,n 5) in
  let nth s = split_int s |> List.nth in
  let d1 = new dice (read_line () |> nth |> f) and
      d2 = new dice (read_line () |> nth |> f) in
  if d1#equals(d2) then print_endline "Yes"
  else print_endline "No"
;;
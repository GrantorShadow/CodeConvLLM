Scanf.(Array.(
  let n,k=scanf" %d %d"@@fun u v->u,v in
  let h=init n@@fun _->scanf" %d"@@fun v->v in
  sort compare h;
  init(n-k+1)(fun i->h.(i+k-1)-h.(i))
  |>fold_left min max_int
  |>print_int))
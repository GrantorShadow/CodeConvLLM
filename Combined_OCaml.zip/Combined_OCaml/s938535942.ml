open Core

let n = Scanf.scanf "%d" ident

let a =
  List.init n ~f:(fun _ -> Scanf.scanf " %d" Fn.id)

let ans = a |> List.dedup_and_sort ~compare:Int.compare |> List.length

let () = Printf.printf "%d\n" ans

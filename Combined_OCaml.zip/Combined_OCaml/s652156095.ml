Scanf.scanf "%d" (fun n ->
    let rec loop i tt xx yy =
        if i = n then "Yes" else
            let t, x, y =  Scanf.scanf " %d %d %d" (fun t x y -> t, x, y) in
            let t0 = t - tt in
            let x0 = abs (xx - x) in
            let y0 = abs (yy - y) in
            if x0 + y0 <= t0 && (t0 - x0 - y0) mod 2 = 0 then loop (i + 1) t x y else "No"
    in
    loop 0 0 0 0 |> print_endline
)
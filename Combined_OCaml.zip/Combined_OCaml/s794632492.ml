let () = Scanf.scanf "%s %s" @@ fun s t ->
  let ans = ref 0 in
  for i = 0 to 2 do
    if s.[i] = t.[i] then ans := !ans + 1
  done;
  Printf.printf "%d\n" !ans
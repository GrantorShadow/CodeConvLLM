open Scanf
open Printf

let cats_and_dogs a b x =
  if a > x then "NO"
  else if a + b < x then "NO"
  else "YES"

let () = scanf "%d %d %d" cats_and_dogs |> printf "%s\n"
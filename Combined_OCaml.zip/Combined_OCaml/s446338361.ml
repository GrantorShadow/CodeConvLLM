Scanf.scanf "%d" (fun k ->
    let c = k mod 50 in
    Printf.printf "50\n";
    for j = 0 to 49 do
        Printf.printf "%d " @@
            if j < c then (49 - j) + (k / 50) + 1
                     else (49 - j) + (k / 50)
    done;
    print_newline ()
)
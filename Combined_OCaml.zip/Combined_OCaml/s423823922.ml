let a = read_int ()
let b = read_int ()
let h = read_int ()
let () =
  print_int (a + b) * h / 2;
  print_newline()

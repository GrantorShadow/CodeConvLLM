let () =
  let n = Scanf.scanf "%d\n" (fun n -> n) in
  let as_ = Array.init n (fun _ -> Scanf.scanf "%d " (fun a -> a)) in
  Array.to_list as_
  |> List.sort compare
  |> List.fold_left (fun (acc, prev) a ->
      match prev with
      | None -> (acc, Some a)
      | Some a' ->
          if a = a' then (a :: acc, None)
          else (acc, Some a)) ([], None)
  |> fst
  |> (function (n :: m :: _) -> n * m | _ -> 0)
  |> Printf.printf "%d\n"
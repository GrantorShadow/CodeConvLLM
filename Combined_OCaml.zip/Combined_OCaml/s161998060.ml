(*
ocamlfind ocamlopt -package batteries -linkpkg main.ml -o a.out
*)
open Batteries

let () =
        (
                let set = Str.split (Str.regexp "") (read_line ())
                          |> List.sort_uniq compare
                          |> Set.of_list
                in

                let abclst = ["a"; "b"; "c"; "d"; "e"; "f"; "g"; "h"; "i"; "j"; "k"; "l"; "m"; "n"; "o"; "p"; "q"; "r"; "s"; "t"; "u"; "v"; "w"; "x"; "y"; "z"]
                             |> Set.of_list
                in
                        try 
                                Set.diff abclst set
                                |> Set.min_elt
                        with Not_found -> ("None")
        ) |> Printf.printf "%s\n"

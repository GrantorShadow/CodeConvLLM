let solve x y = 
  (x - 1) * (y - 1)

let () =
  let rec read () =
    try let ans = (Scanf.scanf "%d %d\n" solve) in
        Printf.printf "%d\n" ans
    with End_of_file -> ()
  in
  read ()
;;

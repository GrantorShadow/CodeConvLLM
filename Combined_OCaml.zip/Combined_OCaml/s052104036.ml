let rec gcd a b = if b = 0 then a else gcd b (a mod b)
let () =
  Scanf.scanf "%d" @@ fun n ->
  let a = Array.init n (fun _ -> Scanf.scanf " %d" ((+) 0)) in
  Array.fold_left gcd a.(0) a
  |> Printf.printf "%d\n"
Scanf.scanf "%d %d" (fun a b ->
    Printf.printf "%d\n" @@ (a - 1) * (b - 1)
)
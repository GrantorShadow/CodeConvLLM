let rec f res (n, k) =
  if n <= 0 then res
  else if res > k then f (res + k) (n - 1, k)
  else f (res * 2) (n - 1, k)

let () =
  let n, k = Scanf.scanf "%d\n%d" (fun n k -> (n, k)) in
  f 1 (n, k) |> print_int

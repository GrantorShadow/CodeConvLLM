    let hantei a b = if (a + b) mod 3 = 0 then "Possible"
    else if a mod 3 = 0 then "Possible"
    else if b mod 3 = 0 then "Possible"
    else "Impossible"
     
  print_string (hantei A B)
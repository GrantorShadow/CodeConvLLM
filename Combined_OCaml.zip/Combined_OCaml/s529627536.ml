Scanf.scanf "%d" (fun d ->
    let c = Array.init 26 (fun _ -> Scanf.scanf " %d" (fun c -> c)) in
    let s = Array.init d (fun _ ->
        Array.init 26 (fun _ ->
            Scanf.scanf " %d" (fun s -> s)))
    in
    let last = Array.make 26 (-1) in
    let f a = a * (a - 1) / 2 in
    for i = 0 to d - 1 do
        let g =
            let rec loop j acc =
                if j = 26 then acc else loop (j + 1) (acc + f (i - last.(j)))
            in
            loop 0 0
        in
        let rec loop j mi mx =
            if j = 26 then (last.(i) <- mi - 1; Printf.printf "%d\n" mi) else
                if s.(i).(j) + c.(j) * f (i - last.(j)) > mx then loop (j + 1) (j + 1) s.(i).(j)
                                                             else loop (j + 1) mi mx
        in
        loop 0 0 0
    done
)
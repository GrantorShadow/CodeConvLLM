let n = read_line ()
let _ = print_endline @@ if n.[0] = n.[1] && n.[1] = n.[2] || n.[1] = n.[2] && n.[2] = n.[3] then "Yes" else "No"
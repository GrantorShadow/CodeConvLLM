let () =
  let rec read pos =
    try let l = read_line ()
                |> Str.split (Str.regexp_string ",")
        in
        if (List.nth l 0) = pos then
          read (List.nth l 1)
        else if (List.nth l 1) = pos then
          read (List.nth l 0)
        else
          read pos
    with End_of_file -> pos
  in print_endline (read "A")
;;
let f x y l =
  let rec loop n m s=
    if n mod m = 0 then
      loop (n/m) m (m::s)
    else
      (n, s)
  in loop x y l;
;;

let () =
  let num = read_int () in
  let s = (string_of_int num)^":" in
  let rec loop n m s step =
    if n < m then s
    else
      if n mod m = 0 then
        loop (n/m) m (m::s) step
      else if step = 2 then
        loop n (m+2) s 4
      else
        loop n (m+4) s 2
   in
   let (n2, s2) = f num 2 [] in
   let (n3, s3) = f n2 3 s2 in
   let p = loop n3 5 s3 2 |> List.rev in
   let rec loop = function
       [] -> ()
     | hd::tl -> Printf.printf " %d" hd;loop tl
   in
   Printf.printf "%s" s;
   loop p;
   print_newline ()
;;
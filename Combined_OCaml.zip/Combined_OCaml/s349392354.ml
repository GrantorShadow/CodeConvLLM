let rec solve n =
    match n with
    1 -> 1
    | n -> (n * (solve (n - 1))) mod 1000000007;;

let () =
    let n = read_int () in
    print_int (solve n);
    print_newline ();;


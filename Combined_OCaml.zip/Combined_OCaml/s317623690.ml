open Printf
open Scanf

let () =
	let x, y = scanf "%d %d" (fun x y -> (x, y)) in
	((x - 1) * (y - 1)) |> printf "%d\n"
	
let _ =
	let n, k = Scanf.scanf "%d %d\n" (fun n k -> n, k) in
    (if n mod k = 0 then 0 else max ((n / k) - (n mod k)) 1)
    |> print_int
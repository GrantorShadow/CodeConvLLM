let () =
  Scanf.scanf "%s" (fun s ->
      let p = String.sub s 0 3 in
      let t = String.sub s 4 6 in
      print_endline (p ^ "8" ^ t) )

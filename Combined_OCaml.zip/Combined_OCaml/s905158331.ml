let x, t = Scanf.scanf " %d %d" @@ fun a b -> a, b
let ans = if x > t then x - t else 0
let () = print_int ans
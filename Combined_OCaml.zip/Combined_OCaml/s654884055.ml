let w, h, n = Scanf.scanf " %d %d %d" @@ fun a b c -> a, b, c
let l, r, d, t = ref 0, ref w, ref 0, ref h
let xyas = Array.init n @@ fun _ -> Scanf.scanf " %d %d %d" @@ fun a b c -> a, b, c
let _ = Array.iter (fun (x, y, a) -> match a with 1 -> l := max !l x | 2 -> r := min !r x | 3 -> d := max !d y | _ -> t := min !t y) xyas;
  Printf.printf "%d\n" @@ max 0 (!r - !l) * max 0 (!t - !d)
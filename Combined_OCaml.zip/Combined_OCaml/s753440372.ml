let n, k = Scanf.scanf " %d %d" @@ fun a b -> a, b
let ab_s = Array.init n @@ fun _ -> Scanf.scanf " %d %d" @@ fun a b -> a, b
let _ = Array.(sort compare ab_s; fold_left (fun r (a, b) -> if r + b >= k then (Printf.printf "%d\n" a; exit 0); r + b) 0 ab_s)
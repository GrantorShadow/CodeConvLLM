let () =
  let n = read_int () in
  let rec check x =
    if x < 0 then print_endline ":("
    else if x * 108 / 100 = n then print_int x
    else check (x-1) in
  check 50000
Scanf.scanf" %d %d"@@fun n k->
let rec f v = function
| 0 -> v
| i -> min (f (v*2) (i-1)) (f (v+k) (i-1))
in f 1 n |> print_int
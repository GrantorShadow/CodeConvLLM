(*
ocamlfind ocamlopt -package batteries -linkpkg main.ml -o a.out
*)
open Batteries

let lst = Str.split (Str.regexp "") (read_line ())
          |> List.sort compare
let lst2 = List.sort_uniq compare lst
let lst3 = 
        List.map (fun elmnt1 ->
                List.filter (fun elmnt2 ->
                        elmnt1 = elmnt2
                ) lst
        ) lst2
let lst4 = List.map (fun elst ->
        List.length elst
) lst3

let () =
        (
                if List.exists (fun elmnt -> elmnt mod 2 = 1) lst4 then
                        "No"
                else
                        "Yes"
        ) |> Printf.printf "%s\n"

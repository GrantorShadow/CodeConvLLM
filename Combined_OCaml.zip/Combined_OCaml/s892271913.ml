let f x y =
    if x < 35.5 &&  y < 71. then "AAA"
    else if x < 37.5 &&  y < 77. then "AA"
    else if x < 40. &&  y < 83. then "A"
    else if x < 43. &&  y < 89. then "B"
    else if x < 50. &&  y < 105. then "C"
    else if x < 55. &&  y < 116. then "D"
    else if x < 70. &&  y < 148. then "E"
    else "NA"
;;

let () =
  let rec read () =
    let line = read_line ()
            |> Str.split (Str.regexp " ")
            |> List.map float_of_string
            |> Array.of_list
    in
    let (x,y) = (line.(0), line.(1)) in
    Printf.printf "%s\n" (f x y);
    read ()
  in
  read ()
;;
let rec popcnt acc = function
  | 0 -> acc
  | n -> popcnt (acc + (n land 1)) (n lsr 1)
let popcnt = popcnt 0

module SegTree = struct
  module type SemiGroup = sig
    type t
    val op : t -> t -> t
  end

  module Make (S : SemiGroup) : sig
    type t
    type elt

    (* 与えられたリストの要素からなるセグ木を作る *)
    val of_list : elt list -> t
    (* f 0, ... f (n - 1)のn要素からなるセグ木を作る *)
    val init : int -> (int -> elt) -> t
    (*
     * update i f t
     * i番目の要素x_iをf x_iに変更したセグ木を作る
     *)
    val update : int -> (elt -> elt) -> t -> t
    (*
     * query l r t
     * 添字が[l, r)の要素を半群の演算子で畳み込んだ値を求める
     *)
    val query : int -> int -> t -> elt
  end with type elt = S.t = struct
    type elt = S.t

    type body =
      | Leaf of elt
      | Node of elt * body * body
    type t = { size : int; body : body }

    (* セグ木の要素をどのように左右に分配するか
       正整数nについて lsize n + rsize n = n が成り立たなくてはならない *)
    let lsize n = n lsr 1
    let rsize n = (n + 1) lsr 1

    (* セグ木の保持する要素を半群の演算子で畳み込んだもの *)
    let data = function
      | Leaf x
      | Node (x, _, _) -> x

    let mknode l r = Node (S.op (data l) (data r), l, r)

    let rec of_list l = function
      | 1 -> Leaf (List.hd l), List.tl l
      | n ->
          let t1, l = of_list l (lsize n) in
          let t2, l = of_list l (rsize n) in
          mknode t1 t2, l
    let of_list l =
      let n = List.length l in
      assert (0 < n);
      { size = n; body = fst (of_list l n) }

    let rec init i f = function
      | 1 -> Leaf (f i)
      | n -> mknode (init i f (lsize n)) (init (i + lsize n) f (rsize n))
    let init n f =
      assert (1 <= n);
      { size = n; body = init 0 f n }

    let rec update n i f = function
      | Leaf x -> Leaf (f x)
      | Node (_, l, r) ->
          if i < lsize n
          then mknode (update (lsize n) i f l) r
          else mknode l (update (rsize n) (i - lsize n) f r)
    let update i f t =
      assert (0 <= i && i < t.size);
      { t with body = update t.size i f t.body }

    let rec query n l r = function
      | Leaf x -> x
      | Node (x, left, right) ->
          if l = 0 && r = n then x
          else if r <= lsize n then query (lsize n) l r left
          else if lsize n <= l then query (rsize n) (l - lsize n) (r - lsize n) right
          else S.op (query (lsize n) l (lsize n) left) (query (rsize n) 0 (r - lsize n) right)
    let query l r t =
      assert (0 <= l && l < r && r <= t.size);
      query t.size l r t.body
  end
end

module MinSegTree = SegTree.Make (struct
  type t = int
  let op = min
end)

let inf = 1145141919810

let () = Scanf.scanf "%d\n" @@ fun n ->
  let as_ = Array.init n @@ fun _ -> Scanf.scanf "%d " @@ fun a -> a in
  let bs = Array.init n @@ fun _ -> Scanf.scanf "%d " @@ fun b -> b in
  let dp = Array.init (1 lsl n) @@ fun _ -> MinSegTree.init 52 @@ fun _ -> inf in
  dp.(0) <- MinSegTree.update 0 (fun _ -> 0) dp.(0);
  for mask = 0 to (1 lsl n) - 1 do
    for i = 0 to n - 1 do
      if mask land (1 lsl i) = 0 then begin
        let j = popcnt mask in
        let x = if i mod 2 = j mod 2 then as_.(i) else bs.(i) in
        dp.(mask lor (1 lsl i)) <-
          MinSegTree.update x (min (max 0 (i - j) + MinSegTree.query 0 (x + 1) dp.(mask))) dp.(mask lor (1 lsl i))
      end
    done
  done;
  let ans = MinSegTree.query 0 51 dp.((1 lsl n) - 1) in
  Printf.printf "%d\n" @@ if inf <= ans then -1 else ans
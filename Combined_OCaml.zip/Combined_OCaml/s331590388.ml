Scanf.scanf "%d" (fun n ->
    let ds k =
        let rec loop r acc =
            if r = 0 then acc else loop (r / 10) (acc + r mod 10)
        in
        loop k 0
    in
    let rec loop a acc =
        if a = 0 then acc else
            loop (a - 1) (min acc (ds a + ds (n - a)))
    in
    loop (n / 2) max_int |> Printf.printf "%d\n"
)
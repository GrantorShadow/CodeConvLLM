open Scanf
open Printf

let id a = a
let pair a b = a, b
let triplet a b c = a, b, c

let rec scan_list = function
  | 1 -> scanf "%d" (fun k -> [k])
  | n -> scanf "%d " (fun k -> k :: scan_list (n-1))

let rec s = function
  | 0 -> 0
  | n -> n mod 10 + s (n / 10)

let sunuke n = float_of_int n /. float_of_int (s n)

let rec repeat c = function
  | 0 -> []
  | n -> c :: repeat c (n-1)

let f n = for i = 1 to n do
    printf "%d99\n" i
  done

let g n = if n > 9
  then begin
    for i = 1 to 9 do
      printf "%d9\n" i
    done;
    f (n-9)
  end
  else
    for i = 1 to n do
      printf "%d9\n" i
    done

let h n = if n > 9
  then begin
    for i = 1 to 9 do
      printf "%d\n" i
    done;
    g (n-9)
  end
  else
    for i = 1 to 9 do
      printf "%d\n" i
    done

let () = scanf "%d\n" h
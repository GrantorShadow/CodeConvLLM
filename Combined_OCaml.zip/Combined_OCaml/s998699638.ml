let k = read_int ()
let a, b = Scanf.scanf "%d %d\n" @@ fun a b -> a, b
let ans = if k = 1 then "OK" else if b/k - a/k > 0 then "OK" else "NG"
let () = print_endline ans
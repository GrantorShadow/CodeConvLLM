let rec f s  minN len =
  if len > 2 then
    let buf = int_of_string (String.sub s 0 3) in
    let newS = String.sub s 1 (len-1) in
    let ans = abs (753 - buf) in
    if minN > ans then f newS ans (len-1) else f newS minN (len-1)
  else minN
let () = Scanf.scanf "%d\n"
    (fun d -> let s = string_of_int d in
       f s max_int (String.length s)) |> print_int
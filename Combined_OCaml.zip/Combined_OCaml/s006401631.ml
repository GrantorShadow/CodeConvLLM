let n = read_int ()
let s = read_line ()
let l, r = ref 0, ref 0
let _ = String.(iter (function '(' -> incr r | _ -> if !r = 0 then incr l else decr r) s; Printf.printf "%s%s%s\n" (make !l '(') s (make !r ')'))
let () = Scanf.scanf "%d %d\n" @@ fun n m ->
  let alist = List.init m @@ fun _ -> Scanf.scanf " %d" Fun.id in
  let sum = List.fold_left (+) 0 alist in
  Printf.printf "%d\n" @@ max (-1) (n-sum)

let id x = x
let n = Scanf.scanf "%d\n" id
let a = Array.init n (fun _ -> (Scanf.scanf "%d " id))  
let h = Hashtbl.create 100000

let hash_add x =
  if Hashtbl.mem h x then Hashtbl.replace h x ((Hashtbl.find h x) + 1)
  else Hashtbl.add h x 1  

let rec add m = 
  if m = n then ()
  else
    let () = hash_add (a.(m)-1) in
    let () = hash_add (a.(m)) in
    let () = hash_add (a.(m)+1) in
    add (m+1)
      
let rec func m z =
  if m = n then z
  else
    let h = max (max (Hashtbl.find h (a.(m)-1)) (Hashtbl.find h (a.(m)))) (Hashtbl.find h (a.(m)+1)) in
    func (m+1) (max h z)
      
let () = add 0

let () =
  let ans = func 0 0 in
  Printf.printf "%d\n" ans
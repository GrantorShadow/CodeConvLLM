
open Scanf
open Printf

let rec for_iter a b f = if a >= b then () else (f a; for_iter (a+1) b f)
let rec for_iterr a b f = if a <= b then () else (f a; for_iter (a-1) b f)
let rec for_iters a b s f = if (a-b >= 0) <> (s >= 0) then () else (f a; for_iter (a+s) b f)

let read_int () = scanf " %d" (fun x -> x)
let rec read_ints n = if n = 0 then [] else let i = read_int () in i :: read_ints (n-1)
let read_ints_arr n = Array.init n (fun _ -> read_int ())
let read_ints_arr_ref n = Array.init n (fun _ -> ref (read_int ()))

let solve a b c x =
  let rec f u v w acc =
    let acc' = acc + if 500 * u + 100 * v + 50 * w = x then 1 else 0 in
    if w < c then f u v (w+1) acc'
    else if v < b then f u (v+1) 0 acc'
    else if u < a then f (u+1) 0 0 acc'
    else acc'
  in f 0 0 0 0

let () =
  let a = read_int () in
  let b = read_int () in
  let c = read_int () in
  let x = read_int () in
  printf "%d\n" (solve a b c x)

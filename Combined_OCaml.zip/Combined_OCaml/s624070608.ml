type 'a t = Empty | Node of 'a node
and 'a node = {index:int; value:'a; left:'a t; right:'a t}

let rec get i t =
    match t with
    | Empty -> failwith "get"
    | Node(n) ->
        if n.index = i then
            n.value
        else if n.index > i then
            get i n.left
        else
            get i n.right

let rec set i v t =
    match t with
    | Empty -> failwith "set"
    | Node(n) ->
        if n.index = i then
            Node {n with value = v}
        else if n.index > i then
            Node {n with left = set i v n.left}
        else
            Node {n with right = set i v n.right}

let rec init v a b =
    if a > b then Empty
    else
        let mid = (a + b) / 2 in
        Node {
            index = mid;
            value = v;
            left  = init v a (mid - 1);
            right = init v (mid + 1) b
        }

let find_max t =
    let rec loop v t =
        match t with
        | Empty -> v
        | Node(n) ->
            max v @@ max n.value @@ max (loop v n.left) (loop v n.right)
    in loop 0 t

let solve n edges dp =
    let rec loop' v dp =
        let l = get v dp in
        if l >= 0 then (l, dp)
        else
            List.fold_left (fun (len, dp) u ->
                let (len', dp') = loop' u dp in
                let len'' = max len (len' + 1) in
                (len'', dp')
            ) (0, dp) (get v edges)
    in
    let rec loop n dp =
        if n = 0 then dp
        else
            let (len, dp') = loop' n dp in
            loop (n - 1) (set n len dp')
    in find_max @@ loop n dp

let rec input m ls =
    if m = 0 then ls
    else
        Scanf.scanf "%d %d\n" @@ fun x y ->
        input (m - 1) @@ set x (y :: get x ls) ls

let () =
    Scanf.scanf "%d %d\n" @@ fun n m ->
    let edges = input m (init [] 1 n) in
    Printf.printf "%d\n" @@ solve n edges (init (-1) 1 n)

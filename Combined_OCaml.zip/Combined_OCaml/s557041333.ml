Scanf.scanf "%d" (fun n ->
    let l = Array.make n 0 in
    let r = Array.make n 0 in
    for i = 0 to n - 1 do
        Scanf.scanf " %d %d" (fun a b -> l.(i) <- a; r.(i) <- b + 1)
    done;

    let rec loop i p q =
        if i = n then p, q else
            let p = if l.(i) > l.(p) then i else p in
            let q = if r.(i) < r.(q) then i else q in
            loop (i + 1) p q
    in
    let p, q = loop 0 0 0 in

    let result1 =
        let rec loop j acc =
            if j = n then acc + max (r.(q) - l.(p)) 0 else
            if j = p || j = q then loop (j + 1) acc else
                loop (j + 1) (max acc (r.(j) - l.(j)))
        in
        loop 0 0
    in
 
    let result2 = (
        let work = Array.init n (fun i -> max (r.(i) - l.(p)) 0, max (r.(q) - l.(i)) 0) in
        Array.sort (fun (a0, b0) (a1, b1) -> compare (-b0, a0) (-b1, a1)) work;
        let s = Array.make (n + 1) 0 in
        let t = Array.make (n + 1) 0 in
        t.(0) <- r.(q) - l.(q);
        s.(n) <- r.(p) - l.(p);
        for i = 1 to n do
            let _, b = work.(i - 1) in
            t.(i) <- min t.(i - 1) b;
        done;
        for i = n - 1 downto 0 do
            let a, _ = work.(i) in
            s.(i) <- min s.(i + 1) a;
        done;

        let rec loop i acc =
            if i = n + 1 then acc else loop (i + 1) (max acc (s.(i) + t.(i)))
        in
        loop 0 0
    )
    in
    Printf.printf "%d\n" @@ max result1 result2
)
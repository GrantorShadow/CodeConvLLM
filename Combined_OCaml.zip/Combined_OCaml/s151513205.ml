(* O(1) *)
let f0 n =
  let last = if n mod 2 = 0 then n else 0 in
  last lxor if (n + 1) / 2 mod 2 = 0 then 0 else 1

(* O(1) *)
let solve a b = f0 (a - 1) lxor f0 b

let read_ints () = read_line () |> Str.split (Str.regexp " ") |> List.map int_of_string

let _ =
  match read_ints () with
  | [a; b] -> solve a b |> string_of_int |> print_endline
  | _ -> ()
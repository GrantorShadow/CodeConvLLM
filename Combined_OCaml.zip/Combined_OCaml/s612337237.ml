Scanf.scanf "%d" (fun n ->
    let h = [| Array.make 100001 0; Array.make 100001 0 |] in
    let module S = Set.Make (struct type t = int * int let compare = compare end) in
    for i = 0 to n - 1 do
        Scanf.scanf " %d" (fun v ->
            h.(i mod 2).(v) <- h.(i mod 2).(v) + 1;
        )
    done;
    let rec loop i set1 set2 =
        if i = 100001 then set1, set2 else
            let set1 = if h.(0).(i) > 0 then S.add (h.(0).(i), i) set1 else set1 in
            let set2 = if h.(1).(i) > 0 then S.add (h.(1).(i), i) set2 else set2 in
            loop (i + 1) set1 set2
    in
    let set1, set2 = loop 0 S.empty S.empty in
    let ((v1, i1) as m1) = S.max_elt set1 in
    let ((v2, i2) as m2) = S.max_elt set2 in

    Printf.printf "%d\n" @@
    if i1 <> i2 then n - v1 - v2 else (
        let c1 = S.cardinal set1 in
        let c2 = S.cardinal set2 in
        if c1 > 1 && c2 > 1 then (
            let (v3, i3) = S.max_elt (S.remove m1 set1) in
            let (v4, i4) = S.max_elt (S.remove m2 set2) in
            min (n - v3 - v2) (n - v1 - v4)
        ) else if c1 > 1 then (
            let (v3, i3) = S.max_elt (S.remove m1 set1) in
            n - v3 - v2
        ) else if c2 > 1 then (
            let (v4, i4) = S.max_elt (S.remove m2 set2) in
            n - v1 - v4
        ) else n / 2
    )
)
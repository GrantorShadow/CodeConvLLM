(* Vicfred
 * https://atcoder.jp/contests/abc130/tasks/abc130_a
 * implementation
 * *)
Scanf.scanf "%d %d\n" (fun x a ->
    if x < a then 0 else 10
) |> Printf.printf "%d\n"


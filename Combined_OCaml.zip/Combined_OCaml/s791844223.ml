
open Scanf
open Printf

let read_int () = scanf " %d" (fun x -> x)
let rec read_ints n = if n = 0 then [] else let i = read_int () in i :: read_ints (n-1)

let () =
  let n = read_int () in
  let xs = List.sort (-) @@ read_ints n in
  let f (a, h) x = if h < x then (a+1, x) else (a, h) in
  let ans, _ = List.fold_left f (0, -1) xs in
  printf "%d\n" ans

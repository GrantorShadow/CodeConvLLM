let () =
  let x,y = Scanf.scanf "%d %d " (fun a b -> a,b) in

  let rec aux cnt res =
    let res = res * 2 in
    if res > y then cnt else aux (cnt+1) res
  in

  Printf.printf "%d\n" @@
  aux 1 x

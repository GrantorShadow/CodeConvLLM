open Scanf
let id x = x
let read_int _ = scanf " %d" id
let () =
  let n = scanf " %d" id in
  let a = Array.init n read_int in
  let b = Array.init n read_int in
  let c = Array.init n read_int in
  Array.sort (-) a; Array.sort (-) b; Array.sort (-) c;
  let f u v =
    let res = Array.make n 0 in
    let rec g a i =
      if i >= n then ()
      else if a = n then (
        res.(i) <- n; g n (i+1)
      ) else if v.(i) <= u.(a) then (
        res.(i) <- a; g a (i+1)
      ) else g (a+1) i in
    g 0 0; res in
  let ab = f a b in
  let bc = f b c in
  Array.iteri (fun i e -> if i > 0 then ab.(i) <- e + ab.(i-1)) ab;
  Array.map (fun e -> if e = 0 then 0 else ab.(e-1)) bc
  |> Array.fold_left (+) 0 |> Printf.printf "%d\n"



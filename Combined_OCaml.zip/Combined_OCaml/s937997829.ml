let () = Scanf.scanf "%d\n" @@ fun n ->
  let as_ = Array.init n @@ fun _ -> Scanf.scanf "%d " @@ fun a -> a in
  let i =
    Array.fold_left (fun i j ->
      if abs as_.(i) < abs as_.(j) then j else i) 0
    @@ Array.init n (fun i -> i) in
  if as_.(i) = 0 then
    print_endline "0"
  else begin
    Printf.printf "%d\n" @@ 2 * n - 2;
    for j = 0 to n - 1 do
      if i <> j then Printf.printf "%d %d\n" (i + 1) (j + 1) 
    done;
    if 0 < as_.(i) then
      for j = 1 to n - 1 do
        Printf.printf "%d %d\n" j (j + 1)
      done
    else
      for j = n - 1 downto 1 do
        Printf.printf "%d %d\n" (j + 1) j
      done
  end
let abs s =
  snd @@ Array.fold_left (fun (c, abs) c' ->
    (c', abs + if c = 'A' && c' = 'B' then 1 else 0)) ('_', 0) @@
  Array.init (String.length s) (String.get s)

let () = Scanf.scanf "%d\n" @@ fun n ->
  let ss = Array.init n @@ fun _ -> Scanf.scanf "%s\n" @@ fun s -> s in
  let (a, b, ba) =
    Array.fold_left (fun (a, b, ba) s ->
      if s.[0] = 'B' && s.[String.length s - 1] = 'A' then (a, b, ba + 1)
      else if s.[0] = 'B' then (a, b + 1, ba)
      else if s.[String.length s - 1] = 'A' then (a + 1, b, ba)
      else (a, b, ba)) (0, 0, 0) ss in
  Printf.printf "%d\n" @@
  Array.fold_left (fun a s -> a + abs s) 0 ss + ba + min a b
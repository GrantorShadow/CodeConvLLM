let id x = x
let (x,a,b) = Scanf.scanf "%d %d %d" (fun x a b -> (x,a,b))

let ans = if b <= a then "delicious" else
    if b <= x + a then "safe" else "dangerous"
  
let () =
  Printf.printf "%s\n" ans
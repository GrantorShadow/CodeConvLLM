let () =
  let n, m = Scanf.scanf "%d %d\n" (fun n m -> (n, m)) in
  let arr = Array.init n (fun _ -> Scanf.scanf " %d" (fun a -> a)) in
  let sum = float_of_int @@ Array.fold_left ( + ) 0 @@ Array.copy arr in
  let fltr = ceil (sum /. (float_of_int m *. 4.)) and count = ref 0 in
  Array.iter (fun i -> if i >= int_of_float fltr then count := !count + 1) arr ;
  if !count >= m then print_endline "Yes" else print_endline "No"

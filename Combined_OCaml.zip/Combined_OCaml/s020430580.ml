let solve h w c =
  for j = 0 to w - 1 do
    c.(0).(j) <- 1 - c.(0).(j);
    for i = 1 to h - 1 do
      c.(i).(j) <- if c.(i).(j) = 1 then 0 else c.(i-1).(j) + 1
    done
  done;
  let rec duduwa ans i j k = function
    | [] -> (ans, [(c.(i).(j), k)])
    | (ch, cj) :: y' when ch >= c.(i).(j) -> duduwa (if ch * (j - cj) > ans then ch * (j - cj) else ans) i j cj y'
    | ys -> (ans, (c.(i).(j), k) :: ys) in
  let rec doit ans = function
    | (i, _, xs) when i = h -> ans
    | (i, j, xs) when j = w -> doit (List.fold_left (fun acc (ch, cj) -> if ch * (w - cj) > acc then ch * (w - cj) else acc) ans xs) (i + 1, 0, [])
    | (i, j, []) -> doit ans (i, j + 1, [(c.(i).(j), j)])
    | (i, j, ((ch, _) :: _ as xs)) when ch < c.(i).(j) -> doit ans (i, j + 1, (c.(i).(j), j) :: xs)
    | (i, j, ((ch, _) :: _ as xs)) when ch > c.(i).(j) ->
      let (ans, ys) = duduwa ans i j j xs in
      doit ans (i, j + 1, ys)
    | (i, j, xs) -> doit ans (i, j + 1, xs) in
  doit 0 (0, 0, [])

let split_on_char sep s =
  let open String in
  let r = ref [] in
  let j = ref (length s) in
  for i = length s - 1 downto 0 do
    if get s i = sep then begin
      r := sub s (i + 1) (!j - i - 1) :: !r;
      j := i
    end
  done;
  sub s 0 !j :: !r

let read () = List.map int_of_string (split_on_char ' ' (read_line ()))

let () =
  match read () with
  | [h; w] ->
    let c = Array.make_matrix h w 0 in
    for i = 0 to h - 1 do
      let rec doit j = function
        | [] -> ()
        | x::xs ->
          c.(i).(j) <- x;
          doit (j + 1) xs in
      doit 0 (read ())
    done;
    Printf.printf "%d\n" (solve h w c)
  | _ -> ()
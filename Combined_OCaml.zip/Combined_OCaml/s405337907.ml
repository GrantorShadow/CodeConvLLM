Printf.printf "%d\n" @@ Scanf.scanf "%d %d" @@ fun n p ->
  let m = Array.init n (fun _ -> Scanf.scanf " %d" ((+) 0))
    |> Array.fold_left (fun z x -> z + x mod 2) 0 in
  if m < p then 0 else 1 lsl (n - if m = 0 then 0 else 1)
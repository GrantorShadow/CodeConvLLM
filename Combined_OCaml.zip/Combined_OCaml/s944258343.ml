let rec f n s =
  if n = 0 then s
  else
    let m = (n - 1) mod 26 in
    let c = char_of_int (m + int_of_char 'a') in
    f ((n - 1) / 26) (Char.escaped c ^ s)

let () =
  let n = read_int () in
  let s = f n "" in
  print_endline s

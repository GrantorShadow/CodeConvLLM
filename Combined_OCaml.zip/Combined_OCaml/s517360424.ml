let () =
  let (n, k) = Scanf.scanf "%d %d " (fun n k -> (n, k)) in
  let a = Array.init n (fun _ -> Scanf.scanf "%d " (fun i -> i)) in
  let check p =
    let rec doit i j s =
      if i = n then n
      else if j >= k then i
      else
        let x = s + a.(i) in
        if x > p then doit i (j + 1) 0
        else doit (i + 1) j x
    in
    doit 0 0 0
  in
  let rec bin_search l r =
    if r < l then l
    else
      let m = (l + r) / 2 in
      if check m >= n then bin_search l (m - 1)
      else bin_search (m + 1) r
  in
  Printf.printf "%d\n" (bin_search 0 (100000 * 10000))
open Scanf
open Printf

let () = scanf "%d %d %d" (fun a b c ->
  a + b + c - (max a (max b c))
  ) |> printf "%d\n"
let () =
  let a, b = Scanf.scanf "%s %s" (fun a b -> a, b) in
  Printf.printf "%s\n" @@ if a.[0] = b.[2] && a.[1] = b.[1] && a.[2] = b.[0] then "YES" else "NO"

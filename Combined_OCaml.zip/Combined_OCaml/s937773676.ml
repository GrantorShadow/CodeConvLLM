open Hashtbl
let h, n, m = create 100100, read_int (), ref 1
let _ = for _ = 1 to n do let s = read_line () in replace h s @@ try let c = find h s + 1 in m := max !m c; c with _ -> 1 done; List.(fold (fun s c a -> if c = !m then s :: a else a) h [] |> sort compare |> iter print_endline)
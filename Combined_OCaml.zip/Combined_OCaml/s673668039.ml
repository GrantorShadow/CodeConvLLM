Scanf.scanf "%d %d %s" (fun n m s ->
    let rec loop cur hist =
        if cur = 0 then Some hist else
            let rec loop2 d =
                if d = 0 then None else
                    match loop (cur - d) (d :: hist) with
                    | None -> loop2 (d - 1)
                    | x -> x
            in
            if s.[cur] = '1' then None else loop2 (min cur m)
    in
    match loop n [] with
    | None -> print_endline "-1"
    | Some best -> List.iter (Printf.printf "%d ") best; print_newline()
)
let () = print_endline @@ Scanf.scanf "%c" @@ function
  | 'A' -> "T"
  | 'C' -> "G"
  | 'G' -> "C"
  | 'T' -> "A"
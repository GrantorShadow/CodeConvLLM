let () = Scanf.scanf "%d %d\n%d %d" (fun h w r c -> (
  Printf.printf "%d\n" ((w - c) * (h - r))
))
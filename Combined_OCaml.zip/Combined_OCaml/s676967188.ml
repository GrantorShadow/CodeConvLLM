let () = Scanf.scanf "%d %d %d" @@ fun a b c ->
  Printf.printf "%d\n" @@ c - min (a - b) c
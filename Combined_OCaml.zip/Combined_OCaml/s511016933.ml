let n = Scanf.scanf " %d" @@ (+) 0
let a_s = Array.init n @@ fun _ -> Scanf.scanf " %d" @@ (+) 0
let bits = ref 0
let r = ref 0
let ans = ref 0
let _ =
  for l = 0 to n - 1 do
    while !r < n && !bits land a_s.(!r) = 0 do bits := !bits + a_s.(!r); incr r done;
    if l = !r then incr r
    else (ans := !ans + !r - l; bits := !bits - a_s.(l)) done;
  Printf.printf "%d\n" !ans
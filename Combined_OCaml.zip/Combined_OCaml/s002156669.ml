Printf.printf "%d\n" @@ Scanf.scanf "%s" @@ fun s ->
  (int_of_char s.[0] - 49) + (9 * (String.length s - 1))
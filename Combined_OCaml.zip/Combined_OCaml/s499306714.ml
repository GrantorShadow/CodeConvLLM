let rec lower_bound l r p =
  if r <= 1 + l
  then r
  else let m = (l + r) / 2 in
       if p m
       then lower_bound l m p
       else lower_bound m r p

let () = Scanf.scanf "%d %d" @@ fun a b ->
  Printf.printf "%d\n" @@
  lower_bound (-1) 1145141919 @@ fun i ->
    b <= (a - 1) * i + 1
